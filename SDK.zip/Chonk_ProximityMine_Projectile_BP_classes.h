// BlueprintGeneratedClass Chonk_ProximityMine_Projectile_BP.Chonk_ProximityMine_Projectile_BP_C
// Size: 0x439 (Inherited: 0x3d1)
struct AChonk_ProximityMine_Projectile_BP_C : AORTestEnemyWeapon_Proj_C {
	char pad_3D1[0x7]; // 0x3d1(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d8(0x08)
	struct UNiagaraComponent* NS_Landing; // 0x3e0(0x08)
	struct UNiagaraComponent* NS_Projectile; // 0x3e8(0x08)
	struct UParticleSystemComponent* Fire; // 0x3f0(0x08)
	struct UORAkComponent* ORAk; // 0x3f8(0x08)
	struct USceneComponent* Scene; // 0x400(0x08)
	struct AProximityMine_BP_C* MineClass; // 0x408(0x08)
	struct UAkAudioEvent* AudioPlayProjSFX; // 0x410(0x08)
	struct UAkAudioEvent* AudioStopProjSFX; // 0x418(0x08)
	struct FORSocketData AttachedCharacterSocketData; // 0x420(0x10)
	struct UAkAudioEvent* AFKAttached; // 0x430(0x08)
	bool PrioritizePreferredSockets; // 0x438(0x01)

	void DeactivateProjectile(); // Function Chonk_ProximityMine_Projectile_BP.Chonk_ProximityMine_Projectile_BP_C.DeactivateProjectile // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AttachToCharacter(struct AORCharacter* Character, struct FVector Location); // Function Chonk_ProximityMine_Projectile_BP.Chonk_ProximityMine_Projectile_BP_C.AttachToCharacter // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	bool AllowImpactWithActor(struct AActor* OtherActor); // Function Chonk_ProximityMine_Projectile_BP.Chonk_ProximityMine_Projectile_BP_C.AllowImpactWithActor // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	float GetAbsorptionWeight(); // Function Chonk_ProximityMine_Projectile_BP.Chonk_ProximityMine_Projectile_BP_C.GetAbsorptionWeight // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AudioStartProjectileSFX(); // Function Chonk_ProximityMine_Projectile_BP.Chonk_ProximityMine_Projectile_BP_C.AudioStartProjectileSFX // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AudioStopProjectileSFX(); // Function Chonk_ProximityMine_Projectile_BP.Chonk_ProximityMine_Projectile_BP_C.AudioStopProjectileSFX // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnReturnedToPool(); // Function Chonk_ProximityMine_Projectile_BP.Chonk_ProximityMine_Projectile_BP_C.OnReturnedToPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnSpawnedFromPool(); // Function Chonk_ProximityMine_Projectile_BP.Chonk_ProximityMine_Projectile_BP_C.OnSpawnedFromPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnImpact(struct FHitResult& ImpactResult); // Function Chonk_ProximityMine_Projectile_BP.Chonk_ProximityMine_Projectile_BP_C.OnImpact // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCharacterImpact(struct AORCharacter* Character, struct FHitResult Hit); // Function Chonk_ProximityMine_Projectile_BP.Chonk_ProximityMine_Projectile_BP_C.OnCharacterImpact // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SpawnMineExplosionDirectly(); // Function Chonk_ProximityMine_Projectile_BP.Chonk_ProximityMine_Projectile_BP_C.SpawnMineExplosionDirectly // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Chonk_ProximityMine_Projectile_BP(int32_t EntryPoint); // Function Chonk_ProximityMine_Projectile_BP.Chonk_ProximityMine_Projectile_BP_C.ExecuteUbergraph_Chonk_ProximityMine_Projectile_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

