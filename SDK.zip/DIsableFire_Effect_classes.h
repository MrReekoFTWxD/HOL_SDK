// BlueprintGeneratedClass DIsableFire_Effect.DIsableFire_Effect_C
// Size: 0x818 (Inherited: 0x818)
struct UDIsableFire_Effect_C : UORGameplayEffect {
};

