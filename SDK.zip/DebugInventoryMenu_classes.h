// WidgetBlueprintGeneratedClass DebugInventoryMenu.DebugInventoryMenu_C
// Size: 0x4f0 (Inherited: 0x3b1)
struct UDebugInventoryMenu_C : UDebugMenu_C {
	char pad_3B1[0x7]; // 0x3b1(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3b8(0x08)
	struct UGridPanel* Grid; // 0x3c0(0x08)
	struct TMap<struct FString, struct TSoftObjectPtr<UInventorySet>> InventoryOverrides; // 0x3c8(0x50)
	struct UDataTable* InventoryItemDataTable; // 0x418(0x08)
	struct TMap<enum class InventoryItemCategory_EN, struct FGameplayTagContainer> ItemCategoryLookup; // 0x420(0x50)
	struct TArray<struct UUserWidget*> ItemWidgets; // 0x470(0x10)
	int32_t Column_Categories; // 0x480(0x04)
	int32_t Column_Name; // 0x484(0x04)
	int32_t Column_Minus; // 0x488(0x04)
	int32_t Column_Owned; // 0x48c(0x04)
	int32_t Column_Plus; // 0x490(0x04)
	int32_t Column_AddDebugAmount; // 0x494(0x04)
	int32_t Column_RemoveAll; // 0x498(0x04)
	char pad_49C[0x4]; // 0x49c(0x04)
	struct TMap<struct FGameplayTag, struct UDebugMenuMissionLabel_C*> OwnedLabelLookup; // 0x4a0(0x50)

	void UpdateOwnedItemLabel(struct FGameplayTag& Key); // Function DebugInventoryMenu.DebugInventoryMenu_C.UpdateOwnedItemLabel // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ClearItemWidgets(); // Function DebugInventoryMenu.DebugInventoryMenu_C.ClearItemWidgets // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ShowItemCategory(enum class InventoryItemCategory_EN ItemCategory); // Function DebugInventoryMenu.DebugInventoryMenu_C.ShowItemCategory // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ShowAllItems(); // Function DebugInventoryMenu.DebugInventoryMenu_C.ShowAllItems // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CreateItemEntryHeaders(); // Function DebugInventoryMenu.DebugInventoryMenu_C.CreateItemEntryHeaders // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CreateCategoryColumn(); // Function DebugInventoryMenu.DebugInventoryMenu_C.CreateCategoryColumn // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AddItemEntry(struct FGameplayTag Item Tag, int32_t Row); // Function DebugInventoryMenu.DebugInventoryMenu_C.AddItemEntry // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CreateGridLabels(); // Function DebugInventoryMenu.DebugInventoryMenu_C.CreateGridLabels // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CacheInventoryData(); // Function DebugInventoryMenu.DebugInventoryMenu_C.CacheInventoryData // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugInventoryMenu.DebugInventoryMenu_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Initialize(); // Function DebugInventoryMenu.DebugInventoryMenu_C.Initialize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnRemoveOneButtonClicked(struct FGameplayTag Item Tag); // Function DebugInventoryMenu.DebugInventoryMenu_C.OnRemoveOneButtonClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnAddOneButtonClicked(struct FGameplayTag Item Tag); // Function DebugInventoryMenu.DebugInventoryMenu_C.OnAddOneButtonClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnAddDebugAmountClicked(struct FGameplayTag Item Tag); // Function DebugInventoryMenu.DebugInventoryMenu_C.OnAddDebugAmountClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnRemoveAllButtonClicked(struct FGameplayTag Item Tag); // Function DebugInventoryMenu.DebugInventoryMenu_C.OnRemoveAllButtonClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugInventoryMenu(int32_t EntryPoint); // Function DebugInventoryMenu.DebugInventoryMenu_C.ExecuteUbergraph_DebugInventoryMenu // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

