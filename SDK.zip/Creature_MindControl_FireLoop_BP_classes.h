// BlueprintGeneratedClass Creature_MindControl_FireLoop_BP.Creature_MindControl_FireLoop_BP_C
// Size: 0x1b8 (Inherited: 0x178)
struct UCreature_MindControl_FireLoop_BP_C : UORFireLoop_CreatureMindControl {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x178(0x08)
	struct TArray<struct UORScriptComponent*> ScriptComponents; // 0x180(0x10)
	struct FGameplayTag MyFireMode; // 0x190(0x08)
	struct FGameplayTag MinionFireMode; // 0x198(0x08)
	struct UCreature_MinionFire_FireLoop_BP_C* MinionFireLoop; // 0x1a0(0x08)
	struct FGameplayTag ADSFireMode; // 0x1a8(0x08)
	struct UCreature_ChargingADS_FireLoop_BP_C* ADSFireLoop; // 0x1b0(0x08)

	struct TArray<struct UORScriptComponent*> GetScriptComponents(); // Function Creature_MindControl_FireLoop_BP.Creature_MindControl_FireLoop_BP_C.GetScriptComponents // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StopCharging(); // Function Creature_MindControl_FireLoop_BP.Creature_MindControl_FireLoop_BP_C.StopCharging // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StartCharging(bool ResetCharge); // Function Creature_MindControl_FireLoop_BP.Creature_MindControl_FireLoop_BP_C.StartCharging // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetupPreview(); // Function Creature_MindControl_FireLoop_BP.Creature_MindControl_FireLoop_BP_C.SetupPreview // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetupChargeSC(); // Function Creature_MindControl_FireLoop_BP.Creature_MindControl_FireLoop_BP_C.SetupChargeSC // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetScriptComponents(struct TArray<struct UORScriptComponent*>& ScriptComponents); // Function Creature_MindControl_FireLoop_BP.Creature_MindControl_FireLoop_BP_C.SetScriptComponents // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BeginFireLoop(); // Function Creature_MindControl_FireLoop_BP.Creature_MindControl_FireLoop_BP_C.BeginFireLoop // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void EndFireLoop(); // Function Creature_MindControl_FireLoop_BP.Creature_MindControl_FireLoop_BP_C.EndFireLoop // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BP_Init(struct FGameplayTag ModeKey); // Function Creature_MindControl_FireLoop_BP.Creature_MindControl_FireLoop_BP_C.BP_Init // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void CancelFireLoop(); // Function Creature_MindControl_FireLoop_BP.Creature_MindControl_FireLoop_BP_C.CancelFireLoop // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BP_PostInit(); // Function Creature_MindControl_FireLoop_BP.Creature_MindControl_FireLoop_BP_C.BP_PostInit // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void UpdatePreviewLastHitResult(); // Function Creature_MindControl_FireLoop_BP.Creature_MindControl_FireLoop_BP_C.UpdatePreviewLastHitResult // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_MindControl_FireLoop_BP(int32_t EntryPoint); // Function Creature_MindControl_FireLoop_BP.Creature_MindControl_FireLoop_BP_C.ExecuteUbergraph_Creature_MindControl_FireLoop_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

