// BlueprintGeneratedClass AttachedProximityMineDamage_GE.AttachedProximityMineDamage_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UAttachedProximityMineDamage_GE_C : UORGameplayEffect {
};

