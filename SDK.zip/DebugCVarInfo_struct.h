// UserDefinedStruct DebugCVarInfo.DebugCVarInfo
// Size: 0x10 (Inherited: 0x00)
struct FDebugCVarInfo {
	struct TArray<struct FString> CVars_7_0BB59D8B4E10565C32B76BBBDE123B1F; // 0x00(0x10)
};

