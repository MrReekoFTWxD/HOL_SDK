// BlueprintGeneratedClass Creature_PrimaryUpgrade_Payload.Creature_PrimaryUpgrade_Payload_C
// Size: 0x50 (Inherited: 0x50)
struct UCreature_PrimaryUpgrade_Payload_C : UORItemEquipPayload_ItemEffects {
};

