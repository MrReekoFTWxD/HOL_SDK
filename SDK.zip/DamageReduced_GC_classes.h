// BlueprintGeneratedClass DamageReduced_GC.DamageReduced_GC_C
// Size: 0x40 (Inherited: 0x40)
struct UDamageReduced_GC_C : UGameplayCueNotify_Static {

	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function DamageReduced_GC.DamageReduced_GC_C.OnExecute // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1953910
};

