// BlueprintGeneratedClass CreaturePheromoneMarker_BP.CreaturePheromoneMarker_BP_C
// Size: 0x250 (Inherited: 0x240)
struct ACreaturePheromoneMarker_BP_C : AORCreaturePheromoneMarker {
	struct UBillboardComponent* Billboard; // 0x240(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x248(0x08)
};

