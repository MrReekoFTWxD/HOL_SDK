// BlueprintGeneratedClass BTS_FocusTargetActorInRange.BTS_FocusTargetActorInRange_C
// Size: 0xd4 (Inherited: 0x98)
struct UBTS_FocusTargetActorInRange_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	struct FBlackboardKeySelector TargetActorKey; // 0xa0(0x28)
	bool ClearFocusOnDeactivation; // 0xc8(0x01)
	char pad_C9[0x3]; // 0xc9(0x03)
	float ActivationDelay; // 0xcc(0x04)
	float TimeSinceActivation; // 0xd0(0x04)

	void UpdateControllerFocus(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_FocusTargetActorInRange.BTS_FocusTargetActorInRange_C.UpdateControllerFocus // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_FocusTargetActorInRange.BTS_FocusTargetActorInRange_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_FocusTargetActorInRange.BTS_FocusTargetActorInRange_C.ReceiveDeactivationAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_FocusTargetActorInRange.BTS_FocusTargetActorInRange_C.ReceiveActivationAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTS_FocusTargetActorInRange(int32_t EntryPoint); // Function BTS_FocusTargetActorInRange.BTS_FocusTargetActorInRange_C.ExecuteUbergraph_BTS_FocusTargetActorInRange // (Final|UbergraphFunction) // @ game+0x1953910
};

