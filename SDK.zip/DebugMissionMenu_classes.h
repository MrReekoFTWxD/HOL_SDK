// WidgetBlueprintGeneratedClass DebugMissionMenu.DebugMissionMenu_C
// Size: 0x3d0 (Inherited: 0x3b1)
struct UDebugMissionMenu_C : UDebugMenu_C {
	char pad_3B1[0x7]; // 0x3b1(0x07)
	struct UDebugObjectiveMenu_C* DebugObjectiveMenu; // 0x3b8(0x08)
	struct UGridPanel* Grid; // 0x3c0(0x08)
	struct UScrollBox* MissionScrollbox; // 0x3c8(0x08)

	void ShowElements(bool bShow); // Function DebugMissionMenu.DebugMissionMenu_C.ShowElements // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OpenObjectiveMenu(struct FGameplayTag MissionTag); // Function DebugMissionMenu.DebugMissionMenu_C.OpenObjectiveMenu // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugMissionMenu.DebugMissionMenu_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Initialize(); // Function DebugMissionMenu.DebugMissionMenu_C.Initialize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AddMissionElements(); // Function DebugMissionMenu.DebugMissionMenu_C.AddMissionElements // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

