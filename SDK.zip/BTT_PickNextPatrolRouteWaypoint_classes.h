// BlueprintGeneratedClass BTT_PickNextPatrolRouteWaypoint.BTT_PickNextPatrolRouteWaypoint_C
// Size: 0x104 (Inherited: 0xa8)
struct UBTT_PickNextPatrolRouteWaypoint_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct FBlackboardKeySelector NewPatrolMoveLocationKey; // 0xb0(0x28)
	struct FBlackboardKeySelector NewPatrolWaitAtWaypointKey; // 0xd8(0x28)
	int32_t LastPatrolWaypointIdx; // 0x100(0x04)

	void HandleReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, bool& Success); // Function BTT_PickNextPatrolRouteWaypoint.BTT_PickNextPatrolRouteWaypoint_C.HandleReceiveExecuteAI // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_PickNextPatrolRouteWaypoint.BTT_PickNextPatrolRouteWaypoint_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTT_PickNextPatrolRouteWaypoint(int32_t EntryPoint); // Function BTT_PickNextPatrolRouteWaypoint.BTT_PickNextPatrolRouteWaypoint_C.ExecuteUbergraph_BTT_PickNextPatrolRouteWaypoint // (Final|UbergraphFunction) // @ game+0x1953910
};

