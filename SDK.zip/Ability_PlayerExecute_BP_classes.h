// BlueprintGeneratedClass Ability_PlayerExecute_BP.Ability_PlayerExecute_BP_C
// Size: 0x47c (Inherited: 0x428)
struct UAbility_PlayerExecute_BP_C : UORGameplayAbility_PlayerExecute {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x428(0x08)
	struct AORAICharacter* Target Character; // 0x430(0x08)
	struct TArray<struct UGameplayEffect*> PlayerGameplayEffects; // 0x438(0x10)
	struct TArray<struct UGameplayEffect*> TargetGameplayEffects; // 0x448(0x10)
	struct FGameplayTagContainer Damage Tags; // 0x458(0x20)
	float Execution Damage; // 0x478(0x04)

	void OnExecutionCompleted(); // Function Ability_PlayerExecute_BP.Ability_PlayerExecute_BP_C.OnExecutionCompleted // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnExecutionStart(struct AORAICharacter* TargetCharacter); // Function Ability_PlayerExecute_BP.Ability_PlayerExecute_BP_C.OnExecutionStart // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Ability_PlayerExecute_BP(int32_t EntryPoint); // Function Ability_PlayerExecute_BP.Ability_PlayerExecute_BP_C.ExecuteUbergraph_Ability_PlayerExecute_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

