// BlueprintGeneratedClass EnemyGrenade_Damage_Effect.EnemyGrenade_Damage_Effect_C
// Size: 0x818 (Inherited: 0x818)
struct UEnemyGrenade_Damage_Effect_C : UORGameplayEffect {
};

