// BlueprintGeneratedClass DebugMenuText.DebugMenuText_C
// Size: 0x2b0 (Inherited: 0x2b0)
struct UDebugMenuText_C : UTextBlock {
};

