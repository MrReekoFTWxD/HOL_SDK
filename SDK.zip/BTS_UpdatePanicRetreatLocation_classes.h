// BlueprintGeneratedClass BTS_UpdatePanicRetreatLocation.BTS_UpdatePanicRetreatLocation_C
// Size: 0xe0 (Inherited: 0x98)
struct UBTS_UpdatePanicRetreatLocation_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	struct FBlackboardKeySelector MoveToLocation; // 0xa0(0x28)
	bool IsQueryRunning; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)
	struct UEnvQueryInstanceBlueprintWrapper* RunningEQSQuery; // 0xd0(0x08)
	struct AAIController* OwnedController; // 0xd8(0x08)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_UpdatePanicRetreatLocation.BTS_UpdatePanicRetreatLocation_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void EQS_QueryComplete(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus); // Function BTS_UpdatePanicRetreatLocation.BTS_UpdatePanicRetreatLocation_C.EQS_QueryComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_UpdatePanicRetreatLocation.BTS_UpdatePanicRetreatLocation_C.ReceiveDeactivationAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTS_UpdatePanicRetreatLocation(int32_t EntryPoint); // Function BTS_UpdatePanicRetreatLocation.BTS_UpdatePanicRetreatLocation_C.ExecuteUbergraph_BTS_UpdatePanicRetreatLocation // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

