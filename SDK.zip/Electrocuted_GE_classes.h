// BlueprintGeneratedClass Electrocuted_GE.Electrocuted_GE_C
// Size: 0x810 (Inherited: 0x810)
struct UElectrocuted_GE_C : UGameplayEffect {
};

