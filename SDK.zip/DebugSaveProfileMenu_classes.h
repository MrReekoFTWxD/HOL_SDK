// WidgetBlueprintGeneratedClass DebugSaveProfileMenu.DebugSaveProfileMenu_C
// Size: 0x3d0 (Inherited: 0x3b1)
struct UDebugSaveProfileMenu_C : UDebugMenu_C {
	char pad_3B1[0x7]; // 0x3b1(0x07)
	struct UGridPanel* Grid; // 0x3b8(0x08)
	struct TArray<struct FString> SaveProfiles; // 0x3c0(0x10)

	void InitSaveProfiles(); // Function DebugSaveProfileMenu.DebugSaveProfileMenu_C.InitSaveProfiles // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugSaveProfileMenu.DebugSaveProfileMenu_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Initialize(); // Function DebugSaveProfileMenu.DebugSaveProfileMenu_C.Initialize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

