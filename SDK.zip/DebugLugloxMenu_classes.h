// WidgetBlueprintGeneratedClass DebugLugloxMenu.DebugLugloxMenu_C
// Size: 0x434 (Inherited: 0x3b1)
struct UDebugLugloxMenu_C : UDebugMenu_C {
	char pad_3B1[0x7]; // 0x3b1(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3b8(0x08)
	struct UGridPanel* Grid; // 0x3c0(0x08)
	struct UDebugMenuMissionLabel_C* LugloxButtonsLabel; // 0x3c8(0x08)
	struct TMap<struct FGameplayTag, struct FDataTableRowHandleArray> LugloxRewardsByMission; // 0x3d0(0x50)
	struct UDataTable* LugloxRewardsDataTable; // 0x420(0x08)
	int32_t InstructionsColumn; // 0x428(0x04)
	int32_t CollectAllButtonColumn; // 0x42c(0x04)
	int32_t CollectUpToButtonColumn; // 0x430(0x04)

	void AddMissionCollectAllButtons(); // Function DebugLugloxMenu.DebugLugloxMenu_C.AddMissionCollectAllButtons // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AddCollectUpToButtons(); // Function DebugLugloxMenu.DebugLugloxMenu_C.AddCollectUpToButtons // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AddLugloxButton(struct FText Text, struct TArray<struct FGameplayTag>& MissionTags, int32_t Row, int32_t Column); // Function DebugLugloxMenu.DebugLugloxMenu_C.AddLugloxButton // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AddRewardRowHandleForMission(struct FGameplayTag MissionTag, struct FDataTableRowHandle DataTableRowHandle); // Function DebugLugloxMenu.DebugLugloxMenu_C.AddRewardRowHandleForMission // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CacheLugloxRewardsByMission(); // Function DebugLugloxMenu.DebugLugloxMenu_C.CacheLugloxRewardsByMission // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Initialize(); // Function DebugLugloxMenu.DebugLugloxMenu_C.Initialize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CreateGridLabels(); // Function DebugLugloxMenu.DebugLugloxMenu_C.CreateGridLabels // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AddCollectAllButtons(); // Function DebugLugloxMenu.DebugLugloxMenu_C.AddCollectAllButtons // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugLugloxMenu(int32_t EntryPoint); // Function DebugLugloxMenu.DebugLugloxMenu_C.ExecuteUbergraph_DebugLugloxMenu // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

