// BlueprintGeneratedClass ActivateOnAppliedGETag_GA.ActivateOnAppliedGETag_GA_C
// Size: 0x480 (Inherited: 0x3f8)
struct UActivateOnAppliedGETag_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	int32_t StacksToConsume; // 0x400(0x04)
	char pad_404[0x4]; // 0x404(0x04)
	struct FGameplayTagContainer RequiredGETags; // 0x408(0x20)
	struct FGameplayTagContainer AssetTagToConsume; // 0x428(0x20)
	struct AActor* ActivationSource; // 0x448(0x08)
	struct FGameplayEffectSpecHandle ActivationSpecHandle; // 0x450(0x10)
	struct FGameplayTagContainer IgnoredGETags; // 0x460(0x20)

	void OnEffectApplied_57C2DC75421B4EF1205EA583C33EF7C1(struct FActiveGameplayEffectHandle ActiveEffectHandle, struct FGameplayEffectSpecHandle EffectSpecHandle); // Function ActivateOnAppliedGETag_GA.ActivateOnAppliedGETag_GA_C.OnEffectApplied_57C2DC75421B4EF1205EA583C33EF7C1 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_CommitExecute(); // Function ActivateOnAppliedGETag_GA.ActivateOnAppliedGETag_GA_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function ActivateOnAppliedGETag_GA.ActivateOnAppliedGETag_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_ActivateOnAppliedGETag_GA(int32_t EntryPoint); // Function ActivateOnAppliedGETag_GA.ActivateOnAppliedGETag_GA_C.ExecuteUbergraph_ActivateOnAppliedGETag_GA // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

