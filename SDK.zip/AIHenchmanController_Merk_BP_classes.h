// BlueprintGeneratedClass AIHenchmanController_Merk_BP.AIHenchmanController_Merk_BP_C
// Size: 0x8d8 (Inherited: 0x8c2)
struct AAIHenchmanController_Merk_BP_C : AORAIHenchmanController_BP_C {
	char pad_8C2[0x2]; // 0x8c2(0x02)
	struct FGameplayTag EventNDCharging; // 0x8c4(0x08)
	bool HasNotRetreated; // 0x8cc(0x01)
	char pad_8CD[0x3]; // 0x8cd(0x03)
	float RetreatHealthPercent; // 0x8d0(0x04)
	float RetreatTime; // 0x8d4(0x04)
};

