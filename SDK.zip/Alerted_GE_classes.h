// BlueprintGeneratedClass Alerted_GE.Alerted_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UAlerted_GE_C : UORGameplayEffect {
};

