// BlueprintGeneratedClass Ability_AltReload_BP.Ability_AltReload_BP_C
// Size: 0x428 (Inherited: 0x428)
struct UAbility_AltReload_BP_C : UORGameplayAbility_FireItem {
};

