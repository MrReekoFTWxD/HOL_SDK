// BlueprintGeneratedClass BTS_UnsetTargetWhenTargetInvalid.BTS_UnsetTargetWhenTargetInvalid_C
// Size: 0xc8 (Inherited: 0x98)
struct UBTS_UnsetTargetWhenTargetInvalid_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	struct FBlackboardKeySelector TargetKey; // 0xa0(0x28)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_UnsetTargetWhenTargetInvalid.BTS_UnsetTargetWhenTargetInvalid_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTS_UnsetTargetWhenTargetInvalid(int32_t EntryPoint); // Function BTS_UnsetTargetWhenTargetInvalid.BTS_UnsetTargetWhenTargetInvalid_C.ExecuteUbergraph_BTS_UnsetTargetWhenTargetInvalid // (Final|UbergraphFunction) // @ game+0x1953910
};

