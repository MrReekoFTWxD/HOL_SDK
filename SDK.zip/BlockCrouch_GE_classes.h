// BlueprintGeneratedClass BlockCrouch_GE.BlockCrouch_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UBlockCrouch_GE_C : UORGameplayEffect {
};

