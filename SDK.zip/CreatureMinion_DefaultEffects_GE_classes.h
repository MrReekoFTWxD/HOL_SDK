// BlueprintGeneratedClass CreatureMinion_DefaultEffects_GE.CreatureMinion_DefaultEffects_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreatureMinion_DefaultEffects_GE_C : UORGameplayEffect {
};

