// BlueprintGeneratedClass Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C
// Size: 0x46c (Inherited: 0x429)
struct UChonk_ExitMonsterCloset_GA_C : UOREnemy_ExitMonsterCloset_GA_C {
	char pad_429[0x7]; // 0x429(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x430(0x08)
	enum class EORAIHostileAwareness CachedAwarenessState; // 0x438(0x01)
	char pad_439[0x3]; // 0x439(0x03)
	float CachedGravityScale; // 0x43c(0x04)
	struct TArray<enum class ECollisionResponse> CachedCollisionResponse; // 0x440(0x10)
	struct TArray<enum class ECollisionChannel> JumpCollisionChannelsToModify; // 0x450(0x10)
	bool CollisionResponsesCached; // 0x460(0x01)
	char pad_461[0x3]; // 0x461(0x03)
	struct FActiveGameplayEffectHandle ImmunityGE; // 0x464(0x08)

	void ActivateJumpCollision(bool Activate); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.ActivateJumpCollision // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCancelled_C10F6DBF44BF0025A7FA0C92D294DD9D(); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.OnCancelled_C10F6DBF44BF0025A7FA0C92D294DD9D // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnInterrupted_C10F6DBF44BF0025A7FA0C92D294DD9D(); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.OnInterrupted_C10F6DBF44BF0025A7FA0C92D294DD9D // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnBlendOut_C10F6DBF44BF0025A7FA0C92D294DD9D(); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.OnBlendOut_C10F6DBF44BF0025A7FA0C92D294DD9D // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_C10F6DBF44BF0025A7FA0C92D294DD9D(); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.OnCompleted_C10F6DBF44BF0025A7FA0C92D294DD9D // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void K2_CommitExecute(); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void CharacterLanded(struct FHitResult& Hit); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.CharacterLanded // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Chonk_ExitMonsterCloset_GA(int32_t EntryPoint); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.ExecuteUbergraph_Chonk_ExitMonsterCloset_GA // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

