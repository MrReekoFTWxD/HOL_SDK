// BlueprintGeneratedClass Creature_Primary_EggMinionPhysics_Projectile_BP.Creature_Primary_EggMinionPhysics_Projectile_BP_C
// Size: 0x4d9 (Inherited: 0x4cc)
struct ACreature_Primary_EggMinionPhysics_Projectile_BP_C : ACreature_Primary_MinionFire_Projectile_BP_C {
	char pad_4CC[0x4]; // 0x4cc(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4d0(0x08)
	bool ExplodeOnBounce; // 0x4d8(0x01)

	void BndEvt__MovementComp_K2Node_ComponentBoundEvent_1_OnProjectileBounceDelegate__DelegateSignature(struct FHitResult& ImpactResult, struct FVector& ImpactVelocity); // Function Creature_Primary_EggMinionPhysics_Projectile_BP.Creature_Primary_EggMinionPhysics_Projectile_BP_C.BndEvt__MovementComp_K2Node_ComponentBoundEvent_1_OnProjectileBounceDelegate__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_Primary_EggMinionPhysics_Projectile_BP(int32_t EntryPoint); // Function Creature_Primary_EggMinionPhysics_Projectile_BP.Creature_Primary_EggMinionPhysics_Projectile_BP_C.ExecuteUbergraph_Creature_Primary_EggMinionPhysics_Projectile_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

