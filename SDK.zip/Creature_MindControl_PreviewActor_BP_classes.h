// BlueprintGeneratedClass Creature_MindControl_PreviewActor_BP.Creature_MindControl_PreviewActor_BP_C
// Size: 0x298 (Inherited: 0x270)
struct ACreature_MindControl_PreviewActor_BP_C : AORTrajectoryPreviewActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x270(0x08)
	struct USkeletalMeshComponent* MissMinionPreview; // 0x278(0x08)
	struct USkeletalMeshComponent* HitMinionPreview; // 0x280(0x08)
	struct TArray<struct AActor*> MinionInteractableClasses; // 0x288(0x10)

	void IsMinionInteractableTarget(struct AActor* TargetActor, bool& IsMinionInteractableTarget); // Function Creature_MindControl_PreviewActor_BP.Creature_MindControl_PreviewActor_BP_C.IsMinionInteractableTarget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void BP_UpdatePreview(); // Function Creature_MindControl_PreviewActor_BP.Creature_MindControl_PreviewActor_BP_C.BP_UpdatePreview // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_MindControl_PreviewActor_BP(int32_t EntryPoint); // Function Creature_MindControl_PreviewActor_BP.Creature_MindControl_PreviewActor_BP_C.ExecuteUbergraph_Creature_MindControl_PreviewActor_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

