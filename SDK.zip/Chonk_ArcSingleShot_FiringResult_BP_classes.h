// BlueprintGeneratedClass Chonk_ArcSingleShot_FiringResult_BP.Chonk_ArcSingleShot_FiringResult_BP_C
// Size: 0x358 (Inherited: 0x358)
struct UChonk_ArcSingleShot_FiringResult_BP_C : UORFiringResult_ArcProjectile {
};

