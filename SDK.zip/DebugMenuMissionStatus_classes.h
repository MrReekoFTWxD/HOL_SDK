// WidgetBlueprintGeneratedClass DebugMenuMissionStatus.DebugMenuMissionStatus_C
// Size: 0x2d0 (Inherited: 0x290)
struct UDebugMenuMissionStatus_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UORWidget_Button_BP_C* ORWidget_Button_BP; // 0x298(0x08)
	struct FText Status; // 0x2a0(0x18)
	struct UDebugUI_C* DebugUI; // 0x2b8(0x08)
	struct FGameplayTag MissionTag; // 0x2c0(0x08)
	struct UDebugMissionMenu_C* ParentMissionMenu; // 0x2c8(0x08)

	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugMenuMissionStatus.DebugMenuMissionStatus_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetStatus(struct FText NewStatus); // Function DebugMenuMissionStatus.DebugMenuMissionStatus_C.SetStatus // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AddObjectiveMenu(); // Function DebugMenuMissionStatus.DebugMenuMissionStatus_C.AddObjectiveMenu // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function DebugMenuMissionStatus.DebugMenuMissionStatus_C.BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugMenuMissionStatus(int32_t EntryPoint); // Function DebugMenuMissionStatus.DebugMenuMissionStatus_C.ExecuteUbergraph_DebugMenuMissionStatus // (Final|UbergraphFunction) // @ game+0x1953910
};

