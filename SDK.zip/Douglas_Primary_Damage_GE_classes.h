// BlueprintGeneratedClass Douglas_Primary_Damage_GE.Douglas_Primary_Damage_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UDouglas_Primary_Damage_GE_C : UGus_DamageAndBounce_GE_C {
};

