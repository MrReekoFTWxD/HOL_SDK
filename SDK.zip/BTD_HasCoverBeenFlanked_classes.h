// BlueprintGeneratedClass BTD_HasCoverBeenFlanked.BTD_HasCoverBeenFlanked_C
// Size: 0xd0 (Inherited: 0xa0)
struct UBTD_HasCoverBeenFlanked_C : UBTDecorator_BlueprintBase {
	struct FBlackboardKeySelector TargetLastKnownLocationBBKey; // 0xa0(0x28)
	float MinDistanceFromTarget; // 0xc8(0x04)
	float BreakOutDamage; // 0xcc(0x04)

	void IsAttractionPointInHomeArea(struct UObject* AttractionPoint, struct AORAIController* Controller, bool& Out); // Function BTD_HasCoverBeenFlanked.BTD_HasCoverBeenFlanked_C.IsAttractionPointInHomeArea // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_HasCoverBeenFlanked.BTD_HasCoverBeenFlanked_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

