// BlueprintGeneratedClass Douglas_InkProximityMine_BP.Douglas_InkProximityMine_BP_C
// Size: 0x350 (Inherited: 0x348)
struct ADouglas_InkProximityMine_BP_C : AProximityMine_BP_C {
	struct UStaticMeshComponent* StaticMesh; // 0x348(0x08)
};

