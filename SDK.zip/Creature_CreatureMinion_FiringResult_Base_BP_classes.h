// BlueprintGeneratedClass Creature_CreatureMinion_FiringResult_Base_BP.Creature_CreatureMinion_FiringResult_Base_BP_C
// Size: 0x2f8 (Inherited: 0x2e0)
struct UCreature_CreatureMinion_FiringResult_Base_BP_C : UORFiringResult_CreatureMindCon {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2e0(0x08)
	struct ACreature_MinionFire_Projectile_Base_BP_C* CreatureProjectile; // 0x2e8(0x08)
	struct AActor* TaskTargetActor; // 0x2f0(0x08)

	void BP_InitProjectile(struct ASQProjectile* Projectile); // Function Creature_CreatureMinion_FiringResult_Base_BP.Creature_CreatureMinion_FiringResult_Base_BP_C.BP_InitProjectile // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_CreatureMinion_FiringResult_Base_BP(int32_t EntryPoint); // Function Creature_CreatureMinion_FiringResult_Base_BP.Creature_CreatureMinion_FiringResult_Base_BP_C.ExecuteUbergraph_Creature_CreatureMinion_FiringResult_Base_BP // (Final|UbergraphFunction) // @ game+0x1953910
};

