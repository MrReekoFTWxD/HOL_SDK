// BlueprintGeneratedClass BTD_ImmortalMovementModeCheck.BTD_ImmortalMovementModeCheck_C
// Size: 0xa1 (Inherited: 0xa0)
struct UBTD_ImmortalMovementModeCheck_C : UBTDecorator_BlueprintBase {
	enum class E_ImmortalMovementMode MovementMode; // 0xa0(0x01)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_ImmortalMovementModeCheck.BTD_ImmortalMovementModeCheck_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

