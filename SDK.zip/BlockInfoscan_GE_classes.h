// BlueprintGeneratedClass BlockInfoscan_GE.BlockInfoscan_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UBlockInfoscan_GE_C : UORGameplayEffect {
};

