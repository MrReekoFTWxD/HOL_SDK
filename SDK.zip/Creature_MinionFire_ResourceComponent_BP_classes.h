// BlueprintGeneratedClass Creature_MinionFire_ResourceComponent_BP.Creature_MinionFire_ResourceComponent_BP_C
// Size: 0x180 (Inherited: 0x180)
struct UCreature_MinionFire_ResourceComponent_BP_C : UORResource_PlayerPrimaryFire {
};

