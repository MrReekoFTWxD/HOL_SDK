// BlueprintGeneratedClass CreatureMinion_Base_BP.CreatureMinion_Base_BP_C
// Size: 0x227c (Inherited: 0x20b0)
struct ACreatureMinion_Base_BP_C : AORAICreatureMinionCharacter {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x20b0(0x08)
	struct UORScannableComponent* ORScannable; // 0x20b8(0x08)
	struct UStaticMeshComponent* NecroMinionHealthTankMesh; // 0x20c0(0x08)
	struct UParticleSystemComponent* Trail; // 0x20c8(0x08)
	struct UStaticMeshComponent* AttackRadiusHelper; // 0x20d0(0x08)
	struct UORTriggerVolumeComponent* MeleeTriggerVolume; // 0x20d8(0x08)
	struct UORAkComponent* ORAk; // 0x20e0(0x08)
	struct UORStylizedDestroyerComponent* ORStylizedDestroyer; // 0x20e8(0x08)
	float Timeline_2_PhaseTrack_D182C1234D14991A752DA5BEF17AA3A6; // 0x20f0(0x04)
	enum class ETimelineDirection Timeline_2__Direction_D182C1234D14991A752DA5BEF17AA3A6; // 0x20f4(0x01)
	char pad_20F5[0x3]; // 0x20f5(0x03)
	struct UTimelineComponent* Timeline_3; // 0x20f8(0x08)
	struct AActor* CarriedActor; // 0x2100(0x08)
	struct AActor* ControllingActor; // 0x2108(0x08)
	struct UProgressBar* LifeProgressBar; // 0x2110(0x08)
	struct AActor* PoppinMinionsExplosionClass; // 0x2118(0x08)
	struct UGameplayEffect* MinionLatchedGE; // 0x2120(0x08)
	struct AORCharacter* LatchTarget; // 0x2128(0x08)
	struct FActiveGameplayEffectHandle DamageImmunityActiveGE; // 0x2130(0x08)
	struct FGameplayTag PoppinMinionsGlobalEventTag; // 0x2138(0x08)
	struct FGameplayTag OutWithABlastGlobalEventTag; // 0x2140(0x08)
	struct FGameplayTag NecroMinionGlobalEventTag; // 0x2148(0x08)
	struct FName IsAggessiveBBKey; // 0x2150(0x08)
	bool IsAggressive; // 0x2158(0x01)
	char pad_2159[0x3]; // 0x2159(0x03)
	struct FGameplayTag LatchImmunityTag; // 0x215c(0x08)
	char pad_2164[0x4]; // 0x2164(0x04)
	struct FGameplayTagContainer NonValidTargetTags; // 0x2168(0x20)
	struct UORGameplayEffect* NecroMinionBuffGE; // 0x2188(0x08)
	struct AORAICreatureMinionCharacter* NecroMinionClass; // 0x2190(0x08)
	struct UMaterialInstanceDynamic* CreatureBodyMaterialInstance; // 0x2198(0x08)
	struct FLinearColor MeanderNippleColor; // 0x21a0(0x10)
	struct FLinearColor AttackNippleColor; // 0x21b0(0x10)
	struct FLinearColor FrenzyNippleColor; // 0x21c0(0x10)
	struct FLinearColor MindControlNippleColor; // 0x21d0(0x10)
	struct FName CachedCurrentAttachedSocket; // 0x21e0(0x08)
	struct FTimerHandle AcidClearTimer; // 0x21e8(0x08)
	struct UParticleSystem* DeathFX; // 0x21f0(0x08)
	struct TArray<struct UMaterialInterface*> Blood Decal Materials; // 0x21f8(0x10)
	float AcidRemovalRadius; // 0x2208(0x04)
	struct FGameplayTag CreatureModTag; // 0x220c(0x08)
	char pad_2214[0x4]; // 0x2214(0x04)
	struct TMap<struct FGameplayTag, struct UParticleSystem*> DeathFXPerCreatureMod; // 0x2218(0x50)
	struct UMaterialInstance* CreatureModMaterial; // 0x2268(0x08)
	bool PlayDeathFX; // 0x2270(0x01)
	char pad_2271[0x3]; // 0x2271(0x03)
	float MaxNecroMinionHeal; // 0x2274(0x04)
	float NecroMinionHeal; // 0x2278(0x04)

	struct FVector GetEnemyEffectLocation(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.GetEnemyEffectLocation // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	float GetEnemyEffectRadius(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.GetEnemyEffectRadius // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetPlayerDamageBindingsEnabled(bool Enabled); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.SetPlayerDamageBindingsEnabled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetDeathFX(struct UParticleSystem*& DeathFX); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.GetDeathFX // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetCreatureMod(struct FGameplayTag CreatureModTag, struct UMaterialInstance* CreatureModMaterial); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.SetCreatureMod // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetCurrentAttachedSocket(struct FName CurrentAttachedSocket); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.SetCurrentAttachedSocket // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetCurrentAttachedSocket(struct FName& CurrentAttachedSocket); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.GetCurrentAttachedSocket // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void CreatureMinionTaskChanged(struct AORAICreatureMinionController* CreatureMinionController, enum class EORCreatureMinionTask OldTask, enum class EORCreatureMinionTask NewTask); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.CreatureMinionTaskChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void NecroMinionBuffActive(bool& Equipped); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.NecroMinionBuffActive // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void CanTriggerNecroMinionsMod(bool& Equipped); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.CanTriggerNecroMinionsMod // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void TriggerNecroMinion(struct AORAICharacter* KilledTarget); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.TriggerNecroMinion // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CanTriggerPoppinMinionsMod(bool& Equipped); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.CanTriggerPoppinMinionsMod // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void TriggerPoppinMinions(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.TriggerPoppinMinions // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CanTriggerOutWithABlastMod(bool& Equipped); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.CanTriggerOutWithABlastMod // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void SetIsAggressive(bool Aggressive); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.SetIsAggressive // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void IsValidAttackTarget(struct AORCharacter* ORCharacter, bool& IsValid); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.IsValidAttackTarget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void TryAttackPotentialTarget(struct AORCharacter* ORCharacter); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.TryAttackPotentialTarget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	float ModifyDamage(struct UObject* Damager, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.ModifyDamage // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CanLatchToCharacter(struct AORCharacter* ORCharacter, bool& IsValid); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.CanLatchToCharacter // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void LatchToCharacter(struct AORCharacter* Character); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.LatchToCharacter // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void TriggerOutWithABlast(bool& Success); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.TriggerOutWithABlast // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetControllingActor(struct AActor* ControllingActor); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.SetControllingActor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InitMaterialInstances(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.InitMaterialInstances // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Timeline_2__FinishedFunc(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.Timeline_2__FinishedFunc // (BlueprintEvent) // @ game+0x1953910
	void Timeline_2__UpdateFunc(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.Timeline_2__UpdateFunc // (BlueprintEvent) // @ game+0x1953910
	void OnNotifyEnd_5DA7CDB3475ABD80F7E9F3B548EFA953(struct FName NotifyName); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.OnNotifyEnd_5DA7CDB3475ABD80F7E9F3B548EFA953 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnNotifyBegin_5DA7CDB3475ABD80F7E9F3B548EFA953(struct FName NotifyName); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.OnNotifyBegin_5DA7CDB3475ABD80F7E9F3B548EFA953 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnInterrupted_5DA7CDB3475ABD80F7E9F3B548EFA953(struct FName NotifyName); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.OnInterrupted_5DA7CDB3475ABD80F7E9F3B548EFA953 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnBlendOut_5DA7CDB3475ABD80F7E9F3B548EFA953(struct FName NotifyName); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.OnBlendOut_5DA7CDB3475ABD80F7E9F3B548EFA953 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_5DA7CDB3475ABD80F7E9F3B548EFA953(struct FName NotifyName); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.OnCompleted_5DA7CDB3475ABD80F7E9F3B548EFA953 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void RecallMinion(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.RecallMinion // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void EnableTargetRecallEffects(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.EnableTargetRecallEffects // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void DisableTargetRecallEffects(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.DisableTargetRecallEffects // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnDied(struct UObject* Killer, struct FHitResult& HitResult, struct FGameplayTagContainer& DamageTags); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.OnDied // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1953910
	void OnDamageTaken(struct UObject* Damager, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.OnDamageTaken // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1953910
	void OnLanded(struct FHitResult& Hit); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.OnLanded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1953910
	void BP_CharacterLifeSpanExpired(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.BP_CharacterLifeSpanExpired // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void OnLifespanDecrease(float LifeSpan, float Percent); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.OnLifespanDecrease // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void Explode(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.Explode // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Sleep(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.Sleep // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Wake(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.Wake // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnPlayerInflictedDamaged(struct UObject* Damaged, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags, bool WasKillingBlow); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.OnPlayerInflictedDamaged // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ReceivePossessed(struct AController* NewController); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.ReceivePossessed // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ReceiveUnpossessed(struct AController* OldController); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.ReceiveUnpossessed // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ClearAcid(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.ClearAcid // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveDirectEvent(struct FGameplayTag Tag, struct UORGlobalEventPayload* Payload); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.ReceiveDirectEvent // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ClearEnemyEffect(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.ClearEnemyEffect // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void BP_SpawnedFromPool(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.BP_SpawnedFromPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnCreatureWeaponItemChanged(struct AORCreatureWeaponItem* NewCreatureWeaponItem); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.OnCreatureWeaponItemChanged // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void BP_ReturnedToPool(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.BP_ReturnedToPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ResetAcidRemovalTimer(); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.ResetAcidRemovalTimer // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_CreatureMinion_Base_BP(int32_t EntryPoint); // Function CreatureMinion_Base_BP.CreatureMinion_Base_BP_C.ExecuteUbergraph_CreatureMinion_Base_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

