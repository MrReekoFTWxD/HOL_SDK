// BlueprintGeneratedClass DisablePlayerFireableItemOnGazeReceived_GA.DisablePlayerFireableItemOnGazeReceived_GA_C
// Size: 0x418 (Inherited: 0x3f8)
struct UDisablePlayerFireableItemOnGazeReceived_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct TArray<struct AORFireableInventoryItem*> ItemsToDisable; // 0x400(0x10)
	struct AORCharacter* OwningCharacter; // 0x410(0x08)

	void GazeLost(struct UORGlobalEventPayload* Payload); // Function DisablePlayerFireableItemOnGazeReceived_GA.DisablePlayerFireableItemOnGazeReceived_GA_C.GazeLost // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GazeReceived(struct UORGlobalEventPayload* Payload); // Function DisablePlayerFireableItemOnGazeReceived_GA.DisablePlayerFireableItemOnGazeReceived_GA_C.GazeReceived // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function DisablePlayerFireableItemOnGazeReceived_GA.DisablePlayerFireableItemOnGazeReceived_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function DisablePlayerFireableItemOnGazeReceived_GA.DisablePlayerFireableItemOnGazeReceived_GA_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void K2_CommitExecute(); // Function DisablePlayerFireableItemOnGazeReceived_GA.DisablePlayerFireableItemOnGazeReceived_GA_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DisablePlayerFireableItemOnGazeReceived_GA(int32_t EntryPoint); // Function DisablePlayerFireableItemOnGazeReceived_GA.DisablePlayerFireableItemOnGazeReceived_GA_C.ExecuteUbergraph_DisablePlayerFireableItemOnGazeReceived_GA // (Final|UbergraphFunction) // @ game+0x1953910
};

