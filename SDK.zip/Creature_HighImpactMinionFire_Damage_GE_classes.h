// BlueprintGeneratedClass Creature_HighImpactMinionFire_Damage_GE.Creature_HighImpactMinionFire_Damage_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreature_HighImpactMinionFire_Damage_GE_C : UORGameplayEffect {
};

