// BlueprintGeneratedClass Creature_MindControl_FiringResult_BP.Creature_MindControl_FiringResult_BP_C
// Size: 0x3b0 (Inherited: 0x2f8)
struct UCreature_MindControl_FiringResult_BP_C : UCreature_CreatureMinion_FiringResult_Base_BP_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2f8(0x08)
	struct ACreature_Primary_MindControlMinion_Projectile_BP_C* MindControlProjectile; // 0x300(0x08)
	struct FGameplayTag ChargeFireloopMode; // 0x308(0x08)
	bool DoesCharge; // 0x310(0x01)
	char pad_311[0x3]; // 0x311(0x03)
	struct FHitResult PreviewLastHitResult; // 0x314(0x90)
	char pad_3A4[0x4]; // 0x3a4(0x04)
	struct USQProjectileMovementComponent* ProjectileMovementComp; // 0x3a8(0x08)

	struct ASQProjectile* GetProjectileType(); // Function Creature_MindControl_FiringResult_BP.Creature_MindControl_FiringResult_BP_C.GetProjectileType // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetSpawnTransform(struct FVector& OutLocation, struct FRotator& OutRotation, struct FVector& OutEffectsOffset, int32_t Shot, int32_t TotalShots, bool bUseOverrideLocation, struct FVector OverrideStartLocation); // Function Creature_MindControl_FiringResult_BP.Creature_MindControl_FiringResult_BP_C.GetSpawnTransform // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetFireLoop(struct UCreature_MindControl_FireLoop_BP_C*& FireLoop); // Function Creature_MindControl_FiringResult_BP.Creature_MindControl_FiringResult_BP_C.GetFireLoop // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BP_InitProjectile(struct ASQProjectile* Projectile); // Function Creature_MindControl_FiringResult_BP.Creature_MindControl_FiringResult_BP_C.BP_InitProjectile // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_MindControl_FiringResult_BP(int32_t EntryPoint); // Function Creature_MindControl_FiringResult_BP.Creature_MindControl_FiringResult_BP_C.ExecuteUbergraph_Creature_MindControl_FiringResult_BP // (Final|UbergraphFunction) // @ game+0x1953910
};

