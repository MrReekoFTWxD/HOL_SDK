// UserDefinedStruct ConfirmationWidgetData.ConfirmationWidgetData
// Size: 0xb9 (Inherited: 0x00)
struct FConfirmationWidgetData {
	struct FText TitleText_2_811099D0485D8857BED72FADFB0AF5A9; // 0x00(0x18)
	struct FText DescriptionText_4_0160E67D47EE2F39F81D418B78EA1DCE; // 0x18(0x18)
	struct FSlateBrush OptionalImage_8_ABDB90A1435D71A8A21C9CA18EB9B377; // 0x30(0x88)
	bool UseImage_10_4E31B6714E9646929BF9F2A000E93539; // 0xb8(0x01)
};

