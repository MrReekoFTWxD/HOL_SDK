// BlueprintGeneratedClass Cooldown_Myte_Bite_GE.Cooldown_Myte_Bite_GE_C
// Size: 0x810 (Inherited: 0x810)
struct UCooldown_Myte_Bite_GE_C : UGameplayEffect {
};

