// BlueprintGeneratedClass Chonk_EnemyMortar_FireLoop_Barrage_BP.Chonk_EnemyMortar_FireLoop_Barrage_BP_C
// Size: 0x13c (Inherited: 0x135)
struct UChonk_EnemyMortar_FireLoop_Barrage_BP_C : UORTestEnemyWeapons_FireLoop_C {
	char pad_135[0x3]; // 0x135(0x03)
	int32_t ChargeUpAKOnPlayer; // 0x138(0x04)

	void StopFireChargeUpSFX(); // Function Chonk_EnemyMortar_FireLoop_Barrage_BP.Chonk_EnemyMortar_FireLoop_Barrage_BP_C.StopFireChargeUpSFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void PlayFireChargeUpSFX(); // Function Chonk_EnemyMortar_FireLoop_Barrage_BP.Chonk_EnemyMortar_FireLoop_Barrage_BP_C.PlayFireChargeUpSFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

