// BlueprintGeneratedClass Chonk_IntroJump_ExplosionDamage_BP.Chonk_IntroJump_ExplosionDamage_BP_C
// Size: 0x460 (Inherited: 0x438)
struct AChonk_IntroJump_ExplosionDamage_BP_C : AORExplosionActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x438(0x08)
	struct UORAkComponent* ORAk; // 0x440(0x08)
	struct UNiagaraComponent* FX_ChonkGPFall; // 0x448(0x08)
	struct UMatineeCameraShake* Camera Shake; // 0x450(0x08)
	struct UAkAudioEvent* ExplosionAkEvent; // 0x458(0x08)

	void ReceiveBeginPlay(); // Function Chonk_IntroJump_ExplosionDamage_BP.Chonk_IntroJump_ExplosionDamage_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ReceiveDestroyed(); // Function Chonk_IntroJump_ExplosionDamage_BP.Chonk_IntroJump_ExplosionDamage_BP_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Chonk_IntroJump_ExplosionDamage_BP(int32_t EntryPoint); // Function Chonk_IntroJump_ExplosionDamage_BP.Chonk_IntroJump_ExplosionDamage_BP_C.ExecuteUbergraph_Chonk_IntroJump_ExplosionDamage_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

