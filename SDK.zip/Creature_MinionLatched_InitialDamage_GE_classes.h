// BlueprintGeneratedClass Creature_MinionLatched_InitialDamage_GE.Creature_MinionLatched_InitialDamage_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreature_MinionLatched_InitialDamage_GE_C : UORGameplayEffect {
};

