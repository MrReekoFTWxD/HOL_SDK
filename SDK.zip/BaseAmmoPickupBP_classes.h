// BlueprintGeneratedClass BaseAmmoPickupBP.BaseAmmoPickupBP_C
// Size: 0x320 (Inherited: 0x2d8)
struct ABaseAmmoPickupBP_C : AORAmmoPickup {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d8(0x08)
	enum class Relationships Weapon; // 0x2e0(0x01)
	bool PrimaryFire; // 0x2e1(0x01)
	bool PhysicsEnabled; // 0x2e2(0x01)
	char pad_2E3[0x5]; // 0x2e3(0x05)
	struct FMulticastInlineDelegate AmmoRecieved; // 0x2e8(0x30)
	struct FName ReloadAbilityName; // 0x318(0x08)

	void AttemptAutoReload(struct AORPlayerCharacter* Character, struct AORFireableInventoryItem* Item); // Function BaseAmmoPickupBP.BaseAmmoPickupBP_C.AttemptAutoReload // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function BaseAmmoPickupBP.BaseAmmoPickupBP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ReceivedAmmo(struct AORFireableInventoryItem* Item, struct AORPlayerCharacter* PlayerCharacter, int32_t AmmoPickedUP); // Function BaseAmmoPickupBP.BaseAmmoPickupBP_C.ReceivedAmmo // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BaseAmmoPickupBP(int32_t EntryPoint); // Function BaseAmmoPickupBP.BaseAmmoPickupBP_C.ExecuteUbergraph_BaseAmmoPickupBP // (Final|UbergraphFunction) // @ game+0x1953910
	void AmmoRecieved__DelegateSignature(); // Function BaseAmmoPickupBP.BaseAmmoPickupBP_C.AmmoRecieved__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

