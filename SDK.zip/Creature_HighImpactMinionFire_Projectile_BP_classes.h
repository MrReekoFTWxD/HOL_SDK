// BlueprintGeneratedClass Creature_HighImpactMinionFire_Projectile_BP.Creature_HighImpactMinionFire_Projectile_BP_C
// Size: 0x4b8 (Inherited: 0x400)
struct ACreature_HighImpactMinionFire_Projectile_BP_C : AORProjectile_PlayerProjectile_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x400(0x08)
	struct UORTriggerSourceComponent* ORTriggerSource; // 0x408(0x08)
	struct USkeletalMeshComponent* MinionMesh; // 0x410(0x08)
	struct UParticleSystemComponent* ParticleSystem_Trail; // 0x418(0x08)
	struct UORAkComponent* ORAk; // 0x420(0x08)
	struct UAkAudioEvent* ProjectileLoopSound; // 0x428(0x08)
	struct AORCreatureWeaponItem* CreatureWeaponItem; // 0x430(0x08)
	struct AActor* TaskTarget; // 0x438(0x08)
	bool CanSpawnCreatureMinion; // 0x440(0x01)
	bool CreatureMinionSpawned; // 0x441(0x01)
	char pad_442[0x6]; // 0x442(0x06)
	struct TMap<struct FGameplayTag, struct ACreatureMinion_Base_BP_C*> CreatureMinionClassToSpawn; // 0x448(0x50)
	struct ACreatureMinion_Base_BP_C* DefaultCreatureMinionClassToSpawn; // 0x498(0x08)
	struct FName IsAggessiveBBKey; // 0x4a0(0x08)
	struct FGameplayTag CreatureModTag; // 0x4a8(0x08)
	struct UMaterialInstance* CreatureModMaterial; // 0x4b0(0x08)

	void GetCreatureMinionClassToSpawn(struct ACreatureMinion_Base_BP_C*& CreatureMinionClass); // Function Creature_HighImpactMinionFire_Projectile_BP.Creature_HighImpactMinionFire_Projectile_BP_C.GetCreatureMinionClassToSpawn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void SetCreatureWeaponItem(struct AORCreatureWeaponItem* CreatureWeaponItem); // Function Creature_HighImpactMinionFire_Projectile_BP.Creature_HighImpactMinionFire_Projectile_BP_C.SetCreatureWeaponItem // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InitCreatureMinion(struct ACreatureMinion_Base_BP_C* CreatureMinion); // Function Creature_HighImpactMinionFire_Projectile_BP.Creature_HighImpactMinionFire_Projectile_BP_C.InitCreatureMinion // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void TrySpawnCreatureMinion(struct ACreatureMinion_Base_BP_C*& CreatureMinion); // Function Creature_HighImpactMinionFire_Projectile_BP.Creature_HighImpactMinionFire_Projectile_BP_C.TrySpawnCreatureMinion // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnSpawnedFromPool(); // Function Creature_HighImpactMinionFire_Projectile_BP.Creature_HighImpactMinionFire_Projectile_BP_C.OnSpawnedFromPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnReturnedToPool(); // Function Creature_HighImpactMinionFire_Projectile_BP.Creature_HighImpactMinionFire_Projectile_BP_C.OnReturnedToPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnImpact(struct FHitResult& ImpactResult); // Function Creature_HighImpactMinionFire_Projectile_BP.Creature_HighImpactMinionFire_Projectile_BP_C.OnImpact // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_HighImpactMinionFire_Projectile_BP(int32_t EntryPoint); // Function Creature_HighImpactMinionFire_Projectile_BP.Creature_HighImpactMinionFire_Projectile_BP_C.ExecuteUbergraph_Creature_HighImpactMinionFire_Projectile_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

