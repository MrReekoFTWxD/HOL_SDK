// BlueprintGeneratedClass Chonk_Stagger_GA.Chonk_Stagger_GA_C
// Size: 0x5b8 (Inherited: 0x59c)
struct UChonk_Stagger_GA_C : UBaseAICharacter_Stagger_GA_C {
	char pad_59C[0x4]; // 0x59c(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5a0(0x08)
	struct UAbilityTask_PlayMontageAndWait* DeepCutMontageTask; // 0x5a8(0x08)
	struct FGameplayTag BarrageAbilityTag; // 0x5b0(0x08)

	void TriggerNDEnemyStaggerLine(); // Function Chonk_Stagger_GA.Chonk_Stagger_GA_C.TriggerNDEnemyStaggerLine // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StopExistingMontage(); // Function Chonk_Stagger_GA.Chonk_Stagger_GA_C.StopExistingMontage // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCancelled_DF9EBB8F45A9B03E8AC1BBB5AC5567F5(); // Function Chonk_Stagger_GA.Chonk_Stagger_GA_C.OnCancelled_DF9EBB8F45A9B03E8AC1BBB5AC5567F5 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnInterrupted_DF9EBB8F45A9B03E8AC1BBB5AC5567F5(); // Function Chonk_Stagger_GA.Chonk_Stagger_GA_C.OnInterrupted_DF9EBB8F45A9B03E8AC1BBB5AC5567F5 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnBlendOut_DF9EBB8F45A9B03E8AC1BBB5AC5567F5(); // Function Chonk_Stagger_GA.Chonk_Stagger_GA_C.OnBlendOut_DF9EBB8F45A9B03E8AC1BBB5AC5567F5 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_DF9EBB8F45A9B03E8AC1BBB5AC5567F5(); // Function Chonk_Stagger_GA.Chonk_Stagger_GA_C.OnCompleted_DF9EBB8F45A9B03E8AC1BBB5AC5567F5 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCancelled_3D839B6D4B748B69A0C37D8AA506EF46(); // Function Chonk_Stagger_GA.Chonk_Stagger_GA_C.OnCancelled_3D839B6D4B748B69A0C37D8AA506EF46 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnInterrupted_3D839B6D4B748B69A0C37D8AA506EF46(); // Function Chonk_Stagger_GA.Chonk_Stagger_GA_C.OnInterrupted_3D839B6D4B748B69A0C37D8AA506EF46 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnBlendOut_3D839B6D4B748B69A0C37D8AA506EF46(); // Function Chonk_Stagger_GA.Chonk_Stagger_GA_C.OnBlendOut_3D839B6D4B748B69A0C37D8AA506EF46 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_3D839B6D4B748B69A0C37D8AA506EF46(); // Function Chonk_Stagger_GA.Chonk_Stagger_GA_C.OnCompleted_3D839B6D4B748B69A0C37D8AA506EF46 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_CommitExecute(); // Function Chonk_Stagger_GA.Chonk_Stagger_GA_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void LeaveStagger(); // Function Chonk_Stagger_GA.Chonk_Stagger_GA_C.LeaveStagger // (BlueprintEvent) // @ game+0x1953910
	void DeepCutTriggered(); // Function Chonk_Stagger_GA.Chonk_Stagger_GA_C.DeepCutTriggered // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StaggerTimerEnded(); // Function Chonk_Stagger_GA.Chonk_Stagger_GA_C.StaggerTimerEnded // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Chonk_Stagger_GA(int32_t EntryPoint); // Function Chonk_Stagger_GA.Chonk_Stagger_GA_C.ExecuteUbergraph_Chonk_Stagger_GA // (Final|UbergraphFunction) // @ game+0x1953910
};

