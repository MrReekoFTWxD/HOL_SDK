// BlueprintGeneratedClass Ability_UIToggleFreeLook_BP.Ability_UIToggleFreeLook_BP_C
// Size: 0x3f8 (Inherited: 0x3f8)
struct UAbility_UIToggleFreeLook_BP_C : UORGameplayAbility_ToggleFreeLook {
};

