// BlueprintGeneratedClass DeepCut_PlayerImmunities_GE.DeepCut_PlayerImmunities_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UDeepCut_PlayerImmunities_GE_C : UORGameplayEffect {
};

