// BlueprintGeneratedClass BlockDash_GE.BlockDash_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UBlockDash_GE_C : UORGameplayEffect {
};

