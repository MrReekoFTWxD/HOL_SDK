// BlueprintGeneratedClass Chonk_PublisherDemo_Intro_Hand_Slam_CameraShake.Chonk_PublisherDemo_Intro_Hand_Slam_CameraShake_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UChonk_PublisherDemo_Intro_Hand_Slam_CameraShake_C : UMatineeCameraShake {
};

