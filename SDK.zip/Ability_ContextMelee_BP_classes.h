// BlueprintGeneratedClass Ability_ContextMelee_BP.Ability_ContextMelee_BP_C
// Size: 0x408 (Inherited: 0x408)
struct UAbility_ContextMelee_BP_C : UORGameplayAbility_AbilityContextSwapping {
};

