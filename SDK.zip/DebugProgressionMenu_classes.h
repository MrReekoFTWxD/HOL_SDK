// WidgetBlueprintGeneratedClass DebugProgressionMenu.DebugProgressionMenu_C
// Size: 0x414 (Inherited: 0x3b1)
struct UDebugProgressionMenu_C : UDebugMenu_C {
	char pad_3B1[0x7]; // 0x3b1(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3b8(0x08)
	struct UGridPanel* Grid; // 0x3c0(0x08)
	struct UDebugMenuMissionLabel_C* SectionTitle; // 0x3c8(0x08)
	struct UDebugMenuMissionLabel_C* SectionDescription; // 0x3d0(0x08)
	struct TArray<struct UUserWidget*> SectionWidgets; // 0x3d8(0x10)
	enum class ProgressionReportSection_EN CurrentSection; // 0x3e8(0x01)
	bool ProgressionReport_RaiseErrors; // 0x3e9(0x01)
	char pad_3EA[0x2]; // 0x3ea(0x02)
	int32_t SectionContentFirstRow; // 0x3ec(0x04)
	struct UDebugMenu_ProgressionCategoryButton_C* RaiseErrorsButton; // 0x3f0(0x08)
	int32_t SectionContentFirstColumn; // 0x3f8(0x04)
	enum class InventoryItemCategory_EN CurrentItemCategory; // 0x3fc(0x01)
	char pad_3FD[0x3]; // 0x3fd(0x03)
	struct TArray<struct UUserWidget*> ItemDisplayWidgets; // 0x400(0x10)
	float CategoryButtonColumnFill; // 0x410(0x04)

	void ShowSection_PesosProgression(); // Function DebugProgressionMenu.DebugProgressionMenu_C.ShowSection_PesosProgression // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ShowSection_ItemCoverage_Items(bool AllItems); // Function DebugProgressionMenu.DebugProgressionMenu_C.ShowSection_ItemCoverage_Items // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ShowItemCategoryButtons(); // Function DebugProgressionMenu.DebugProgressionMenu_C.ShowItemCategoryButtons // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetRaiseErrorsButtonText(); // Function DebugProgressionMenu.DebugProgressionMenu_C.SetRaiseErrorsButtonText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Show Progression Report Status(bool& ShowCurrentSection, struct AORProgressionReport_BP_C*& ProgressionReport); // Function DebugProgressionMenu.DebugProgressionMenu_C.Show Progression Report Status // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ShowSection_ItemCoverage(); // Function DebugProgressionMenu.DebugProgressionMenu_C.ShowSection_ItemCoverage // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ShowSection_ItemsNotGranted_Items(bool AllItems); // Function DebugProgressionMenu.DebugProgressionMenu_C.ShowSection_ItemsNotGranted_Items // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ShowSection_ItemsNotGranted(); // Function DebugProgressionMenu.DebugProgressionMenu_C.ShowSection_ItemsNotGranted // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ShowSection_ValidationErrors(); // Function DebugProgressionMenu.DebugProgressionMenu_C.ShowSection_ValidationErrors // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ShowSection_ReportInProgress(); // Function DebugProgressionMenu.DebugProgressionMenu_C.ShowSection_ReportInProgress // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ShowSection_StartReport(); // Function DebugProgressionMenu.DebugProgressionMenu_C.ShowSection_StartReport // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AddSectionHeader(struct FString Title, struct FString Description, int32_t TitleRow, int32_t TitleColumn); // Function DebugProgressionMenu.DebugProgressionMenu_C.AddSectionHeader // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CreateMenuSectionColumn(); // Function DebugProgressionMenu.DebugProgressionMenu_C.CreateMenuSectionColumn // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Initialize(); // Function DebugProgressionMenu.DebugProgressionMenu_C.Initialize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetMenuSection(enum class ProgressionReportSection_EN Section); // Function DebugProgressionMenu.DebugProgressionMenu_C.SetMenuSection // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StartProgressionReport(enum class ProgressionReportSection_EN Section); // Function DebugProgressionMenu.DebugProgressionMenu_C.StartProgressionReport // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnProgressionReportComplete(struct AORProgressionReport_BP_C* Report); // Function DebugProgressionMenu.DebugProgressionMenu_C.OnProgressionReportComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnRaiseErrorsButtonClicked(enum class ProgressionReportSection_EN Section); // Function DebugProgressionMenu.DebugProgressionMenu_C.OnRaiseErrorsButtonClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCategoryButtonClicked(enum class InventoryItemCategory_EN Category); // Function DebugProgressionMenu.DebugProgressionMenu_C.OnCategoryButtonClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnShowAllItemsButtonClicked(); // Function DebugProgressionMenu.DebugProgressionMenu_C.OnShowAllItemsButtonClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnMissionButtonClicked(struct UORMission_BP_C* MissionConfig); // Function DebugProgressionMenu.DebugProgressionMenu_C.OnMissionButtonClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnAllMissionsButtonClicked(); // Function DebugProgressionMenu.DebugProgressionMenu_C.OnAllMissionsButtonClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnAct1MissionsButtonClicked(); // Function DebugProgressionMenu.DebugProgressionMenu_C.OnAct1MissionsButtonClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnAct2MissionsButtonClicked(); // Function DebugProgressionMenu.DebugProgressionMenu_C.OnAct2MissionsButtonClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnAct3MissionButtonsClicked(); // Function DebugProgressionMenu.DebugProgressionMenu_C.OnAct3MissionButtonsClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugProgressionMenu(int32_t EntryPoint); // Function DebugProgressionMenu.DebugProgressionMenu_C.ExecuteUbergraph_DebugProgressionMenu // (Final|UbergraphFunction) // @ game+0x1953910
};

