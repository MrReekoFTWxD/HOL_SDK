// BlueprintGeneratedClass Ability_PlayerTether_GE.Ability_PlayerTether_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UAbility_PlayerTether_GE_C : UORGameplayEffect {
};

