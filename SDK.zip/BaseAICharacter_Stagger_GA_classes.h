// BlueprintGeneratedClass BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C
// Size: 0x59c (Inherited: 0x480)
struct UBaseAICharacter_Stagger_GA_C : UActivateOnAppliedGETag_GA_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x480(0x08)
	struct AORAICharacter* OwnerAICharacter; // 0x488(0x08)
	struct AStagger_Melee_Interact_Prompt_BP_C* InteractPrompt; // 0x490(0x08)
	struct UORAbilityTask_WaitGameplayEffectApplied* Async Task; // 0x498(0x08)
	struct FGameplayTagRequirements StaggerTag; // 0x4a0(0x40)
	enum class EORAIStatusEffect StunStatus; // 0x4e0(0x01)
	char pad_4E1[0x3]; // 0x4e1(0x03)
	struct FName StatusEffectBBKey; // 0x4e4(0x08)
	float EndAbilityTimer; // 0x4ec(0x04)
	struct FTimerHandle AbilityEndTimerHandle; // 0x4f0(0x08)
	bool AbilityStarted; // 0x4f8(0x01)
	char pad_4F9[0x7]; // 0x4f9(0x07)
	struct FGameplayTagRequirements DeepcutTag; // 0x500(0x40)
	float DeepcutInteractRadius; // 0x540(0x04)
	struct FName CharactersHeadSocketName; // 0x544(0x08)
	char pad_54C[0x4]; // 0x54c(0x04)
	struct UNiagaraComponent* NiagaraStaggerFXInstance; // 0x550(0x08)
	struct UNiagaraSystem* NiagaraStaggerFXTemplate; // 0x558(0x08)
	float StaggerFXDuration; // 0x560(0x04)
	float StaggerFXRadiusSize; // 0x564(0x04)
	float StaggerFXStarSize; // 0x568(0x04)
	char pad_56C[0x4]; // 0x56c(0x04)
	struct UGameplayEffect* StaggeredGameplayEffectClass; // 0x570(0x08)
	bool DoesEndStaggerOnDeepcut; // 0x578(0x01)
	char pad_579[0x3]; // 0x579(0x03)
	struct FName OverrideDeepcutSocket; // 0x57c(0x08)
	char pad_584[0x4]; // 0x584(0x04)
	struct TArray<struct FName> SocketCache; // 0x588(0x10)
	float NDTriggerStaggerLineMaxDistance; // 0x598(0x04)

	void TriggerNDEnemyStaggerLine(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.TriggerNDEnemyStaggerLine // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ClearOverrideSocket(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.ClearOverrideSocket // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetOverrideSocket(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.SetOverrideSocket // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void HandleStaggerFXCustomSettings(struct UNiagaraComponent* StaggerFXInstance); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.HandleStaggerFXCustomSettings // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetStaggeredFXEnabled(bool Enabled); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.SetStaggeredFXEnabled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetAIStatusEffect(enum class EORAIStatusEffect NewStatusEffect); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.SetAIStatusEffect // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnEffectApplied_4B30CE0F4EA8886D752C7A844956F762(struct FActiveGameplayEffectHandle ActiveEffectHandle, struct FGameplayEffectSpecHandle EffectSpecHandle); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.OnEffectApplied_4B30CE0F4EA8886D752C7A844956F762 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnEffectApplied_65F2657D4CC203E18217CF988A825D0B(struct FActiveGameplayEffectHandle ActiveEffectHandle, struct FGameplayEffectSpecHandle EffectSpecHandle); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.OnEffectApplied_65F2657D4CC203E18217CF988A825D0B // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_E6EFFAD846C9B0FEBC64EB8734803303(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.OnCompleted_E6EFFAD846C9B0FEBC64EB8734803303 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnTick_E6EFFAD846C9B0FEBC64EB8734803303(float DeltaTime, float TotalElapsed); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.OnTick_E6EFFAD846C9B0FEBC64EB8734803303 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void K2_CommitExecute(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void StaggerCompleted(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.StaggerCompleted // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void DeepCutTriggered(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.DeepCutTriggered // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CharacterDied(struct AORAICharacter* Victim, struct UObject* Killer); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.CharacterDied // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void DisableDeepcut(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.DisableDeepcut // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StaggerTimerEnded(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.StaggerTimerEnded // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BaseAICharacter_Stagger_GA(int32_t EntryPoint); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.ExecuteUbergraph_BaseAICharacter_Stagger_GA // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

