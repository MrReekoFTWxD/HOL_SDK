// BlueprintGeneratedClass DebugMenuButton.DebugMenuButton_C
// Size: 0x4d0 (Inherited: 0x4d0)
struct UDebugMenuButton_C : UButton {
};

