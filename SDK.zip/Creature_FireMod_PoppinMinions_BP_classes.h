// BlueprintGeneratedClass Creature_FireMod_PoppinMinions_BP.Creature_FireMod_PoppinMinions_BP_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UCreature_FireMod_PoppinMinions_BP_C : UORItemEquipPayload_FiringOverride {
};

