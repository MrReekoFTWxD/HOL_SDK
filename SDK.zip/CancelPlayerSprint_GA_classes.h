// BlueprintGeneratedClass CancelPlayerSprint_GA.CancelPlayerSprint_GA_C
// Size: 0x400 (Inherited: 0x3f8)
struct UCancelPlayerSprint_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)

	void K2_ActivateAbility(); // Function CancelPlayerSprint_GA.CancelPlayerSprint_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_CancelPlayerSprint_GA(int32_t EntryPoint); // Function CancelPlayerSprint_GA.CancelPlayerSprint_GA_C.ExecuteUbergraph_CancelPlayerSprint_GA // (Final|UbergraphFunction) // @ game+0x1953910
};

