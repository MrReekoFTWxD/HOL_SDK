// BlueprintGeneratedClass BTD_CanUseCharacterAbilityOffCooldown.BTD_CanUseCharacterAbilityOffCooldown_C
// Size: 0xa8 (Inherited: 0xa0)
struct UBTD_CanUseCharacterAbilityOffCooldown_C : UBTDecorator_BlueprintBase {
	struct FGameplayTag CharacterAbilityTag; // 0xa0(0x08)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_CanUseCharacterAbilityOffCooldown.BTD_CanUseCharacterAbilityOffCooldown_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

