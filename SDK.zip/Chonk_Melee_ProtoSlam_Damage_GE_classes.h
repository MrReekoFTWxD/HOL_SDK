// BlueprintGeneratedClass Chonk_Melee_ProtoSlam_Damage_GE.Chonk_Melee_ProtoSlam_Damage_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UChonk_Melee_ProtoSlam_Damage_GE_C : UORGameplayEffect {
};

