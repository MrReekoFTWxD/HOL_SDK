// BlueprintGeneratedClass BTS_UpdateMeleeCombatLocation.BTS_UpdateMeleeCombatLocation_C
// Size: 0x100 (Inherited: 0x98)
struct UBTS_UpdateMeleeCombatLocation_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	struct FBlackboardKeySelector TargetActorKey; // 0xa0(0x28)
	struct FBlackboardKeySelector CombatMoveLocation; // 0xc8(0x28)
	struct AORCharacter* TargetORCharacter; // 0xf0(0x08)
	struct APawn* Controlled Pawn; // 0xf8(0x08)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_UpdateMeleeCombatLocation.BTS_UpdateMeleeCombatLocation_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_UpdateMeleeCombatLocation.BTS_UpdateMeleeCombatLocation_C.ReceiveActivationAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTS_UpdateMeleeCombatLocation(int32_t EntryPoint); // Function BTS_UpdateMeleeCombatLocation.BTS_UpdateMeleeCombatLocation_C.ExecuteUbergraph_BTS_UpdateMeleeCombatLocation // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

