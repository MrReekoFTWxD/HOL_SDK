// BlueprintGeneratedClass CanUseAbility_SecondaryFire.CanUseAbility_SecondaryFire_C
// Size: 0xc8 (Inherited: 0xc8)
struct UCanUseAbility_SecondaryFire_C : UUtilityConsideration {
};

