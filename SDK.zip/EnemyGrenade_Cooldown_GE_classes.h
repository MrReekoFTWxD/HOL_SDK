// BlueprintGeneratedClass EnemyGrenade_Cooldown_GE.EnemyGrenade_Cooldown_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UEnemyGrenade_Cooldown_GE_C : UORGameplayEffect {
};

