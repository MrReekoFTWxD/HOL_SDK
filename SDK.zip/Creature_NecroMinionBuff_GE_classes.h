// BlueprintGeneratedClass Creature_NecroMinionBuff_GE.Creature_NecroMinionBuff_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreature_NecroMinionBuff_GE_C : UORGameplayEffect {
};

