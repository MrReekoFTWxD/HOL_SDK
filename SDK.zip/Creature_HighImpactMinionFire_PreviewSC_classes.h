// BlueprintGeneratedClass Creature_HighImpactMinionFire_PreviewSC.Creature_HighImpactMinionFire_PreviewSC_C
// Size: 0x158 (Inherited: 0x158)
struct UCreature_HighImpactMinionFire_PreviewSC_C : UORFireableInventoryItemPreview {
};

