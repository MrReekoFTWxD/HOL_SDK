// BlueprintGeneratedClass ChangeCollisionWhileActive_GA.ChangeCollisionWhileActive_GA_C
// Size: 0x414 (Inherited: 0x3f8)
struct UChangeCollisionWhileActive_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct FName OldProfileName; // 0x400(0x08)
	enum class ECollisionEnabled OldCollision; // 0x408(0x01)
	char pad_409[0x3]; // 0x409(0x03)
	struct FName NewProfileName; // 0x40c(0x08)

	void K2_ActivateAbility(); // Function ChangeCollisionWhileActive_GA.ChangeCollisionWhileActive_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function ChangeCollisionWhileActive_GA.ChangeCollisionWhileActive_GA_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_ChangeCollisionWhileActive_GA(int32_t EntryPoint); // Function ChangeCollisionWhileActive_GA.ChangeCollisionWhileActive_GA_C.ExecuteUbergraph_ChangeCollisionWhileActive_GA // (Final|UbergraphFunction) // @ game+0x1953910
};

