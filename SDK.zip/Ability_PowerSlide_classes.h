// BlueprintGeneratedClass Ability_PowerSlide.Ability_PowerSlide_C
// Size: 0x420 (Inherited: 0x3f8)
struct UAbility_PowerSlide_C : UORGameplayAbility_PowerSlide {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct UMaterialInstance* SpeedLinesMaterial; // 0x400(0x08)
	struct UCameraShakeBase* SlidingCameraShake; // 0x408(0x08)
	struct UCameraShakeBase* ImpactCameraShake; // 0x410(0x08)
	struct UAkAudioEvent* ImpactSFX; // 0x418(0x08)

	void GetCameraManager(struct AORPlayerCameraManager*& CameraManager); // Function Ability_PowerSlide.Ability_PowerSlide_C.GetCameraManager // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void EventReceived_8B92170A42AFC0058D8C9B95BD1EF44F(struct FGameplayEventData Payload); // Function Ability_PowerSlide.Ability_PowerSlide_C.EventReceived_8B92170A42AFC0058D8C9B95BD1EF44F // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnHeavyImpact(); // Function Ability_PowerSlide.Ability_PowerSlide_C.OnHeavyImpact // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function Ability_PowerSlide.Ability_PowerSlide_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function Ability_PowerSlide.Ability_PowerSlide_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Ability_PowerSlide(int32_t EntryPoint); // Function Ability_PowerSlide.Ability_PowerSlide_C.ExecuteUbergraph_Ability_PowerSlide // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

