// BlueprintGeneratedClass Chonk_Melee_ProtoSlam_GA.Chonk_Melee_ProtoSlam_GA_C
// Size: 0x4c1 (Inherited: 0x4a8)
struct UChonk_Melee_ProtoSlam_GA_C : UOREnemy_Melee_GA_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4a8(0x08)
	struct FGameplayTag GlobalEventTag; // 0x4b0(0x08)
	struct AActor* Preview Actor; // 0x4b8(0x08)
	bool InflictedDamage; // 0x4c0(0x01)

	struct FTransform GetCasterTransform(); // Function Chonk_Melee_ProtoSlam_GA.Chonk_Melee_ProtoSlam_GA_C.GetCasterTransform // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void SpawnPreviewActor(struct AActor*& PreviewActor); // Function Chonk_Melee_ProtoSlam_GA.Chonk_Melee_ProtoSlam_GA_C.SpawnPreviewActor // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function Chonk_Melee_ProtoSlam_GA.Chonk_Melee_ProtoSlam_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnGlobalEvent(struct UORGlobalEventPayload* EventData); // Function Chonk_Melee_ProtoSlam_GA.Chonk_Melee_ProtoSlam_GA_C.OnGlobalEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function Chonk_Melee_ProtoSlam_GA.Chonk_Melee_ProtoSlam_GA_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void DamageInflicted(struct UObject* Damaged, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags, bool WasKillingBlow); // Function Chonk_Melee_ProtoSlam_GA.Chonk_Melee_ProtoSlam_GA_C.DamageInflicted // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Chonk_Melee_ProtoSlam_GA(int32_t EntryPoint); // Function Chonk_Melee_ProtoSlam_GA.Chonk_Melee_ProtoSlam_GA_C.ExecuteUbergraph_Chonk_Melee_ProtoSlam_GA // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

