// BlueprintGeneratedClass Chonk_IntroJump_Explosion_GE.Chonk_IntroJump_Explosion_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UChonk_IntroJump_Explosion_GE_C : UORGameplayEffect {
};

