// UserDefinedEnum Creature_CreatureMinionStatus.Creature_CreatureMinionStatus
enum class Creature_CreatureMinionStatus : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator2 = 1,
	NewEnumerator3 = 2,
	Creature_MAX = 3
};

