// BlueprintGeneratedClass BTD_TakenRecentDamage.BTD_TakenRecentDamage_C
// Size: 0xa8 (Inherited: 0xa0)
struct UBTD_TakenRecentDamage_C : UBTDecorator_BlueprintBase {
	float TimeInPastToCheck; // 0xa0(0x04)
	float DamageThreshold; // 0xa4(0x04)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_TakenRecentDamage.BTD_TakenRecentDamage_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

