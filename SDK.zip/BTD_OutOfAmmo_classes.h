// BlueprintGeneratedClass BTD_OutOfAmmo.BTD_OutOfAmmo_C
// Size: 0xb0 (Inherited: 0xa0)
struct UBTD_OutOfAmmo_C : UBTDecorator_BlueprintBase {
	struct FGameplayTag InventorySlotGameplayTag; // 0xa0(0x08)
	struct FGameplayTag FireModeGameplayTag; // 0xa8(0x08)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_OutOfAmmo.BTD_OutOfAmmo_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

