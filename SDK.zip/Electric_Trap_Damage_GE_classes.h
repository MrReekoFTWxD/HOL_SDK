// BlueprintGeneratedClass Electric_Trap_Damage_GE.Electric_Trap_Damage_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UElectric_Trap_Damage_GE_C : UORGameplayEffect {
};

