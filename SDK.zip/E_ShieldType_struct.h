// UserDefinedEnum E_ShieldType.E_ShieldType
enum class E_ShieldType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	E_MAX = 2
};

