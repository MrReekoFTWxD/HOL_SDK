// WidgetBlueprintGeneratedClass DebugMenu_IntCVarToggle.DebugMenu_IntCVarToggle_C
// Size: 0x2dc (Inherited: 0x2c8)
struct UDebugMenu_IntCVarToggle_C : UDebugMenu_BoolCVarToggle_C {
	struct TArray<int32_t> ValidValues; // 0x2c8(0x10)
	int32_t CurIdx; // 0x2d8(0x04)

	void Init(); // Function DebugMenu_IntCVarToggle.DebugMenu_IntCVarToggle_C.Init // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UpdateValue(); // Function DebugMenu_IntCVarToggle.DebugMenu_IntCVarToggle_C.UpdateValue // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void IncCVar(); // Function DebugMenu_IntCVarToggle.DebugMenu_IntCVarToggle_C.IncCVar // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

