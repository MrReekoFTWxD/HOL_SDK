// BlueprintGeneratedClass Creature_MinionFire_PreviewSC.Creature_MinionFire_PreviewSC_C
// Size: 0x170 (Inherited: 0x160)
struct UCreature_MinionFire_PreviewSC_C : UORPreviewSC_CreatureMinionFire {
	struct TArray<struct AActor*> ImpactActorClasses; // 0x160(0x10)

	bool ShouldBounce(struct FHitResult& Hit, struct ASQProjectile* ProjectileCDO); // Function Creature_MinionFire_PreviewSC.Creature_MinionFire_PreviewSC_C.ShouldBounce // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1953910
	float GetProjectileLaunchSpeed(struct ASQProjectile* ProjectileCDO); // Function Creature_MinionFire_PreviewSC.Creature_MinionFire_PreviewSC_C.GetProjectileLaunchSpeed // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1953910
};

