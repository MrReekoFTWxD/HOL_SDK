// ScriptStruct AnimMontageTrack.AnimMontageSectionParams
// Size: 0x20 (Inherited: 0x00)
struct FAnimMontageSectionParams {
	struct UAnimMontage* Montage; // 0x00(0x08)
	float StartOffset; // 0x08(0x04)
	float PlayRate; // 0x0c(0x04)
	char bPauseOnEnd : 1; // 0x10(0x01)
	char bReverse : 1; // 0x10(0x01)
	char pad_10_2 : 6; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	float PostTime; // 0x14(0x04)
	float BlendWeight; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct AnimMontageTrack.AnimMontageSectionTemplate
// Size: 0x88 (Inherited: 0x20)
struct FAnimMontageSectionTemplate : FMovieSceneEvalTemplate {
	struct FAnimMontageSectionParams Data; // 0x20(0x20)
	struct FMovieSceneEasingSettings Easing; // 0x40(0x38)
	struct TArray<struct TWeakObjectPtr<struct UObject>> BoundObjects; // 0x78(0x10)
};

