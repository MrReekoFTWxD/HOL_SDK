// WidgetBlueprintGeneratedClass DebugObjectiveMenu.DebugObjectiveMenu_C
// Size: 0x400 (Inherited: 0x3b1)
struct UDebugObjectiveMenu_C : UDebugMenu_C {
	char pad_3B1[0x7]; // 0x3b1(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3b8(0x08)
	struct UGridPanel* Grid; // 0x3c0(0x08)
	struct UScrollBox* ScrollBox_361; // 0x3c8(0x08)
	struct FMulticastInlineDelegate ObjectiveMenuPopped; // 0x3d0(0x30)

	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugObjectiveMenu.DebugObjectiveMenu_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Add Objective Elements(struct FGameplayTag MissionTag); // Function DebugObjectiveMenu.DebugObjectiveMenu_C.Add Objective Elements // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Construct(); // Function DebugObjectiveMenu.DebugObjectiveMenu_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnPopped(); // Function DebugObjectiveMenu.DebugObjectiveMenu_C.OnPopped // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugObjectiveMenu(int32_t EntryPoint); // Function DebugObjectiveMenu.DebugObjectiveMenu_C.ExecuteUbergraph_DebugObjectiveMenu // (Final|UbergraphFunction) // @ game+0x1953910
	void ObjectiveMenuPopped__DelegateSignature(); // Function DebugObjectiveMenu.DebugObjectiveMenu_C.ObjectiveMenuPopped__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

