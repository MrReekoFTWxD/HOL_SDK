// BlueprintGeneratedClass Creature_MinionFire_FiringResult_BP.Creature_MinionFire_FiringResult_BP_C
// Size: 0x398 (Inherited: 0x2e0)
struct UCreature_MinionFire_FiringResult_BP_C : UORFiringResult_CreatureMinion {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2e0(0x08)
	struct ACreature_MinionFire_Projectile_Base_BP_C* CreatureProjectile; // 0x2e8(0x08)
	bool DoesCharge; // 0x2f0(0x01)
	char pad_2F1[0x3]; // 0x2f1(0x03)
	struct FGameplayTag ChargeFireloopMode; // 0x2f4(0x08)
	struct FHitResult PreviewLastHitResult; // 0x2fc(0x90)
	char pad_38C[0x4]; // 0x38c(0x04)
	struct USQProjectileMovementComponent* ProjectileMovementComp; // 0x390(0x08)

	void GetFireLoop(struct UCreature_MinionFire_FireLoop_BP_C*& FireLoop); // Function Creature_MinionFire_FiringResult_BP.Creature_MinionFire_FiringResult_BP_C.GetFireLoop // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct ASQProjectile* GetProjectileType(); // Function Creature_MinionFire_FiringResult_BP.Creature_MinionFire_FiringResult_BP_C.GetProjectileType // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetSpawnTransform(struct FVector& OutLocation, struct FRotator& OutRotation, struct FVector& OutEffectsOffset, int32_t Shot, int32_t TotalShots, bool bUseOverrideLocation, struct FVector OverrideStartLocation); // Function Creature_MinionFire_FiringResult_BP.Creature_MinionFire_FiringResult_BP_C.GetSpawnTransform // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BP_InitProjectile(struct ASQProjectile* Projectile); // Function Creature_MinionFire_FiringResult_BP.Creature_MinionFire_FiringResult_BP_C.BP_InitProjectile // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_MinionFire_FiringResult_BP(int32_t EntryPoint); // Function Creature_MinionFire_FiringResult_BP.Creature_MinionFire_FiringResult_BP_C.ExecuteUbergraph_Creature_MinionFire_FiringResult_BP // (Final|UbergraphFunction) // @ game+0x1953910
};

