// BlueprintGeneratedClass Creature_CartridgeMindControlMinionAttachment_BP.Creature_CartridgeMindControlMinionAttachment_BP_C
// Size: 0x270 (Inherited: 0x264)
struct ACreature_CartridgeMindControlMinionAttachment_BP_C : ACreature_CartridgeMinionAttachment_BP_C {
	char pad_264[0x4]; // 0x264(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x268(0x08)

	void InitSocketMinionAttachment(struct ACreature_WeaponItem_BP_C* CreatureWeaponItem, struct ACreature_CartridgeAttachment_BP_C* CreatureCartridgeAttachment, int32_t SocketIndex); // Function Creature_CartridgeMindControlMinionAttachment_BP.Creature_CartridgeMindControlMinionAttachment_BP_C.InitSocketMinionAttachment // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_CartridgeMindControlMinionAttachment_BP(int32_t EntryPoint); // Function Creature_CartridgeMindControlMinionAttachment_BP.Creature_CartridgeMindControlMinionAttachment_BP_C.ExecuteUbergraph_Creature_CartridgeMindControlMinionAttachment_BP // (Final|UbergraphFunction) // @ game+0x1953910
};

