// BlueprintGeneratedClass BaseSkelMeshNPC_BP.BaseSkelMeshNPC_BP_C
// Size: 0x4d0 (Inherited: 0x470)
struct ABaseSkelMeshNPC_BP_C : AORBaseSkeletalMeshNPC {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x470(0x08)
	struct UORDetachedTriggerComponent* InterruptVolume; // 0x478(0x08)
	struct UNarrativeInfluenceVolumeComponent_BP_C* NIV; // 0x480(0x08)
	struct UTrigger_OptIntoComponent_C* OptIntoTrigger; // 0x488(0x08)
	struct UORTriggerVolumeComponent* ORTriggerVolume; // 0x490(0x08)
	struct ATrigger_OptInto_C* OptInto; // 0x498(0x08)
	struct FMulticastInlineDelegate OnOptIn; // 0x4a0(0x30)

	void SetOptIntoActive(bool InEnabled); // Function BaseSkelMeshNPC_BP.BaseSkelMeshNPC_BP_C.SetOptIntoActive // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function BaseSkelMeshNPC_BP.BaseSkelMeshNPC_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void OnOptedInto(); // Function BaseSkelMeshNPC_BP.BaseSkelMeshNPC_BP_C.OnOptedInto // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BaseSkelMeshNPC_BP(int32_t EntryPoint); // Function BaseSkelMeshNPC_BP.BaseSkelMeshNPC_BP_C.ExecuteUbergraph_BaseSkelMeshNPC_BP // (Final|UbergraphFunction) // @ game+0x1953910
	void OnOptIn__DelegateSignature(struct UTrigger_OptIntoComponent_C* OptInto); // Function BaseSkelMeshNPC_BP.BaseSkelMeshNPC_BP_C.OnOptIn__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

