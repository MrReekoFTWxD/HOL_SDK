// WidgetBlueprintGeneratedClass DebugMenuMissionLabel.DebugMenuMissionLabel_C
// Size: 0x2b0 (Inherited: 0x290)
struct UDebugMenuMissionLabel_C : UUserWidget {
	struct UDebugMenuText_C* DebugMenuText_C_55; // 0x290(0x08)
	struct FText MissionName; // 0x298(0x18)
};

