// BlueprintGeneratedClass BlockSpecialMoves_GE.BlockSpecialMoves_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UBlockSpecialMoves_GE_C : UORGameplayEffect {
};

