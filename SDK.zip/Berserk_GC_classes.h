// BlueprintGeneratedClass Berserk_GC.Berserk_GC_C
// Size: 0x294 (Inherited: 0x280)
struct ABerserk_GC_C : AGameplayCueNotify_Actor {
	struct UParticleSystemComponent* ParticleSystem; // 0x280(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x288(0x08)
	float ScaleIncrease; // 0x290(0x04)

	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function Berserk_GC.Berserk_GC_C.OnRemove // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function Berserk_GC.Berserk_GC_C.OnActive // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

