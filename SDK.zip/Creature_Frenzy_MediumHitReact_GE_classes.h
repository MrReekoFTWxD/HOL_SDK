// BlueprintGeneratedClass Creature_Frenzy_MediumHitReact_GE.Creature_Frenzy_MediumHitReact_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreature_Frenzy_MediumHitReact_GE_C : UORGameplayEffect {
};

