// BlueprintGeneratedClass Douglas_Primary_Projectile.Douglas_Primary_Projectile_C
// Size: 0x3e8 (Inherited: 0x3d0)
struct ADouglas_Primary_Projectile_C : AORProjectile {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d0(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x3d8(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x3e0(0x08)

	void OnReturnedToPool(); // Function Douglas_Primary_Projectile.Douglas_Primary_Projectile_C.OnReturnedToPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnSpawnedFromPool(); // Function Douglas_Primary_Projectile.Douglas_Primary_Projectile_C.OnSpawnedFromPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Douglas_Primary_Projectile(int32_t EntryPoint); // Function Douglas_Primary_Projectile.Douglas_Primary_Projectile_C.ExecuteUbergraph_Douglas_Primary_Projectile // (Final|UbergraphFunction) // @ game+0x1953910
};

