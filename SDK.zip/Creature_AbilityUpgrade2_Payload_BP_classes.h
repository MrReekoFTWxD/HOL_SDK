// BlueprintGeneratedClass Creature_AbilityUpgrade2_Payload_BP.Creature_AbilityUpgrade2_Payload_BP_C
// Size: 0x50 (Inherited: 0x50)
struct UCreature_AbilityUpgrade2_Payload_BP_C : UORItemEquipPayload_ItemEffects {
};

