// WidgetBlueprintGeneratedClass DebugMenuObjectiveStatus.DebugMenuObjectiveStatus_C
// Size: 0x3d8 (Inherited: 0x3a0)
struct UDebugMenuObjectiveStatus_C : UORWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a0(0x08)
	struct UORWidget_Button_BP_C* ORWidget_Button_BP; // 0x3a8(0x08)
	struct FText Status; // 0x3b0(0x18)
	struct UDebugUI_C* DebugUI; // 0x3c8(0x08)
	struct FGameplayTag ObjectiveTag; // 0x3d0(0x08)

	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugMenuObjectiveStatus.DebugMenuObjectiveStatus_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetStatus(struct FText NewStatus); // Function DebugMenuObjectiveStatus.DebugMenuObjectiveStatus_C.SetStatus // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function DebugMenuObjectiveStatus.DebugMenuObjectiveStatus_C.BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugMenuObjectiveStatus(int32_t EntryPoint); // Function DebugMenuObjectiveStatus.DebugMenuObjectiveStatus_C.ExecuteUbergraph_DebugMenuObjectiveStatus // (Final|UbergraphFunction) // @ game+0x1953910
};

