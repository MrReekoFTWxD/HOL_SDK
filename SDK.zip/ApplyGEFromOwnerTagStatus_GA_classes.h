// BlueprintGeneratedClass ApplyGEFromOwnerTagStatus_GA.ApplyGEFromOwnerTagStatus_GA_C
// Size: 0x418 (Inherited: 0x3f8)
struct UApplyGEFromOwnerTagStatus_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct FGameplayTag Tag; // 0x400(0x08)
	struct AActor* Owner; // 0x408(0x08)
	struct UGameplayEffect* GEToAdd; // 0x410(0x08)

	void Added_0C598E384933C65E60A5DD9912C21F12(); // Function ApplyGEFromOwnerTagStatus_GA.ApplyGEFromOwnerTagStatus_GA_C.Added_0C598E384933C65E60A5DD9912C21F12 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Removed_7325A66A49B4EFCCA18CF0B17693D065(); // Function ApplyGEFromOwnerTagStatus_GA.ApplyGEFromOwnerTagStatus_GA_C.Removed_7325A66A49B4EFCCA18CF0B17693D065 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function ApplyGEFromOwnerTagStatus_GA.ApplyGEFromOwnerTagStatus_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void OnTagAdded(); // Function ApplyGEFromOwnerTagStatus_GA.ApplyGEFromOwnerTagStatus_GA_C.OnTagAdded // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function ApplyGEFromOwnerTagStatus_GA.ApplyGEFromOwnerTagStatus_GA_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void OnTagRemoved(); // Function ApplyGEFromOwnerTagStatus_GA.ApplyGEFromOwnerTagStatus_GA_C.OnTagRemoved // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_ApplyGEFromOwnerTagStatus_GA(int32_t EntryPoint); // Function ApplyGEFromOwnerTagStatus_GA.ApplyGEFromOwnerTagStatus_GA_C.ExecuteUbergraph_ApplyGEFromOwnerTagStatus_GA // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

