// BlueprintGeneratedClass CombatIntro_GA.CombatIntro_GA_C
// Size: 0x410 (Inherited: 0x3f8)
struct UCombatIntro_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct UAnimMontage* IntroMontage; // 0x400(0x08)
	struct FName StartSection; // 0x408(0x08)

	void OnNotifyEnd_06576C1C466F8815983B738D42C21F59(struct FName NotifyName); // Function CombatIntro_GA.CombatIntro_GA_C.OnNotifyEnd_06576C1C466F8815983B738D42C21F59 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnNotifyBegin_06576C1C466F8815983B738D42C21F59(struct FName NotifyName); // Function CombatIntro_GA.CombatIntro_GA_C.OnNotifyBegin_06576C1C466F8815983B738D42C21F59 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnInterrupted_06576C1C466F8815983B738D42C21F59(struct FName NotifyName); // Function CombatIntro_GA.CombatIntro_GA_C.OnInterrupted_06576C1C466F8815983B738D42C21F59 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnBlendOut_06576C1C466F8815983B738D42C21F59(struct FName NotifyName); // Function CombatIntro_GA.CombatIntro_GA_C.OnBlendOut_06576C1C466F8815983B738D42C21F59 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_06576C1C466F8815983B738D42C21F59(struct FName NotifyName); // Function CombatIntro_GA.CombatIntro_GA_C.OnCompleted_06576C1C466F8815983B738D42C21F59 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function CombatIntro_GA.CombatIntro_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void K2_CommitExecute(); // Function CombatIntro_GA.CombatIntro_GA_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnMontageComplete(); // Function CombatIntro_GA.CombatIntro_GA_C.OnMontageComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnMontageBlendout(); // Function CombatIntro_GA.CombatIntro_GA_C.OnMontageBlendout // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnMontageInterrupted(); // Function CombatIntro_GA.CombatIntro_GA_C.OnMontageInterrupted // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnMontageNotifyBegin(struct FName NotifyName); // Function CombatIntro_GA.CombatIntro_GA_C.OnMontageNotifyBegin // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnMontageNotifyEnd(struct FName Notify Name); // Function CombatIntro_GA.CombatIntro_GA_C.OnMontageNotifyEnd // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_CombatIntro_GA(int32_t EntryPoint); // Function CombatIntro_GA.CombatIntro_GA_C.ExecuteUbergraph_CombatIntro_GA // (Final|UbergraphFunction) // @ game+0x1953910
};

