// BlueprintGeneratedClass Chonk_Mortar_v4_BP.Chonk_Mortar_v4_BP_C
// Size: 0x2748 (Inherited: 0x26a4)
struct AChonk_Mortar_v4_BP_C : AChonk_BP_C {
	char pad_26A4[0x4]; // 0x26a4(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x26a8(0x08)
	float WarpInScaleTimeline_ScaleTrack_7B0C56544983C42249CF19A029DB1B40; // 0x26b0(0x04)
	enum class ETimelineDirection WarpInScaleTimeline__Direction_7B0C56544983C42249CF19A029DB1B40; // 0x26b4(0x01)
	char pad_26B5[0x3]; // 0x26b5(0x03)
	struct UTimelineComponent* WarpInScaleTimeline; // 0x26b8(0x08)
	float WarpInTimeline_Phasing_0DAD9D844248CDA0EB3A5A8697E9662E; // 0x26c0(0x04)
	enum class ETimelineDirection WarpInTimeline__Direction_0DAD9D844248CDA0EB3A5A8697E9662E; // 0x26c4(0x01)
	char pad_26C5[0x3]; // 0x26c5(0x03)
	struct UTimelineComponent* WarpInTimeline; // 0x26c8(0x08)
	int32_t TauntTimerMin; // 0x26d0(0x04)
	int32_t TauntTimerMax; // 0x26d4(0x04)
	struct FGameplayTagRequirements AgressiveModeRequirements; // 0x26d8(0x40)
	struct FMulticastInlineDelegate WarpInComplete; // 0x2718(0x30)

	bool BP_CanPostTakeDamageEventToND(struct UObject* Damager, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function Chonk_Mortar_v4_BP.Chonk_Mortar_v4_BP_C.BP_CanPostTakeDamageEventToND // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void WarpInTimeline__FinishedFunc(); // Function Chonk_Mortar_v4_BP.Chonk_Mortar_v4_BP_C.WarpInTimeline__FinishedFunc // (BlueprintEvent) // @ game+0x1953910
	void WarpInTimeline__UpdateFunc(); // Function Chonk_Mortar_v4_BP.Chonk_Mortar_v4_BP_C.WarpInTimeline__UpdateFunc // (BlueprintEvent) // @ game+0x1953910
	void WarpInScaleTimeline__FinishedFunc(); // Function Chonk_Mortar_v4_BP.Chonk_Mortar_v4_BP_C.WarpInScaleTimeline__FinishedFunc // (BlueprintEvent) // @ game+0x1953910
	void WarpInScaleTimeline__UpdateFunc(); // Function Chonk_Mortar_v4_BP.Chonk_Mortar_v4_BP_C.WarpInScaleTimeline__UpdateFunc // (BlueprintEvent) // @ game+0x1953910
	void OnEffectApplied_AECE7F3C48B6113561B7E2BFE023A0B0(struct FActiveGameplayEffectHandle ActiveEffectHandle, struct FGameplayEffectSpecHandle EffectSpecHandle); // Function Chonk_Mortar_v4_BP.Chonk_Mortar_v4_BP_C.OnEffectApplied_AECE7F3C48B6113561B7E2BFE023A0B0 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function Chonk_Mortar_v4_BP.Chonk_Mortar_v4_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ReceiveDirectEvent(struct FGameplayTag Tag, struct UORGlobalEventPayload* Payload); // Function Chonk_Mortar_v4_BP.Chonk_Mortar_v4_BP_C.ReceiveDirectEvent // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Chonk_Mortar_v4_BP(int32_t EntryPoint); // Function Chonk_Mortar_v4_BP.Chonk_Mortar_v4_BP_C.ExecuteUbergraph_Chonk_Mortar_v4_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
	void WarpInComplete__DelegateSignature(); // Function Chonk_Mortar_v4_BP.Chonk_Mortar_v4_BP_C.WarpInComplete__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

