// BlueprintGeneratedClass Creature_OutWithABlastMod_Explosion_BP.Creature_OutWithABlastMod_Explosion_BP_C
// Size: 0x450 (Inherited: 0x438)
struct ACreature_OutWithABlastMod_Explosion_BP_C : AORExplosionActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x438(0x08)
	struct UORAkComponent* ORAk; // 0x440(0x08)
	struct UParticleSystemComponent* Explosion; // 0x448(0x08)

	void ReceiveBeginPlay(); // Function Creature_OutWithABlastMod_Explosion_BP.Creature_OutWithABlastMod_Explosion_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_OutWithABlastMod_Explosion_BP(int32_t EntryPoint); // Function Creature_OutWithABlastMod_Explosion_BP.Creature_OutWithABlastMod_Explosion_BP_C.ExecuteUbergraph_Creature_OutWithABlastMod_Explosion_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

