// BlueprintGeneratedClass Creature_MindControlMinionLatched_Attachement_BP.Creature_MindControlMinionLatched_Attachement_BP_C
// Size: 0x2c0 (Inherited: 0x2a8)
struct ACreature_MindControlMinionLatched_Attachement_BP_C : ACreature_MinionLatched_Attachement_BP_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2a8(0x08)
	struct UNiagaraComponent* FrenzyRadioWaves; // 0x2b0(0x08)
	struct UNiagaraComponent* MindControlRadioWaves; // 0x2b8(0x08)

	void SetMindControlFXEnabled(bool Enabled); // Function Creature_MindControlMinionLatched_Attachement_BP.Creature_MindControlMinionLatched_Attachement_BP_C.SetMindControlFXEnabled // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetFrenzyFXEnabled(bool Enabled); // Function Creature_MindControlMinionLatched_Attachement_BP.Creature_MindControlMinionLatched_Attachement_BP_C.SetFrenzyFXEnabled // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_MindControlMinionLatched_Attachement_BP(int32_t EntryPoint); // Function Creature_MindControlMinionLatched_Attachement_BP.Creature_MindControlMinionLatched_Attachement_BP_C.ExecuteUbergraph_Creature_MindControlMinionLatched_Attachement_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

