// BlueprintGeneratedClass AITraversal_NA.AITraversal_NA_C
// Size: 0x48 (Inherited: 0x48)
struct UAITraversal_NA_C : UNavArea {
};

