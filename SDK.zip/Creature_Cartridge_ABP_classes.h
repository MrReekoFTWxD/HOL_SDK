// AnimBlueprintGeneratedClass Creature_Cartridge_ABP.Creature_Cartridge_ABP_C
// Size: 0x1e84 (Inherited: 0x390)
struct UCreature_Cartridge_ABP_C : UORAnimInstance_CreatureCartridge {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x390(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x398(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot_7; // 0x3c8(0x48)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3; // 0x410(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3; // 0x568(0x28)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_7; // 0x590(0xc0)
	struct FAnimNode_Slot AnimGraphNode_Slot_6; // 0x650(0x48)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_6; // 0x698(0xc0)
	struct FAnimNode_Slot AnimGraphNode_Slot_5; // 0x758(0x48)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_5; // 0x7a0(0xc0)
	struct FAnimNode_Slot AnimGraphNode_Slot_4; // 0x860(0x48)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_4; // 0x8a8(0xc0)
	struct FAnimNode_Slot AnimGraphNode_Slot_3; // 0x968(0x48)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_3; // 0x9b0(0xc0)
	struct FAnimNode_Slot AnimGraphNode_Slot_2; // 0xa70(0x48)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2; // 0xab8(0xc0)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0xb78(0x48)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2; // 0xbc0(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2; // 0xd18(0x28)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_7; // 0xd40(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_20; // 0xde0(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_19; // 0xe60(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_6; // 0xee0(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_18; // 0xf80(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_17; // 0x1000(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_5; // 0x1080(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_16; // 0x1120(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_15; // 0x11a0(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_4; // 0x1220(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_14; // 0x12c0(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_13; // 0x1340(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3; // 0x13c0(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_12; // 0x1460(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_11; // 0x14e0(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2; // 0x1560(0xa0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_10; // 0x1600(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_9; // 0x1680(0x80)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x1700(0x158)
	struct FAnimNode_BlendListByInt AnimGraphNode_BlendListByInt; // 0x1858(0xa0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0x18f8(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_8; // 0x1920(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7; // 0x19a0(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6; // 0x1a20(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5; // 0x1aa0(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4; // 0x1b20(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x1ba0(0x80)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend; // 0x1c20(0xc0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x1ce0(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x1d60(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x1de0(0xa0)
	int32_t PrimedMinionSlotIndex; // 0x1e80(0x04)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function Creature_Cartridge_ABP.Creature_Cartridge_ABP_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InitCreatureCartridge(struct ACreature_WeaponItem_BP_C* CreatureWeaponItem); // Function Creature_Cartridge_ABP.Creature_Cartridge_ABP_C.InitCreatureCartridge // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Creature_Cartridge_ABP_AnimGraphNode_BlendListByBool_CA8B78BC46C1CC5E09396A8AA38619D3(); // Function Creature_Cartridge_ABP.Creature_Cartridge_ABP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Creature_Cartridge_ABP_AnimGraphNode_BlendListByBool_CA8B78BC46C1CC5E09396A8AA38619D3 // (BlueprintEvent) // @ game+0x1953910
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Creature_Cartridge_ABP_AnimGraphNode_BlendListByBool_81A3B2C6469AE75AA3C808827E0A2FF2(); // Function Creature_Cartridge_ABP.Creature_Cartridge_ABP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Creature_Cartridge_ABP_AnimGraphNode_BlendListByBool_81A3B2C6469AE75AA3C808827E0A2FF2 // (BlueprintEvent) // @ game+0x1953910
	void OnMinionSlotFired(int32_t SlotFired); // Function Creature_Cartridge_ABP.Creature_Cartridge_ABP_C.OnMinionSlotFired // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Creature_Cartridge_ABP_AnimGraphNode_BlendListByBool_0E3641E24F704C88A7A6E79102D7D2BB(); // Function Creature_Cartridge_ABP.Creature_Cartridge_ABP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Creature_Cartridge_ABP_AnimGraphNode_BlendListByBool_0E3641E24F704C88A7A6E79102D7D2BB // (BlueprintEvent) // @ game+0x1953910
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Creature_Cartridge_ABP_AnimGraphNode_BlendListByBool_2CED83F441C8ADD6B19FC2B34767FE41(); // Function Creature_Cartridge_ABP.Creature_Cartridge_ABP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Creature_Cartridge_ABP_AnimGraphNode_BlendListByBool_2CED83F441C8ADD6B19FC2B34767FE41 // (BlueprintEvent) // @ game+0x1953910
	void ReloadSlot(int32_t SlotReloaded); // Function Creature_Cartridge_ABP.Creature_Cartridge_ABP_C.ReloadSlot // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Creature_Cartridge_ABP_AnimGraphNode_BlendListByBool_C06648D44CB2861F5E619C811B3C1ADE(); // Function Creature_Cartridge_ABP.Creature_Cartridge_ABP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Creature_Cartridge_ABP_AnimGraphNode_BlendListByBool_C06648D44CB2861F5E619C811B3C1ADE // (BlueprintEvent) // @ game+0x1953910
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Creature_Cartridge_ABP_AnimGraphNode_BlendListByBool_1709FDDE4B7CA9455933DF94757A4142(); // Function Creature_Cartridge_ABP.Creature_Cartridge_ABP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Creature_Cartridge_ABP_AnimGraphNode_BlendListByBool_1709FDDE4B7CA9455933DF94757A4142 // (BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_Cartridge_ABP(int32_t EntryPoint); // Function Creature_Cartridge_ABP.Creature_Cartridge_ABP_C.ExecuteUbergraph_Creature_Cartridge_ABP // (Final|UbergraphFunction) // @ game+0x1953910
};

