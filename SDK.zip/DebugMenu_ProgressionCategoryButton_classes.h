// WidgetBlueprintGeneratedClass DebugMenu_ProgressionCategoryButton.DebugMenu_ProgressionCategoryButton_C
// Size: 0x2d2 (Inherited: 0x290)
struct UDebugMenu_ProgressionCategoryButton_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UORWidget_Button_BP_C* ORWidget_Button_BP; // 0x298(0x08)
	struct FMulticastInlineDelegate SectionButtonClicked; // 0x2a0(0x30)
	enum class ProgressionReportSection_EN ReportSection; // 0x2d0(0x01)
	bool UseOverrideText; // 0x2d1(0x01)

	void OverrideText(struct FText InText); // Function DebugMenu_ProgressionCategoryButton.DebugMenu_ProgressionCategoryButton_C.OverrideText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugMenu_ProgressionCategoryButton.DebugMenu_ProgressionCategoryButton_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function DebugMenu_ProgressionCategoryButton.DebugMenu_ProgressionCategoryButton_C.BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void Construct(); // Function DebugMenu_ProgressionCategoryButton.DebugMenu_ProgressionCategoryButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugMenu_ProgressionCategoryButton(int32_t EntryPoint); // Function DebugMenu_ProgressionCategoryButton.DebugMenu_ProgressionCategoryButton_C.ExecuteUbergraph_DebugMenu_ProgressionCategoryButton // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
	void SectionButtonClicked__DelegateSignature(enum class ProgressionReportSection_EN Section); // Function DebugMenu_ProgressionCategoryButton.DebugMenu_ProgressionCategoryButton_C.SectionButtonClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

