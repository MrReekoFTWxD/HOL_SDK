// BlueprintGeneratedClass Chonk_Projectile_Explosion_CameraShake.Chonk_Projectile_Explosion_CameraShake_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UChonk_Projectile_Explosion_CameraShake_C : UMatineeCameraShake {
};

