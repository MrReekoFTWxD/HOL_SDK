// BlueprintGeneratedClass Chonk_BP.Chonk_BP_C
// Size: 0x26a4 (Inherited: 0x23d8)
struct AChonk_BP_C : AHenchman_GoopArmored_BP_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x23d8(0x08)
	struct USceneComponent* BarrageWarningPlacementScene; // 0x23e0(0x08)
	struct USkeletalMeshComponent* HighlightGunMesh; // 0x23e8(0x08)
	float GunDisable_Cycle_R_Value_A839FA2A42EA0A837933648C7441B87E; // 0x23f0(0x04)
	enum class ETimelineDirection GunDisable_Cycle__Direction_A839FA2A42EA0A837933648C7441B87E; // 0x23f4(0x01)
	char pad_23F5[0x3]; // 0x23f5(0x03)
	struct UTimelineComponent* GunDisable_Cycle; // 0x23f8(0x08)
	int32_t GunArm_HitCount; // 0x2400(0x04)
	int32_t GunArm_MaxHit; // 0x2404(0x04)
	struct TArray<struct FName> Placeholder_LeftArmBoneNamesForGun; // 0x2408(0x10)
	struct FGameplayTag eventND_ChonkGunBroken; // 0x2418(0x08)
	struct FMulticastInlineDelegate OnDisableComplete; // 0x2420(0x30)
	struct FScalableFloat GunAttackInterruptDamage; // 0x2450(0x28)
	float CurrentGunDamage; // 0x2478(0x04)
	bool GunAttackActive; // 0x247c(0x01)
	bool ForceHeavyHitReaction; // 0x247d(0x01)
	char pad_247E[0x2]; // 0x247e(0x02)
	struct UORWidget_HUDPrompt* CachedHudPrompt; // 0x2480(0x08)
	struct FMulticastInlineDelegate ForceHitReact; // 0x2488(0x30)
	struct AActor* MainTarget; // 0x24b8(0x08)
	float MinDistanceToFriendlyTarget; // 0x24c0(0x04)
	bool IsTargetingFriendly; // 0x24c4(0x01)
	char pad_24C5[0x3]; // 0x24c5(0x03)
	float IntroJumpLaunchSpeed; // 0x24c8(0x04)
	char pad_24CC[0x4]; // 0x24cc(0x04)
	struct TArray<struct AActor*> OverrideTargetList; // 0x24d0(0x10)
	struct FName TargetAdditionalActors; // 0x24e0(0x08)
	struct FName TargetActorBBKey; // 0x24e8(0x08)
	struct FName TargetActor_Ability; // 0x24f0(0x08)
	struct FGameplayTagQuery ExcludeFromFriendlyTargetting; // 0x24f8(0x48)
	struct FGameplayTagQuery PriorityFriendlyTarget; // 0x2540(0x48)
	struct FRuntimeFloatCurve ProxyMineTargetChonkDistanceScoreCurve; // 0x2588(0x88)
	struct FRuntimeFloatCurve ProxyMineTargetPlayerDistanceScoreCurve; // 0x2610(0x88)
	int32_t NDBarrageInterruptTotalShots; // 0x2698(0x04)
	float NDBarrageInterruptTimeBetweenShots; // 0x269c(0x04)
	float NDBarrageInterruptInitialDelay; // 0x26a0(0x04)

	void IsTargetPrioritizedForFriendlyTargeting(struct AActor* Target Character, bool& Is Prioritized); // Function Chonk_BP.Chonk_BP_C.IsTargetPrioritizedForFriendlyTargeting // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void IsTargetExcludedFromFriendlyTargeting(struct AActor* Target Character, bool& Is Excluded); // Function Chonk_BP.Chonk_BP_C.IsTargetExcludedFromFriendlyTargeting // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void SetTargetActorListFromOverride(bool& FoundTarget); // Function Chonk_BP.Chonk_BP_C.SetTargetActorListFromOverride // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void TargetRandomFriendlyCharacter(bool& NewParam); // Function Chonk_BP.Chonk_BP_C.TargetRandomFriendlyCharacter // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void TargetBestFriendlyCharacter(bool& FoundTarget); // Function Chonk_BP.Chonk_BP_C.TargetBestFriendlyCharacter // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CalcFriendlyProxyMineTargetScore(struct AORAICharacter* ORAICharacter, float& TargetScore); // Function Chonk_BP.Chonk_BP_C.CalcFriendlyProxyMineTargetScore // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetBestFriendlyProxyMineTarget(struct AActor*& FriendlyProxyMineTarget); // Function Chonk_BP.Chonk_BP_C.GetBestFriendlyProxyMineTarget // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Start Critical Damage VO(); // Function Chonk_BP.Chonk_BP_C.Start Critical Damage VO // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void EnableBarrageWarning(bool Enable); // Function Chonk_BP.Chonk_BP_C.EnableBarrageWarning // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void HandleWeakpointVFX(struct FGameplayTagContainer& TagContainer, struct FHitResult& Hit); // Function Chonk_BP.Chonk_BP_C.HandleWeakpointVFX // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CanForceHeavyHitReact(bool& Force); // Function Chonk_BP.Chonk_BP_C.CanForceHeavyHitReact // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void EnableGunInterrupt(bool Enable); // Function Chonk_BP.Chonk_BP_C.EnableGunInterrupt // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CancelAbilities(); // Function Chonk_BP.Chonk_BP_C.CancelAbilities // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UserConstructionScript(); // Function Chonk_BP.Chonk_BP_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GunDisable_Cycle__FinishedFunc(); // Function Chonk_BP.Chonk_BP_C.GunDisable_Cycle__FinishedFunc // (BlueprintEvent) // @ game+0x1953910
	void GunDisable_Cycle__UpdateFunc(); // Function Chonk_BP.Chonk_BP_C.GunDisable_Cycle__UpdateFunc // (BlueprintEvent) // @ game+0x1953910
	void DisableGun(); // Function Chonk_BP.Chonk_BP_C.DisableGun // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnDied(struct UObject* Killer, struct FHitResult& HitResult, struct FGameplayTagContainer& DamageTags); // Function Chonk_BP.Chonk_BP_C.OnDied // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function Chonk_BP.Chonk_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void TriggerCriticalDamageVO(struct FHitResult HitResult, struct FGameplayTagContainer HitReactTag); // Function Chonk_BP.Chonk_BP_C.TriggerCriticalDamageVO // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnDamageTaken(struct UObject* Damager, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function Chonk_BP.Chonk_BP_C.OnDamageTaken // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1953910
	void SetListOfTargetActors(struct TArray<struct AActor*>& TargetList); // Function Chonk_BP.Chonk_BP_C.SetListOfTargetActors // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BP_SpawnedFromPool(); // Function Chonk_BP.Chonk_BP_C.BP_SpawnedFromPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Chonk_BP(int32_t EntryPoint); // Function Chonk_BP.Chonk_BP_C.ExecuteUbergraph_Chonk_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
	void ForceHitReact__DelegateSignature(struct FHitResult HitResult, struct FGameplayTagContainer HitReactTag); // Function Chonk_BP.Chonk_BP_C.ForceHitReact__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnDisableComplete__DelegateSignature(); // Function Chonk_BP.Chonk_BP_C.OnDisableComplete__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

