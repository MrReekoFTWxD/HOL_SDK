// BlueprintGeneratedClass CreatureMinionMoveToMarker_BP.CreatureMinionMoveToMarker_BP_C
// Size: 0x279 (Inherited: 0x220)
struct ACreatureMinionMoveToMarker_BP_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UBillboardComponent* Billboard; // 0x228(0x08)
	struct UORTriggerVolumeComponent* ORTriggerVolume; // 0x230(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x238(0x08)
	bool MoveToMarkerEnabled; // 0x240(0x01)
	bool DisableOnEntered; // 0x241(0x01)
	char pad_242[0x6]; // 0x242(0x06)
	struct FMulticastInlineDelegate CreatureMinionActorEntered; // 0x248(0x30)
	bool DestroyCreatureMinionOnEntered; // 0x278(0x01)

	void IsMinion(struct AActor* Actor, bool& IsMinion, struct AActor*& Minion); // Function CreatureMinionMoveToMarker_BP.CreatureMinionMoveToMarker_BP_C.IsMinion // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void SetLureEnabled(bool EnableLure); // Function CreatureMinionMoveToMarker_BP.CreatureMinionMoveToMarker_BP_C.SetLureEnabled // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORTriggerVolume_K2Node_ComponentBoundEvent_0_ORTriggerVolumeComponentCallback__DelegateSignature(struct AActor* SourceActor, int32_t VolumeIndex); // Function CreatureMinionMoveToMarker_BP.CreatureMinionMoveToMarker_BP_C.BndEvt__ORTriggerVolume_K2Node_ComponentBoundEvent_0_ORTriggerVolumeComponentCallback__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void SetTriggerVolumeEnabled(bool TriggerVolumeEnabled); // Function CreatureMinionMoveToMarker_BP.CreatureMinionMoveToMarker_BP_C.SetTriggerVolumeEnabled // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_CreatureMinionMoveToMarker_BP(int32_t EntryPoint); // Function CreatureMinionMoveToMarker_BP.CreatureMinionMoveToMarker_BP_C.ExecuteUbergraph_CreatureMinionMoveToMarker_BP // (Final|UbergraphFunction) // @ game+0x1953910
	void CreatureMinionActorEntered__DelegateSignature(struct AActor* CreatureMinionActor); // Function CreatureMinionMoveToMarker_BP.CreatureMinionMoveToMarker_BP_C.CreatureMinionActorEntered__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

