// BlueprintGeneratedClass Chonk_ArcFiringResult_Base_BP.Chonk_ArcFiringResult_Base_BP_C
// Size: 0x358 (Inherited: 0x358)
struct UChonk_ArcFiringResult_Base_BP_C : UORFiringResult_ArcProjectile {
};

