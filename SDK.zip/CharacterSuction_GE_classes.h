// BlueprintGeneratedClass CharacterSuction_GE.CharacterSuction_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCharacterSuction_GE_C : UORGameplayEffect {
};

