// BlueprintGeneratedClass BTD_Merk_Melee_Trigger_Reload.BTD_Merk_Melee_Trigger_Reload_C
// Size: 0xa0 (Inherited: 0xa0)
struct UBTD_Merk_Melee_Trigger_Reload_C : UBTDecorator_BlueprintBase {

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_Merk_Melee_Trigger_Reload.BTD_Merk_Melee_Trigger_Reload_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

