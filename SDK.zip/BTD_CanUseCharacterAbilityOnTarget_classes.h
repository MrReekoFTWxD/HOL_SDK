// BlueprintGeneratedClass BTD_CanUseCharacterAbilityOnTarget.BTD_CanUseCharacterAbilityOnTarget_C
// Size: 0xd9 (Inherited: 0xa0)
struct UBTD_CanUseCharacterAbilityOnTarget_C : UBTDecorator_BlueprintBase {
	struct FBlackboardKeySelector TargetActorKey; // 0xa0(0x28)
	struct FGameplayTag CharacterAbilityTag; // 0xc8(0x08)
	struct FORAbilityRequirementOverrideData AbilityRequirementOverrides; // 0xd0(0x09)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_CanUseCharacterAbilityOnTarget.BTD_CanUseCharacterAbilityOnTarget_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

