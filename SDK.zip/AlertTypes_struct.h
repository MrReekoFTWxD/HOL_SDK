// UserDefinedEnum AlertTypes.AlertTypes
enum class AlertTypes : uint8 {
	NewEnumerator3 = 0,
	NewEnumerator9 = 1,
	NewEnumerator4 = 2,
	NewEnumerator8 = 3,
	NewEnumerator0 = 4,
	NewEnumerator7 = 5,
	NewEnumerator1 = 6,
	NewEnumerator6 = 7,
	NewEnumerator5 = 8,
	NewEnumerator2 = 9,
	AlertTypes_MAX = 10
};

