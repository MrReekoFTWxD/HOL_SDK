// BlueprintGeneratedClass BTT_Chonk_PickSquadTarget.BTT_Chonk_PickSquadTarget_C
// Size: 0xb0 (Inherited: 0xa8)
struct UBTT_Chonk_PickSquadTarget_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_Chonk_PickSquadTarget.BTT_Chonk_PickSquadTarget_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTT_Chonk_PickSquadTarget(int32_t EntryPoint); // Function BTT_Chonk_PickSquadTarget.BTT_Chonk_PickSquadTarget_C.ExecuteUbergraph_BTT_Chonk_PickSquadTarget // (Final|UbergraphFunction) // @ game+0x1953910
};

