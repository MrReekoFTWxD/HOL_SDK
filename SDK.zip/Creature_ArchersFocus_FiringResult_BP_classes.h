// BlueprintGeneratedClass Creature_ArchersFocus_FiringResult_BP.Creature_ArchersFocus_FiringResult_BP_C
// Size: 0x2e8 (Inherited: 0x2d0)
struct UCreature_ArchersFocus_FiringResult_BP_C : UCreature_HighImpactMinionFire_FiringResult_BP_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d0(0x08)
	struct USQResourceComponent* MinionFireResourceComponent; // 0x2d8(0x08)
	struct FGameplayTag MinionFireMode; // 0x2e0(0x08)

	int32_t GetShotsToFire(); // Function Creature_ArchersFocus_FiringResult_BP.Creature_ArchersFocus_FiringResult_BP_C.GetShotsToFire // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BP_PostInit(); // Function Creature_ArchersFocus_FiringResult_BP.Creature_ArchersFocus_FiringResult_BP_C.BP_PostInit // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_ArchersFocus_FiringResult_BP(int32_t EntryPoint); // Function Creature_ArchersFocus_FiringResult_BP.Creature_ArchersFocus_FiringResult_BP_C.ExecuteUbergraph_Creature_ArchersFocus_FiringResult_BP // (Final|UbergraphFunction) // @ game+0x1953910
};

