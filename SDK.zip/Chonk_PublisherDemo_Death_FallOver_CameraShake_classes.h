// BlueprintGeneratedClass Chonk_PublisherDemo_Death_FallOver_CameraShake.Chonk_PublisherDemo_Death_FallOver_CameraShake_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UChonk_PublisherDemo_Death_FallOver_CameraShake_C : UMatineeCameraShake {
};

