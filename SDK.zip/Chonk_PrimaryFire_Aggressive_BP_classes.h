// BlueprintGeneratedClass Chonk_PrimaryFire_Aggressive_BP.Chonk_PrimaryFire_Aggressive_BP_C
// Size: 0x448 (Inherited: 0x448)
struct UChonk_PrimaryFire_Aggressive_BP_C : UChonk_PrimaryFire_BP_C {
};

