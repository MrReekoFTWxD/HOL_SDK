// BlueprintGeneratedClass BP_Tendril.BP_Tendril_C
// Size: 0x269 (Inherited: 0x220)
struct ABP_Tendril_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UNiagaraComponent* NI_Tendril; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)
	float FlickerTimeline_BeamWidth_B99E267149B9AF9EFEE19AAB97F12C57; // 0x238(0x04)
	enum class ETimelineDirection FlickerTimeline__Direction_B99E267149B9AF9EFEE19AAB97F12C57; // 0x23c(0x01)
	char pad_23D[0x3]; // 0x23d(0x03)
	struct UTimelineComponent* FlickerTimeline; // 0x240(0x08)
	struct AActor* ParentAttachment; // 0x248(0x08)
	struct AActor* ChildAttachment; // 0x250(0x08)
	struct UNiagaraComponent* TendrilParticles; // 0x258(0x08)
	struct FTimerHandle FlickerTimerHandle; // 0x260(0x08)
	bool IsFlickering; // 0x268(0x01)

	void SetAttachments(struct AActor* Parent, struct AActor* Child); // Function BP_Tendril.BP_Tendril_C.SetAttachments // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void FlickerTimeline__FinishedFunc(); // Function BP_Tendril.BP_Tendril_C.FlickerTimeline__FinishedFunc // (BlueprintEvent) // @ game+0x1953910
	void FlickerTimeline__UpdateFunc(); // Function BP_Tendril.BP_Tendril_C.FlickerTimeline__UpdateFunc // (BlueprintEvent) // @ game+0x1953910
	void StopFlicker(); // Function BP_Tendril.BP_Tendril_C.StopFlicker // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Flicker(float Duration); // Function BP_Tendril.BP_Tendril_C.Flicker // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetThin(); // Function BP_Tendril.BP_Tendril_C.SetThin // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveTick(float DeltaSeconds); // Function BP_Tendril.BP_Tendril_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BP_Tendril(int32_t EntryPoint); // Function BP_Tendril.BP_Tendril_C.ExecuteUbergraph_BP_Tendril // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

