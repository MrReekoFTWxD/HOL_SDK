// BlueprintGeneratedClass BlockWeaponFire_GE.BlockWeaponFire_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UBlockWeaponFire_GE_C : UORGameplayEffect {
};

