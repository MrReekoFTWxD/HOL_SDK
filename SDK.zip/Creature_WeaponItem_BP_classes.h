// BlueprintGeneratedClass Creature_WeaponItem_BP.Creature_WeaponItem_BP_C
// Size: 0x640 (Inherited: 0x4b0)
struct ACreature_WeaponItem_BP_C : AORCreatureWeaponItem {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4b0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x4b8(0x08)
	struct TArray<struct FName> OuterAmmoSocketNames; // 0x4c0(0x10)
	struct FName InnerAmmoSocketName; // 0x4d0(0x08)
	struct TArray<struct ACreature_CartridgeMinionAttachment_BP_C*> OuterAmmoAttachments; // 0x4d8(0x10)
	struct TArray<struct FRotator> MinionAttachmentRotations; // 0x4e8(0x10)
	struct ACreature_CartridgeMinionAttachment_BP_C* InnerAmmoAttachment; // 0x4f8(0x08)
	struct ACreature_CartridgeAttachment_BP_C* CartridgeAttachment; // 0x500(0x08)
	struct TArray<struct AORAICharacter*> ActiveMinions; // 0x508(0x10)
	struct FMulticastInlineDelegate OnMinionSlotFired; // 0x518(0x30)
	struct FMulticastInlineDelegate OnMinionsReloaded; // 0x548(0x30)
	struct AORAICharacter* ActiveMindControlMinion; // 0x578(0x08)
	int32_t ActiveProjectileMinions; // 0x580(0x04)
	char pad_584[0x4]; // 0x584(0x04)
	struct FTimerHandle MinionProjectileAutoRemoveTimer; // 0x588(0x08)
	struct TArray<struct UORScriptComponent*> ScriptComponents; // 0x590(0x10)
	struct TMap<struct FGameplayTag, struct UMaterialInstance*> CartridgeMinionMaterials; // 0x5a0(0x50)
	struct TMap<struct FGameplayTag, struct UMaterialInstance*> MinionModMaterials; // 0x5f0(0x50)

	struct TArray<struct UORScriptComponent*> GetScriptComponents(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.GetScriptComponents // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetMinionModMaterial(struct UMaterialInstance*& ModMaterial); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.GetMinionModMaterial // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetCartridgeMinionModMaterial(struct UMaterialInstance*& ModMaterial); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.GetCartridgeMinionModMaterial // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UpdateCartridgeMinionMaterials(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.UpdateCartridgeMinionMaterials // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetCreatureModTag(struct FGameplayTag& CreatureModTag); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.GetCreatureModTag // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InitCreatureMinion(struct ACreatureMinion_Base_BP_C* CreatureMinion, bool RegisterActiveMinion); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.InitCreatureMinion // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SpawnCreatureMinion(struct AORAICreatureMinionCharacter* CreatureMinionClass, struct FTransform SpawnTransform, bool RegisterActiveMinion, struct ACreatureMinion_Base_BP_C*& CreatureMinion); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.SpawnCreatureMinion // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UnregisterActiveMindControlMinion(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.UnregisterActiveMindControlMinion // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void RegisterActiveMindControlMinion(struct AORAICharacter* MindControlMinion); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.RegisterActiveMindControlMinion // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void RemoveActiveMinionProjectile(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.RemoveActiveMinionProjectile // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AddActiveMinionProjectile(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.AddActiveMinionProjectile // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void FreeSpaceForActiveMinion(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.FreeSpaceForActiveMinion // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UnregisterActiveMinion(struct AORAICharacter* Minion); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.UnregisterActiveMinion // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void RegisterActiveMinion(struct AORAICharacter* Minion); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.RegisterActiveMinion // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Set Charging State(bool Charging); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.Set Charging State // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void TriggerMindControlReloadAnimation(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.TriggerMindControlReloadAnimation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void TriggerMindControlFireAnimation(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.TriggerMindControlFireAnimation // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void TriggerReloadAnimations(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.TriggerReloadAnimations // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void TriggerFireAnimation(int32_t MinionSlot); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.TriggerFireAnimation // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnMindControlMinionReloaded(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.OnMindControlMinionReloaded // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnMindControlMinionFired(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.OnMindControlMinionFired // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnMinionReloaded(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.OnMinionReloaded // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnMinionFired(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.OnMinionFired // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InitializeCreatureAttachments(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.InitializeCreatureAttachments // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetScriptComponents(struct TArray<struct UORScriptComponent*>& ScriptComponents); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.SetScriptComponents // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void OnItemEventPosted(struct ASQInventoryItem* Item, struct FGameplayTag EventTag, struct FGameplayTag FireMode, enum class EInventoryTransactionType TransactionType); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.OnItemEventPosted // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BP_GameplayTagChanged(struct FGameplayTag Tag, bool bAdded); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.BP_GameplayTagChanged // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void OnItemUnequipped(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.OnItemUnequipped // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_WeaponItem_BP(int32_t EntryPoint); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.ExecuteUbergraph_Creature_WeaponItem_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
	void OnMinionsReloaded__DelegateSignature(); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.OnMinionsReloaded__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnMinionSlotFired__DelegateSignature(int32_t SlotFired); // Function Creature_WeaponItem_BP.Creature_WeaponItem_BP_C.OnMinionSlotFired__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

