// BlueprintGeneratedClass Base_Fauna_Enemy_BP.Base_Fauna_Enemy_BP_C
// Size: 0x20f8 (Inherited: 0x20e0)
struct ABase_Fauna_Enemy_BP_C : AORAIFaunaCharacter {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x20e0(0x08)
	struct FName PlayerEventNameForKnifeyEnemyDeath; // 0x20e8(0x08)
	struct FName PlayerEventNameForGunEnemyDeath; // 0x20f0(0x08)

	void OnDied(struct UObject* Killer, struct FHitResult& HitResult, struct FGameplayTagContainer& DamageTags); // Function Base_Fauna_Enemy_BP.Base_Fauna_Enemy_BP_C.OnDied // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Base_Fauna_Enemy_BP(int32_t EntryPoint); // Function Base_Fauna_Enemy_BP.Base_Fauna_Enemy_BP_C.ExecuteUbergraph_Base_Fauna_Enemy_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

