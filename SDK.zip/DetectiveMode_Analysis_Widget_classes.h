// WidgetBlueprintGeneratedClass DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C
// Size: 0x648 (Inherited: 0x410)
struct UDetectiveMode_Analysis_Widget_C : UORWidget_HUDPrompt {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x410(0x08)
	struct UWidgetAnimation* TranslateNumbers; // 0x418(0x08)
	struct UWidgetAnimation* HideScanner; // 0x420(0x08)
	struct UWidgetAnimation* ScanAnimation; // 0x428(0x08)
	struct UWidgetAnimation* NameAnimation; // 0x430(0x08)
	struct UWidgetAnimation* ShowPromptAnim; // 0x438(0x08)
	struct UWidgetAnimation* InfoAnimation; // 0x440(0x08)
	struct UImage* AnimatedBG; // 0x448(0x08)
	struct UImage* BG; // 0x450(0x08)
	struct UImage* BigCircle; // 0x458(0x08)
	struct UImage* Border; // 0x460(0x08)
	struct UButtonPrompt_BP_C* ButtonPrompt_BP; // 0x468(0x08)
	struct UImage* Circle; // 0x470(0x08)
	struct UImage* Circle_2; // 0x478(0x08)
	struct UImage* Image; // 0x480(0x08)
	struct UImage* Image_2; // 0x488(0x08)
	struct UImage* Image_3; // 0x490(0x08)
	struct UImage* Image_4; // 0x498(0x08)
	struct UImage* Image_144; // 0x4a0(0x08)
	struct UImage* Image_188; // 0x4a8(0x08)
	struct UOverlay* InfoOverlay; // 0x4b0(0x08)
	struct UTextBlock* ItemDescription_2; // 0x4b8(0x08)
	struct UTextBlock* ItemName; // 0x4c0(0x08)
	struct UTextBlock* ItemTitle_2; // 0x4c8(0x08)
	struct UImage* Line; // 0x4d0(0x08)
	struct UImage* NameLine_2; // 0x4d8(0x08)
	struct UOverlay* NameOverlay; // 0x4e0(0x08)
	struct UTextBlock* NonsenseNumbers; // 0x4e8(0x08)
	struct UTextBlock* NonsenseNumbers_2; // 0x4f0(0x08)
	struct UOverlay* NonsenseOverlay; // 0x4f8(0x08)
	struct UImage* PriceLine; // 0x500(0x08)
	struct UOverlay* PriceOverlay; // 0x508(0x08)
	struct UImage* scannerFill; // 0x510(0x08)
	struct UImage* scannerInner; // 0x518(0x08)
	struct UImage* scannerOuter; // 0x520(0x08)
	struct UImage* SOft_BG; // 0x528(0x08)
	struct UImage* Tab; // 0x530(0x08)
	struct UTextBlock* TextBlock_319; // 0x538(0x08)
	float holdDownTimeComplete; // 0x540(0x04)
	bool holding; // 0x544(0x01)
	bool shouldAllowPurchase; // 0x545(0x01)
	char pad_546[0x2]; // 0x546(0x02)
	struct FText buyingHoldTitle; // 0x548(0x18)
	struct FText sellingHoldTitle; // 0x560(0x18)
	bool preparingToHide; // 0x578(0x01)
	bool IsActive; // 0x579(0x01)
	enum class EPromptWidgetState LastState; // 0x57a(0x01)
	bool showPrice; // 0x57b(0x01)
	bool showName; // 0x57c(0x01)
	bool canTap; // 0x57d(0x01)
	char pad_57E[0x2]; // 0x57e(0x02)
	struct FMulticastInlineDelegate NewEventDispatcher_1; // 0x580(0x30)
	bool scanComplete; // 0x5b0(0x01)
	char pad_5B1[0x7]; // 0x5b1(0x07)
	struct FString nonsenseNumbersText; // 0x5b8(0x10)
	float nonsenseNumbersHoldTime; // 0x5c8(0x04)
	struct FVector2D nonsenseNumbersRange; // 0x5cc(0x08)
	char pad_5D4[0x4]; // 0x5d4(0x04)
	struct TMap<struct UOverlay*, struct FWidgetTransform> overlayBaseTransforms; // 0x5d8(0x50)
	bool IsScanning; // 0x628(0x01)
	char pad_629[0x7]; // 0x629(0x07)
	struct UDataTable* nonsenseNumbersDataTable; // 0x630(0x08)
	struct TArray<struct FString> cachedNonsenseNumbers; // 0x638(0x10)

	void GetNonsenseAdditive(float Delta, struct FString& Text); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.GetNonsenseAdditive // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void CacheNonsenseNumbers(); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.CacheNonsenseNumbers // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetBaseOverlayTransform(struct UOverlay* OverlayObject, struct FVector2D& Translation, struct FVector2D& Scale, struct FVector2D& Shear, float& Angle); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.GetBaseOverlayTransform // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void CacheOverlayTransforms(); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.CacheOverlayTransforms // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ParseLineBreaks(struct FString rawString, struct FText& parsedText); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.ParseLineBreaks // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void SetOffsets(struct FVector2D nameOffset, struct FVector2D priceOffset, struct FVector2D infoOffset, struct FVector2D nonsenseOffset); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.SetOffsets // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void FillPurchaseData(struct FText Name, int32_t price, struct FText Description, bool playerIsBuying, bool enableHoldDown, float holdTime, struct FVector2D nameOffset, struct FVector2D priceOffset, struct FVector2D infoOffset, struct FVector2D nonsenseOffset); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.FillPurchaseData // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BP_StateChanged(enum class EPromptWidgetState NewState, enum class EPromptWidgetState OldState); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.BP_StateChanged // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void InteractHoldComplete(bool FullyActivated); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.InteractHoldComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AnimateScanner(float Percent); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.AnimateScanner // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1953910
	void InteractButtonWasReleased(); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.InteractButtonWasReleased // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InteractButtonWasPressed(float HeldTime); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.InteractButtonWasPressed // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Construct(); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1953910
	void GenerateNonsenseNumbers_OLD(float Lerp); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.GenerateNonsenseNumbers_OLD // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UpdatePromptState(); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.UpdatePromptState // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ForceStopScanning(); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.ForceStopScanning // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GenerateNonsenseNumbers(float Delta); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.GenerateNonsenseNumbers // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DetectiveMode_Analysis_Widget(int32_t EntryPoint); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.ExecuteUbergraph_DetectiveMode_Analysis_Widget // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
	void NewEventDispatcher_0__DelegateSignature(); // Function DetectiveMode_Analysis_Widget.DetectiveMode_Analysis_Widget_C.NewEventDispatcher_0__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

