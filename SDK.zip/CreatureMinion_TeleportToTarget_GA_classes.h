// BlueprintGeneratedClass CreatureMinion_TeleportToTarget_GA.CreatureMinion_TeleportToTarget_GA_C
// Size: 0x414 (Inherited: 0x3f8)
struct UCreatureMinion_TeleportToTarget_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct AActor* TargetActor; // 0x400(0x08)
	struct AORCharacter* OwningCharacter; // 0x408(0x08)
	float RangeRadius; // 0x410(0x04)

	void K2_ActivateAbility(); // Function CreatureMinion_TeleportToTarget_GA.CreatureMinion_TeleportToTarget_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetOwnerFromActor(struct AActor* Actor, bool& Success); // Function CreatureMinion_TeleportToTarget_GA.CreatureMinion_TeleportToTarget_GA_C.SetOwnerFromActor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetTargetFromActor(struct AActor* Actor, bool& Success); // Function CreatureMinion_TeleportToTarget_GA.CreatureMinion_TeleportToTarget_GA_C.SetTargetFromActor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnFinish_98705ED44D7FC024397D54A2563B0D24(); // Function CreatureMinion_TeleportToTarget_GA.CreatureMinion_TeleportToTarget_GA_C.OnFinish_98705ED44D7FC024397D54A2563B0D24 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_CommitExecute(); // Function CreatureMinion_TeleportToTarget_GA.CreatureMinion_TeleportToTarget_GA_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_CreatureMinion_TeleportToTarget_GA(int32_t EntryPoint); // Function CreatureMinion_TeleportToTarget_GA.CreatureMinion_TeleportToTarget_GA_C.ExecuteUbergraph_CreatureMinion_TeleportToTarget_GA // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

