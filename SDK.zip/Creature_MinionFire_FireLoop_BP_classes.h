// BlueprintGeneratedClass Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C
// Size: 0x1ec (Inherited: 0x180)
struct UCreature_MinionFire_FireLoop_BP_C : UORFireLoop_CreatureMinionFire {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x180(0x08)
	struct TArray<struct UORScriptComponent*> ScriptComponents; // 0x188(0x10)
	struct ACreature_WeaponAttachment_BP_C* CreatureWeaponAttachment; // 0x198(0x08)
	struct FGameplayTagContainer MinionInteractableScannableTags; // 0x1a0(0x20)
	struct UCreature_HighImpactMinionFire_FireLoop_BP_C* HighImpactMinionFireFireLoop; // 0x1c0(0x08)
	struct FGameplayTag HighImpactMinionFireMode; // 0x1c8(0x08)
	struct FGameplayTag MyFireMode; // 0x1d0(0x08)
	struct UCreature_MindControl_FireLoop_BP_C* MindControlFireLoop; // 0x1d8(0x08)
	struct FGameplayTag MindControlFireMode; // 0x1e0(0x08)
	float DelayBeforeCharging; // 0x1e8(0x04)

	struct TArray<struct UORScriptComponent*> GetScriptComponents(); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.GetScriptComponents // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	bool CanFire(); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.CanFire // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ADSOn(bool& ADSOn); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.ADSOn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void DisablePreview(); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.DisablePreview // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void EnablePreview(); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.EnablePreview // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StopCharging(); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.StopCharging // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StartCharging(bool ResetCharge); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.StartCharging // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetupPreviewSC(); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.SetupPreviewSC // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetupChargeSC(); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.SetupChargeSC // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetScriptComponents(struct TArray<struct UORScriptComponent*>& ScriptComponents); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.SetScriptComponents // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BeginFireLoop(); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.BeginFireLoop // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void BP_Init(struct FGameplayTag ModeKey); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.BP_Init // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void EndFireLoop(); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.EndFireLoop // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BP_PostInit(); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.BP_PostInit // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void CancelFireLoop(); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.CancelFireLoop // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UpdatePreviewLastHitResult(); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.UpdatePreviewLastHitResult // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_MinionFire_FireLoop_BP(int32_t EntryPoint); // Function Creature_MinionFire_FireLoop_BP.Creature_MinionFire_FireLoop_BP_C.ExecuteUbergraph_Creature_MinionFire_FireLoop_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

