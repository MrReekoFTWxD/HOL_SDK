// BlueprintGeneratedClass Chonk_ArcSingleShot_FriendlyFire_FiringResult_BP.Chonk_ArcSingleShot_FriendlyFire_FiringResult_BP_C
// Size: 0x2c8 (Inherited: 0x2c8)
struct UChonk_ArcSingleShot_FriendlyFire_FiringResult_BP_C : UORFiringResult_Projectile {

	struct FVector GetAimLocation(bool bUseAimCorrections); // Function Chonk_ArcSingleShot_FriendlyFire_FiringResult_BP.Chonk_ArcSingleShot_FriendlyFire_FiringResult_BP_C.GetAimLocation // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

