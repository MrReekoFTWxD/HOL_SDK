// BlueprintGeneratedClass Creature_ArchersFocusMinionFire_FireLoop_BP.Creature_ArchersFocusMinionFire_FireLoop_BP_C
// Size: 0x230 (Inherited: 0x1ec)
struct UCreature_ArchersFocusMinionFire_FireLoop_BP_C : UCreature_MinionFire_FireLoop_BP_C {
	char pad_1EC[0x4]; // 0x1ec(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1f0(0x08)
	struct FTimerHandle EndTimeDilationTimer; // 0x1f8(0x08)
	float MaxTimeDilationTime; // 0x200(0x04)
	float TimeDilationSlow; // 0x204(0x04)
	struct FScalableFloat MaxChargeLevel; // 0x208(0x28)

	void StopCharging(); // Function Creature_ArchersFocusMinionFire_FireLoop_BP.Creature_ArchersFocusMinionFire_FireLoop_BP_C.StopCharging // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void EndTimeDilation(); // Function Creature_ArchersFocusMinionFire_FireLoop_BP.Creature_ArchersFocusMinionFire_FireLoop_BP_C.EndTimeDilation // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BP_Init(struct FGameplayTag ModeKey); // Function Creature_ArchersFocusMinionFire_FireLoop_BP.Creature_ArchersFocusMinionFire_FireLoop_BP_C.BP_Init // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnChargeLevelChanged(struct UORGlobalEventPayload* EventData); // Function Creature_ArchersFocusMinionFire_FireLoop_BP.Creature_ArchersFocusMinionFire_FireLoop_BP_C.OnChargeLevelChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_ArchersFocusMinionFire_FireLoop_BP(int32_t EntryPoint); // Function Creature_ArchersFocusMinionFire_FireLoop_BP.Creature_ArchersFocusMinionFire_FireLoop_BP_C.ExecuteUbergraph_Creature_ArchersFocusMinionFire_FireLoop_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

