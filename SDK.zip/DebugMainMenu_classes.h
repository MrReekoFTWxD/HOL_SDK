// WidgetBlueprintGeneratedClass DebugMainMenu.DebugMainMenu_C
// Size: 0x441 (Inherited: 0x3b1)
struct UDebugMainMenu_C : UDebugMenu_C {
	char pad_3B1[0x7]; // 0x3b1(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3b8(0x08)
	struct UWidgetSwitcher* Content; // 0x3c0(0x08)
	struct UHorizontalBox* Labels; // 0x3c8(0x08)
	struct TMap<struct FName, struct UDebugMenu_C*> DebugMenus; // 0x3d0(0x50)
	struct TArray<struct UDebugTabHeader_C*> LabelWidgets; // 0x420(0x10)
	struct TArray<struct UDebugMenu_C*> TabWidgets; // 0x430(0x10)
	bool AddedTabs; // 0x440(0x01)

	void UpdateDeviceType(enum class EInputDeviceType DeviceType); // Function DebugMainMenu.DebugMainMenu_C.UpdateDeviceType // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UpdateActiveWidget(); // Function DebugMainMenu.DebugMainMenu_C.UpdateActiveWidget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InitializeTabs(); // Function DebugMainMenu.DebugMainMenu_C.InitializeTabs // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugMainMenu.DebugMainMenu_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct FEventReply OnPreviewKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function DebugMainMenu.DebugMainMenu_C.OnPreviewKeyDown // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Construct(); // Function DebugMainMenu.DebugMainMenu_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1953910
	void LabelClicked(int32_t Index); // Function DebugMainMenu.DebugMainMenu_C.LabelClicked // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BindAllLabelButtons(); // Function DebugMainMenu.DebugMainMenu_C.BindAllLabelButtons // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnUIManagerInputDeviceChanged_Event_1(enum class EInputDeviceType NewInputDevice); // Function DebugMainMenu.DebugMainMenu_C.OnUIManagerInputDeviceChanged_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugMainMenu(int32_t EntryPoint); // Function DebugMainMenu.DebugMainMenu_C.ExecuteUbergraph_DebugMainMenu // (Final|UbergraphFunction) // @ game+0x1953910
};

