// BlueprintGeneratedClass Creature_PoppinMinionMod_GE.Creature_PoppinMinionMod_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreature_PoppinMinionMod_GE_C : UORGameplayEffect {
};

