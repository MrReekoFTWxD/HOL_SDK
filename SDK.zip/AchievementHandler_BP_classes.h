// BlueprintGeneratedClass AchievementHandler_BP.AchievementHandler_BP_C
// Size: 0x90 (Inherited: 0x28)
struct UAchievementHandler_BP_C : UORAchievementSubsystemHandler {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x28(0x08)
	bool AchievementsCached; // 0x30(0x01)
	bool Descriptions Cached; // 0x31(0x01)
	bool PlayerIsSetUp; // 0x32(0x01)
	bool PlayerIsSettingUp; // 0x33(0x01)
	bool Cache Achievement Descriptions; // 0x34(0x01)
	bool Min Progress 1%; // 0x35(0x01)
	bool SaveAfterUnlockingAchievement; // 0x36(0x01)
	bool CanAwardAlreadyCompletedAchievements; // 0x37(0x01)
	float Cache Initial Delay; // 0x38(0x04)
	float Cache Retry Time; // 0x3c(0x04)
	float PlayerSetupDelay; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct FGameplayTagContainer TradingCardMatches; // 0x48(0x20)
	struct TArray<struct FGameplayTag> TradingCardsList; // 0x68(0x10)
	struct AORCharacter* CachedORPlayerCharacter; // 0x78(0x08)
	struct FTimerHandle WaitForPlayerValid; // 0x80(0x08)
	struct FTimerHandle WaitForHunterChallengeFixUp; // 0x88(0x08)

	void FixUpAchievements(); // Function AchievementHandler_BP.AchievementHandler_BP_C.FixUpAchievements // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetupNewGame(); // Function AchievementHandler_BP.AchievementHandler_BP_C.SetupNewGame // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void WriteCombatStatToLeaderboard(int32_t StatValue, struct FName StatBasedAchievementRowName, bool& Wrote Stat Successfully, struct FName& Stat Name, int32_t& Stat New Value, int32_t& Stat Max Value, float& Percentage Complete); // Function AchievementHandler_BP.AchievementHandler_BP_C.WriteCombatStatToLeaderboard // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnFailure_F5B1B17A40E65F1E422DE4B2040566A4(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnFailure_F5B1B17A40E65F1E422DE4B2040566A4 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnSuccess_F5B1B17A40E65F1E422DE4B2040566A4(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnSuccess_F5B1B17A40E65F1E422DE4B2040566A4 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnFailure_66CE593143E777708052329F0F8560CC(); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnFailure_66CE593143E777708052329F0F8560CC // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnSuccess_66CE593143E777708052329F0F8560CC(); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnSuccess_66CE593143E777708052329F0F8560CC // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnFailure_EF65249B41844C8272E99B97AA1C415A(); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnFailure_EF65249B41844C8272E99B97AA1C415A // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnSuccess_EF65249B41844C8272E99B97AA1C415A(); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnSuccess_EF65249B41844C8272E99B97AA1C415A // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnFailure_E324CC8F491BA969BDE7B5B55D80AA32(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnFailure_E324CC8F491BA969BDE7B5B55D80AA32 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnSuccess_E324CC8F491BA969BDE7B5B55D80AA32(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnSuccess_E324CC8F491BA969BDE7B5B55D80AA32 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnFailure_302890424F0522A4AD187BB60052688C(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnFailure_302890424F0522A4AD187BB60052688C // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnSuccess_302890424F0522A4AD187BB60052688C(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnSuccess_302890424F0522A4AD187BB60052688C // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnFailure_15B963E84609CB7407A79D8BA44CA5ED(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnFailure_15B963E84609CB7407A79D8BA44CA5ED // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnSuccess_15B963E84609CB7407A79D8BA44CA5ED(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnSuccess_15B963E84609CB7407A79D8BA44CA5ED // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void HandleNewGame(); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleNewGame // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void HandleStatBasedAchievementProgress(struct FName DataTableRowName, int32_t PrevValue, int32_t CurrentValue, int32_t MaxValue); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleStatBasedAchievementProgress // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void HandleStatBasedAchievementComplete(struct FName DataTableRowName, int32_t MaxValue); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleStatBasedAchievementComplete // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ActivateStatBasedAchievementByRowName(struct FName DataTableRowName, int32_t StartingStatValue); // Function AchievementHandler_BP.AchievementHandler_BP_C.ActivateStatBasedAchievementByRowName // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void HandleOnDeinitialize(); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleOnDeinitialize // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void HandleOnInitialize(); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleOnInitialize // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void HandleNewDebugGame(); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleNewDebugGame // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void HandleAddToAchievementProgress(struct FName DataTableName, int32_t Progress); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleAddToAchievementProgress // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void HandleResetAchievements(); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleResetAchievements // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void New Game(); // Function AchievementHandler_BP.AchievementHandler_BP_C.New Game // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void HandleSetAchievementStat(struct FString AchievementName, int32_t Value); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleSetAchievementStat // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void CacheAchievements(); // Function AchievementHandler_BP.AchievementHandler_BP_C.CacheAchievements // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AwardAchievement(struct FName DataTableRowName); // Function AchievementHandler_BP.AchievementHandler_BP_C.AwardAchievement // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void HandleSetAchievementPercent(struct FString AchievementName, float Percent); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleSetAchievementPercent // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void SetupNewPlayer(); // Function AchievementHandler_BP.AchievementHandler_BP_C.SetupNewPlayer // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void On Currency Changed(struct FGameplayTag Currency, int32_t PreviousCount, int32_t NewCount, enum class EInventoryTransactionType TransactionType); // Function AchievementHandler_BP.AchievementHandler_BP_C.On Currency Changed // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void HandleSetupNewPlayer(); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleSetupNewPlayer // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void RecheckPlayerValidity(); // Function AchievementHandler_BP.AchievementHandler_BP_C.RecheckPlayerValidity // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InventoryIsLoaded(struct UORCharacterInventory* Inventory); // Function AchievementHandler_BP.AchievementHandler_BP_C.InventoryIsLoaded // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void HunterChallengeFixupComplete(); // Function AchievementHandler_BP.AchievementHandler_BP_C.HunterChallengeFixupComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_AchievementHandler_BP(int32_t EntryPoint); // Function AchievementHandler_BP.AchievementHandler_BP_C.ExecuteUbergraph_AchievementHandler_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

