// BlueprintGeneratedClass Chonk_Reload_GA.Chonk_Reload_GA_C
// Size: 0x468 (Inherited: 0x468)
struct UChonk_Reload_GA_C : UHenchman_ReloadPrimary_GA_C {
};

