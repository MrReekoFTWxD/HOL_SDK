// BlueprintGeneratedClass Enemy_Grenade_Used_GE.Enemy_Grenade_Used_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UEnemy_Grenade_Used_GE_C : UORGameplayEffect {
};

