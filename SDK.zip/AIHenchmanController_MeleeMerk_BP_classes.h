// BlueprintGeneratedClass AIHenchmanController_MeleeMerk_BP.AIHenchmanController_MeleeMerk_BP_C
// Size: 0x8d8 (Inherited: 0x8d8)
struct AAIHenchmanController_MeleeMerk_BP_C : AAIHenchmanController_Merk_BP_C {
};

