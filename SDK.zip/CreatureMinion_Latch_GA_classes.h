// BlueprintGeneratedClass CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C
// Size: 0x4b0 (Inherited: 0x3f8)
struct UCreatureMinion_Latch_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct ACreatureMinion_Base_BP_C* CreatureMinion_Cached; // 0x400(0x08)
	struct AORCharacter* LatchTarget_Cached; // 0x408(0x08)
	struct ACreature_MinionLatched_Attachement_BP_C* LatchedMinionAttachmentActor; // 0x410(0x08)
	struct AActor* MinionAttachmentActorClass; // 0x418(0x08)
	struct UORSocketReservationComponent* Socket Reservation Component Cached; // 0x420(0x08)
	struct FORSocketData AttachSocketData; // 0x428(0x10)
	struct TArray<struct UGameplayEffect*> MinionLatchedGEs; // 0x438(0x10)
	struct TArray<struct FActiveGameplayEffectHandle> MinionLatchedActiveGEs; // 0x448(0x10)
	struct FGameplayTag DeadStatusGameplayTag; // 0x458(0x08)
	float PoppinMinionsTriggerDistance; // 0x460(0x04)
	char pad_464[0x4]; // 0x464(0x04)
	struct UParticleSystem* TargetKilledParticleFX; // 0x468(0x08)
	bool DisablePoppinMinions; // 0x470(0x01)
	bool NeverChangeTarget; // 0x471(0x01)
	char pad_472[0x6]; // 0x472(0x06)
	struct TArray<struct UGameplayEffect*> NecroMinionLatchedGEs; // 0x478(0x10)
	struct UGameplayEffect* RepeatingLatchGE; // 0x488(0x08)
	struct UGameplayEffect* NecroRepeatingLatchGE; // 0x490(0x08)
	struct UORGoopArmorComponent* GoopArmorComp_Cached; // 0x498(0x08)
	struct FGameplayTag LatchSocketType; // 0x4a0(0x08)
	float FastBiteSpeedTime; // 0x4a8(0x04)
	float MediumBiteSpeedTime; // 0x4ac(0x04)

	void GetAttachmentActorClass(struct AActor*& ActorClass); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.GetAttachmentActorClass // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void GetAttachedSocketLocation(struct FVector& AttachedSocketLocation); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.GetAttachedSocketLocation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void LatchTargetSocketFreed(struct FORSocketData Socket); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.LatchTargetSocketFreed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void LatchTargetDestroyed(struct AActor* DestroyedActor); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.LatchTargetDestroyed // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void LatchTargetDied(struct UObject* Killer, struct AORCharacter* Killed, struct FHitResult& HitResult, struct FGameplayTagContainer& DamageTags); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.LatchTargetDied // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void MinionDied(); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.MinionDied // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void MoveMinionToLatchSocketPosition(); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.MoveMinionToLatchSocketPosition // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void RemoveLatchedMinion(); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.RemoveLatchedMinion // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AddLatchedMinion(); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.AddLatchedMinion // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Added_EB3718CA474CEED9D71A919C4F6A20ED(); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.Added_EB3718CA474CEED9D71A919C4F6A20ED // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnNotifyEnd_150E3CDF4018A0CF2C971989AD44AD41(struct FName NotifyName); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnNotifyEnd_150E3CDF4018A0CF2C971989AD44AD41 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnNotifyBegin_150E3CDF4018A0CF2C971989AD44AD41(struct FName NotifyName); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnNotifyBegin_150E3CDF4018A0CF2C971989AD44AD41 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnInterrupted_150E3CDF4018A0CF2C971989AD44AD41(struct FName NotifyName); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnInterrupted_150E3CDF4018A0CF2C971989AD44AD41 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnBlendOut_150E3CDF4018A0CF2C971989AD44AD41(struct FName NotifyName); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnBlendOut_150E3CDF4018A0CF2C971989AD44AD41 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_150E3CDF4018A0CF2C971989AD44AD41(struct FName NotifyName); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnCompleted_150E3CDF4018A0CF2C971989AD44AD41 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnNotifyEnd_CB26BEDE482044F418F8EC8F99AE90E7(struct FName NotifyName); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnNotifyEnd_CB26BEDE482044F418F8EC8F99AE90E7 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnNotifyBegin_CB26BEDE482044F418F8EC8F99AE90E7(struct FName NotifyName); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnNotifyBegin_CB26BEDE482044F418F8EC8F99AE90E7 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnInterrupted_CB26BEDE482044F418F8EC8F99AE90E7(struct FName NotifyName); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnInterrupted_CB26BEDE482044F418F8EC8F99AE90E7 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnBlendOut_CB26BEDE482044F418F8EC8F99AE90E7(struct FName NotifyName); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnBlendOut_CB26BEDE482044F418F8EC8F99AE90E7 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_CB26BEDE482044F418F8EC8F99AE90E7(struct FName NotifyName); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnCompleted_CB26BEDE482044F418F8EC8F99AE90E7 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnFinish_7BA1452D47ED322109B00985836EB9BB(); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnFinish_7BA1452D47ED322109B00985836EB9BB // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnNotifyEnd_AB942EE04DC63658778A8CBB05399A20(struct FName NotifyName); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnNotifyEnd_AB942EE04DC63658778A8CBB05399A20 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnNotifyBegin_AB942EE04DC63658778A8CBB05399A20(struct FName NotifyName); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnNotifyBegin_AB942EE04DC63658778A8CBB05399A20 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnInterrupted_AB942EE04DC63658778A8CBB05399A20(struct FName NotifyName); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnInterrupted_AB942EE04DC63658778A8CBB05399A20 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnBlendOut_AB942EE04DC63658778A8CBB05399A20(struct FName NotifyName); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnBlendOut_AB942EE04DC63658778A8CBB05399A20 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_AB942EE04DC63658778A8CBB05399A20(struct FName NotifyName); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnCompleted_AB942EE04DC63658778A8CBB05399A20 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnFinish_D0C746E0497FD15691A09DB56AEF08D9(); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnFinish_D0C746E0497FD15691A09DB56AEF08D9 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void K2_CommitExecute(); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void HandleEarlyCancel(); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.HandleEarlyCancel // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnDamageTakenTarget(struct UObject* Damager, struct AORCharacter* Damaged, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.OnDamageTakenTarget // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void MainTargetActorChanged(struct AActor* OldMainTarget, struct AActor* NewMainTarget); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.MainTargetActorChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void TickDamage(); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.TickDamage // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_CreatureMinion_Latch_GA(int32_t EntryPoint); // Function CreatureMinion_Latch_GA.CreatureMinion_Latch_GA_C.ExecuteUbergraph_CreatureMinion_Latch_GA // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

