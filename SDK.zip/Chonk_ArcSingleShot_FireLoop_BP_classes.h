// BlueprintGeneratedClass Chonk_ArcSingleShot_FireLoop_BP.Chonk_ArcSingleShot_FireLoop_BP_C
// Size: 0x135 (Inherited: 0x135)
struct UChonk_ArcSingleShot_FireLoop_BP_C : UORTestEnemyWeapons_FireLoop_C {
};

