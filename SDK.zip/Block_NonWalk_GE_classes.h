// BlueprintGeneratedClass Block_NonWalk_GE.Block_NonWalk_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UBlock_NonWalk_GE_C : UORGameplayEffect {
};

