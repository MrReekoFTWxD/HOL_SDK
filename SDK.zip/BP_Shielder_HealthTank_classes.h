// BlueprintGeneratedClass BP_Shielder_HealthTank.BP_Shielder_HealthTank_C
// Size: 0x338 (Inherited: 0x330)
struct ABP_Shielder_HealthTank_C : AORHealthTankItem {
	struct USceneComponent* DefaultSceneRoot; // 0x330(0x08)
};

