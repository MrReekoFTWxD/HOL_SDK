// BlueprintGeneratedClass Creature_MinionFire_RecoilCameraShake.Creature_MinionFire_RecoilCameraShake_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UCreature_MinionFire_RecoilCameraShake_C : UMatineeCameraShake {
};

