// BlueprintGeneratedClass Chonk_ProximityMine_Projectile_Thrown_BP.Chonk_ProximityMine_Projectile_Thrown_BP_C
// Size: 0x439 (Inherited: 0x439)
struct AChonk_ProximityMine_Projectile_Thrown_BP_C : AChonk_ProximityMine_Projectile_BP_C {
};

