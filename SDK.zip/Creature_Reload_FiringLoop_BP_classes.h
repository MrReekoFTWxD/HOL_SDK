// BlueprintGeneratedClass Creature_Reload_FiringLoop_BP.Creature_Reload_FiringLoop_BP_C
// Size: 0x88 (Inherited: 0x88)
struct UCreature_Reload_FiringLoop_BP_C : UReloadFireLoop_BP_C {
};

