// Class ActorSequence.ActorSequence
// Size: 0x90 (Inherited: 0x68)
struct UActorSequence : UMovieSceneSequence {
	struct UMovieScene* MovieScene; // 0x68(0x08)
	struct FActorSequenceObjectReferenceMap ObjectReferences; // 0x70(0x20)
};

// Class ActorSequence.ActorSequenceComponent
// Size: 0xd8 (Inherited: 0xb0)
struct UActorSequenceComponent : UActorComponent {
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0xb0(0x14)
	char pad_C4[0x4]; // 0xc4(0x04)
	struct UActorSequence* Sequence; // 0xc8(0x08)
	struct UActorSequencePlayer* SequencePlayer; // 0xd0(0x08)
};

// Class ActorSequence.ActorSequencePlayer
// Size: 0x598 (Inherited: 0x598)
struct UActorSequencePlayer : UMovieSceneSequencePlayer {
};

