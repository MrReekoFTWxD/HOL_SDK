// BlueprintGeneratedClass ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C
// Size: 0x4fc (Inherited: 0x3d0)
struct AChefStand_InteractionStation_BP_C : AInteractionStation_BP_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d0(0x08)
	struct USceneComponent* SyncedAnimTargetPoint; // 0x3d8(0x08)
	struct USyncedPlayerAnimationComponent* SyncedPlayerAnimation; // 0x3e0(0x08)
	struct TArray<struct FGameplayTag> ConversationObjectives; // 0x3e8(0x10)
	struct FMulticastInlineDelegate StartBlortoConversation; // 0x3f8(0x30)
	bool AllowPlayerExitShop; // 0x428(0x01)
	char pad_429[0x3]; // 0x429(0x03)
	float EnterShopMenuOpenDelay; // 0x42c(0x04)
	struct FMulticastInlineDelegate PlayerEnter; // 0x430(0x30)
	struct FMulticastInlineDelegate ItemPurchased; // 0x460(0x30)
	struct FMulticastInlineDelegate PlayerExit; // 0x490(0x30)
	struct TArray<struct FGameplayTag> ItemsPurchasedThisTime; // 0x4c0(0x10)
	bool IsRecentReturnToShop; // 0x4d0(0x01)
	char pad_4D1[0x7]; // 0x4d1(0x07)
	struct FTimerHandle RecentReturnTimer; // 0x4d8(0x08)
	bool ShouldInstallWarpDisc; // 0x4e0(0x01)
	bool IsPlayingWarpDiscInstall; // 0x4e1(0x01)
	char pad_4E2[0x2]; // 0x4e2(0x02)
	float EquipDelayDuration; // 0x4e4(0x04)
	struct AActor* FocusActor_Blorto; // 0x4e8(0x08)
	bool IsMenuOpen; // 0x4f0(0x01)
	char pad_4F1[0x3]; // 0x4f1(0x03)
	struct FGameplayTag FirstMeetMissionBool; // 0x4f4(0x08)

	void GetOverrideComponentToFace(struct USceneComponent*& ComponentToFace); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.GetOverrideComponentToFace // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ClearIsRecentReturn(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ClearIsRecentReturn // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void PurchaseItem(struct FChefStandTransactionData TransactionData, enum class ChefStandTransactionResult& Result, int32_t& AmountPurchased); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.PurchaseItem // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ResumeExitShop(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ResumeExitShop // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ShouldStartBlortoConversation(bool& StartConversation, struct FGameplayTag& ObjectiveTag); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ShouldStartBlortoConversation // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ResumeOpenShop(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ResumeOpenShop // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnStationExited(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.OnStationExited // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void StartEntranceAnimation(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.StartEntranceAnimation // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void StartExitAnimation(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.StartExitAnimation // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void NavigateBack(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.NavigateBack // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnWarpDiscInstallComplete(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.OnWarpDiscInstallComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnStationEntered(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.OnStationEntered // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void PlaySitDownAnimation(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.PlaySitDownAnimation // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void RaiseGunAfterStanding(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.RaiseGunAfterStanding // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void FinishedEntrance(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.FinishedEntrance // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__ChefStand_InteractionStation_BP_SyncedPlayerAnimation_K2Node_ComponentBoundEvent_0_SyncedAnimationComponentEvent__DelegateSignature(struct USyncedPlayerAnimationComponent* SyncedAnimationComponent); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.BndEvt__ChefStand_InteractionStation_BP_SyncedPlayerAnimation_K2Node_ComponentBoundEvent_0_SyncedAnimationComponentEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void OnCurrencyChangedDelegate(struct FGameplayTag Currency, int32_t PreviousCount, int32_t NewCount, enum class EInventoryTransactionType TransactionType); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.OnCurrencyChangedDelegate // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_ChefStand_InteractionStation_BP(int32_t EntryPoint); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ExecuteUbergraph_ChefStand_InteractionStation_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
	void PlayerExit__DelegateSignature(struct TArray<struct FGameplayTag>& ItemsPurchased); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.PlayerExit__DelegateSignature // (Public|Delegate|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ItemPurchased__DelegateSignature(struct FGameplayTag ItemTag, enum class ChefStandTransactionResult Result); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ItemPurchased__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void PlayerEnter__DelegateSignature(bool IsRecentReturn); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.PlayerEnter__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StartBlortoConversation__DelegateSignature(struct FGameplayTag ObjectiveTag); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.StartBlortoConversation__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

