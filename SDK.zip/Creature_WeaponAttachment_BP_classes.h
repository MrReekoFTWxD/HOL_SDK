// BlueprintGeneratedClass Creature_WeaponAttachment_BP.Creature_WeaponAttachment_BP_C
// Size: 0x3d0 (Inherited: 0x380)
struct ACreature_WeaponAttachment_BP_C : AORItemAttach_Player {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x380(0x08)
	struct UORAkComponent* ORAk (Barrel); // 0x388(0x08)
	struct UORVocalizationComponent* ORVocalization; // 0x390(0x08)
	struct UParticleSystemComponent* WeaponModActivation; // 0x398(0x08)
	struct UWeaponModActivation_Component_C* WeaponModActivation_Component; // 0x3a0(0x08)
	struct UORBlinkComponent* ORBlink; // 0x3a8(0x08)
	struct UORAttentionComponent* ORAttention; // 0x3b0(0x08)
	struct UORAkComponent* ORAkPrimary; // 0x3b8(0x08)
	struct UEmotionComponent* Emotion; // 0x3c0(0x08)
	struct UORAkComponent* ORAk (Mouth); // 0x3c8(0x08)

	void ItemEquipped(); // Function Creature_WeaponAttachment_BP.Creature_WeaponAttachment_BP_C.ItemEquipped // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ItemUnequipped(); // Function Creature_WeaponAttachment_BP.Creature_WeaponAttachment_BP_C.ItemUnequipped // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ReceiveDestroyed(); // Function Creature_WeaponAttachment_BP.Creature_WeaponAttachment_BP_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function Creature_WeaponAttachment_BP.Creature_WeaponAttachment_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_WeaponAttachment_BP(int32_t EntryPoint); // Function Creature_WeaponAttachment_BP.Creature_WeaponAttachment_BP_C.ExecuteUbergraph_Creature_WeaponAttachment_BP // (Final|UbergraphFunction) // @ game+0x1953910
};

