// WidgetBlueprintGeneratedClass DebugMenu.DebugMenu_C
// Size: 0x3b1 (Inherited: 0x3a0)
struct UDebugMenu_C : UORWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a0(0x08)
	struct UDebugUI_C* DebugUIContainer; // 0x3a8(0x08)
	bool Initialized; // 0x3b0(0x01)

	void SetGridColumnFill(struct UGridPanel* Grid, struct TArray<float>& ColumnFills); // Function DebugMenu.DebugMenu_C.SetGridColumnFill // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetInventoryItemDisplayCategory(struct FGameplayTag ItemTag, enum class InventoryItemCategory_EN& DisplayCategory); // Function DebugMenu.DebugMenu_C.GetInventoryItemDisplayCategory // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void AddGridLabel(struct UGridPanel* Grid, struct FText Text, int32_t InRow, int32_t InColumn, enum class EHorizontalAlignment InHorizontalAlignment, enum class EVerticalAlignment InVerticalAlignment, struct UDebugMenuMissionLabel_C*& Label); // Function DebugMenu.DebugMenu_C.AddGridLabel // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Initialize(); // Function DebugMenu.DebugMenu_C.Initialize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function DebugMenu.DebugMenu_C.OnKeyDown // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Focus(); // Function DebugMenu.DebugMenu_C.Focus // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Construct(); // Function DebugMenu.DebugMenu_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugMenu(int32_t EntryPoint); // Function DebugMenu.DebugMenu_C.ExecuteUbergraph_DebugMenu // (Final|UbergraphFunction) // @ game+0x1953910
};

