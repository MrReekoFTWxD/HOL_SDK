// BlueprintGeneratedClass BTT_RecordFinishedCombatMove.BTT_RecordFinishedCombatMove_C
// Size: 0xb0 (Inherited: 0xa8)
struct UBTT_RecordFinishedCombatMove_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_RecordFinishedCombatMove.BTT_RecordFinishedCombatMove_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTT_RecordFinishedCombatMove(int32_t EntryPoint); // Function BTT_RecordFinishedCombatMove.BTT_RecordFinishedCombatMove_C.ExecuteUbergraph_BTT_RecordFinishedCombatMove // (Final|UbergraphFunction) // @ game+0x1953910
};

