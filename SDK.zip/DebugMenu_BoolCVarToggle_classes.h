// WidgetBlueprintGeneratedClass DebugMenu_BoolCVarToggle.DebugMenu_BoolCVarToggle_C
// Size: 0x2c8 (Inherited: 0x290)
struct UDebugMenu_BoolCVarToggle_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UORWidget_Button_BP_C* ORWidget_Button_BP; // 0x298(0x08)
	struct FText CVarValue; // 0x2a0(0x18)
	struct FString CVar; // 0x2b8(0x10)

	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugMenu_BoolCVarToggle.DebugMenu_BoolCVarToggle_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UpdateValue(); // Function DebugMenu_BoolCVarToggle.DebugMenu_BoolCVarToggle_C.UpdateValue // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void FlipValue(); // Function DebugMenu_BoolCVarToggle.DebugMenu_BoolCVarToggle_C.FlipValue // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetValueLabel(bool Override, bool OverrideValue); // Function DebugMenu_BoolCVarToggle.DebugMenu_BoolCVarToggle_C.SetValueLabel // (Private|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetValue(bool& Value); // Function DebugMenu_BoolCVarToggle.DebugMenu_BoolCVarToggle_C.GetValue // (Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void SetCVar(struct FString InCVar); // Function DebugMenu_BoolCVarToggle.DebugMenu_BoolCVarToggle_C.SetCVar // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function DebugMenu_BoolCVarToggle.DebugMenu_BoolCVarToggle_C.BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugMenu_BoolCVarToggle(int32_t EntryPoint); // Function DebugMenu_BoolCVarToggle.DebugMenu_BoolCVarToggle_C.ExecuteUbergraph_DebugMenu_BoolCVarToggle // (Final|UbergraphFunction) // @ game+0x1953910
};

