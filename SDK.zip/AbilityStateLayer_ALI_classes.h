// AnimBlueprintGeneratedClass AbilityStateLayer_ALI.AbilityStateLayer_ALI_C
// Size: 0x28 (Inherited: 0x28)
struct UAbilityStateLayer_ALI_C : UAnimLayerInterface {

	void AbilityStateLayer(struct FPoseLink InPose, struct FPoseLink& AbilityStateLayer); // Function AbilityStateLayer_ALI.AbilityStateLayer_ALI_C.AbilityStateLayer // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

