// BlueprintGeneratedClass Creature_MinionEggFire_Damage_GE.Creature_MinionEggFire_Damage_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreature_MinionEggFire_Damage_GE_C : UORGameplayEffect {
};

