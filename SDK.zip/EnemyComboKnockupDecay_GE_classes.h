// BlueprintGeneratedClass EnemyComboKnockupDecay_GE.EnemyComboKnockupDecay_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UEnemyComboKnockupDecay_GE_C : UORGameplayEffect {
};

