// BlueprintGeneratedClass ActivateWhenMined_GA.ActivateWhenMined_GA_C
// Size: 0x408 (Inherited: 0x3f8)
struct UActivateWhenMined_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct AProximityMine_BP_C* ProximityMine; // 0x400(0x08)

	void OnEffectApplied_A581AE3145728136C98999BF7C9ECED1(struct FActiveGameplayEffectHandle ActiveEffectHandle, struct FGameplayEffectSpecHandle EffectSpecHandle); // Function ActivateWhenMined_GA.ActivateWhenMined_GA_C.OnEffectApplied_A581AE3145728136C98999BF7C9ECED1 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function ActivateWhenMined_GA.ActivateWhenMined_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_ActivateWhenMined_GA(int32_t EntryPoint); // Function ActivateWhenMined_GA.ActivateWhenMined_GA_C.ExecuteUbergraph_ActivateWhenMined_GA // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

