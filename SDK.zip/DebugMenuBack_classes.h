// WidgetBlueprintGeneratedClass DebugMenuBack.DebugMenuBack_C
// Size: 0x2a8 (Inherited: 0x290)
struct UDebugMenuBack_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UORWidget_Button_BP_C* ORWidget_Button_BP; // 0x298(0x08)
	struct UDebugUI_C* DebugUI; // 0x2a0(0x08)

	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugMenuBack.DebugMenuBack_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function DebugMenuBack.DebugMenuBack_C.BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugMenuBack(int32_t EntryPoint); // Function DebugMenuBack.DebugMenuBack_C.ExecuteUbergraph_DebugMenuBack // (Final|UbergraphFunction) // @ game+0x1953910
};

