// BlueprintGeneratedClass CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C
// Size: 0x5e0 (Inherited: 0x4b0)
struct UCreatureMinion_MindControlLatch_GA_C : UCreatureMinion_Latch_GA_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4b0(0x08)
	struct UGameplayEffect* InfiniteLifeSpanGE; // 0x4b8(0x08)
	struct UGameplayEffect* MindControlGE; // 0x4c0(0x08)
	struct UGameplayEffect* StaggerGE; // 0x4c8(0x08)
	struct UGameplayEffect* RagdollGE; // 0x4d0(0x08)
	struct FActiveGameplayEffectHandle MindControlActiveGE; // 0x4d8(0x08)
	struct FActiveGameplayEffectHandle ExtendedMindControlActiveGE; // 0x4e0(0x08)
	struct FGameplayTag MinionLatchedEffectTag; // 0x4e8(0x08)
	struct FGameplayTag MindControlStatusEffectTag; // 0x4f0(0x08)
	struct UORAbilityTask_WaitGameplayEffectApplied* ListenForGameplayEffectAppliedTask; // 0x4f8(0x08)
	struct FGameplayTagContainer KillOnLatchBeginTags; // 0x500(0x20)
	struct FGameplayTagContainer KillOnLatchEndTags; // 0x520(0x20)
	struct FGameplayTagRequirements StaggerTagRequirements; // 0x540(0x40)
	bool KillMindControlMinion; // 0x580(0x01)
	char pad_581[0x7]; // 0x581(0x07)
	struct TMap<struct FGameplayTag, int32_t> StacksToExtendMindControlTagMap; // 0x588(0x50)
	int32_t DefaultStacksToExtendMindControl; // 0x5d8(0x04)
	int32_t StacksToExtendMindControl; // 0x5dc(0x04)

	void ShouldStaggerOnLatchEnd(struct AORCharacter* ORCharacter, bool& CanStagger); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.ShouldStaggerOnLatchEnd // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void ShouldKillOnLatchEnd(struct AORCharacter* ORCharacter, bool& CanInstaKill); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.ShouldKillOnLatchEnd // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void ShouldKillOnLatchBegin(struct AORCharacter* ORCharacter, bool& CanInstaKill); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.ShouldKillOnLatchBegin // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void ShouldExtendMindControlEffect(struct FActiveGameplayEffectHandle MindControlStrengthActiveGE, bool& ShouldTrigger); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.ShouldExtendMindControlEffect // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void CalcStacksToExtendMindControl(int32_t& StacksToMindControl); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.CalcStacksToExtendMindControl // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void GetExtendedMindControlTime(float& MindControlTime); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.GetExtendedMindControlTime // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetMindControlTime(float& MindControlTime); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.GetMindControlTime // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnEffectApplied_9EF249DE482268A7D0E11E91EBFA7067(struct FActiveGameplayEffectHandle ActiveEffectHandle, struct FGameplayEffectSpecHandle EffectSpecHandle); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.OnEffectApplied_9EF249DE482268A7D0E11E91EBFA7067 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InvalidHandle_3253EC214FD86753FE99E9863F501CF2(struct FGameplayEffectRemovalInfo& GameplayEffectRemovalInfo); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.InvalidHandle_3253EC214FD86753FE99E9863F501CF2 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnRemoved_3253EC214FD86753FE99E9863F501CF2(struct FGameplayEffectRemovalInfo& GameplayEffectRemovalInfo); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.OnRemoved_3253EC214FD86753FE99E9863F501CF2 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InvalidHandle_A7C33EAE49A102C307B5F2B8D5C3C574(struct FGameplayEffectRemovalInfo& GameplayEffectRemovalInfo); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.InvalidHandle_A7C33EAE49A102C307B5F2B8D5C3C574 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnRemoved_A7C33EAE49A102C307B5F2B8D5C3C574(struct FGameplayEffectRemovalInfo& GameplayEffectRemovalInfo); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.OnRemoved_A7C33EAE49A102C307B5F2B8D5C3C574 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void K2_CommitExecute(); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void HandleMindControlEffect(); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.HandleMindControlEffect // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void TickDamage(); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.TickDamage // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void TriggerMindControl(); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.TriggerMindControl // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void TriggerExtendedMindControl(); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.TriggerExtendedMindControl // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void EndMindConttrol(); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.EndMindConttrol // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_CreatureMinion_MindControlLatch_GA(int32_t EntryPoint); // Function CreatureMinion_MindControlLatch_GA.CreatureMinion_MindControlLatch_GA_C.ExecuteUbergraph_CreatureMinion_MindControlLatch_GA // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

