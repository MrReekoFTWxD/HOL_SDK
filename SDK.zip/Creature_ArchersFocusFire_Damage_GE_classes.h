// BlueprintGeneratedClass Creature_ArchersFocusFire_Damage_GE.Creature_ArchersFocusFire_Damage_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreature_ArchersFocusFire_Damage_GE_C : UORGameplayEffect {
};

