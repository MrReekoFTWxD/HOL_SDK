// BlueprintGeneratedClass Creature_Primary_MindControlMinion_Projectile_BP.Creature_Primary_MindControlMinion_Projectile_BP_C
// Size: 0x4d9 (Inherited: 0x4d9)
struct ACreature_Primary_MindControlMinion_Projectile_BP_C : ACreature_Primary_EggMinionPhysics_Projectile_BP_C {

	void InitCreatureMinion(struct ACreatureMinion_Base_BP_C* CreatureMinion); // Function Creature_Primary_MindControlMinion_Projectile_BP.Creature_Primary_MindControlMinion_Projectile_BP_C.InitCreatureMinion // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

