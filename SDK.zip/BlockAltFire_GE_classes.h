// BlueprintGeneratedClass BlockAltFire_GE.BlockAltFire_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UBlockAltFire_GE_C : UORGameplayEffect {
};

