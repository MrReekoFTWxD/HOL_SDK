// BlueprintGeneratedClass Douglas_InkShot_GE.Douglas_InkShot_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UDouglas_InkShot_GE_C : UORGameplayEffect {
};

