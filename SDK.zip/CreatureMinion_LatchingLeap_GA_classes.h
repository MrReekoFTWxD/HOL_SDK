// BlueprintGeneratedClass CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C
// Size: 0x464 (Inherited: 0x3f8)
struct UCreatureMinion_LatchingLeap_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct AActor* TargetActor; // 0x400(0x08)
	struct AORCharacter* OwningCharacter; // 0x408(0x08)
	struct UAnimMontage* TellMontage; // 0x410(0x08)
	struct UAnimMontage* LandMontage; // 0x418(0x08)
	struct FName AttackInstanceName; // 0x420(0x08)
	struct TArray<float> LaunchSpeeds; // 0x428(0x10)
	struct FVector TargetLeapLocation; // 0x438(0x0c)
	float LeapMontageSpeedRate; // 0x444(0x04)
	bool PlayTellMontage; // 0x448(0x01)
	char pad_449[0x7]; // 0x449(0x07)
	struct FTimerHandle TickingLaunchTimerHandle; // 0x450(0x08)
	float LatchDistance; // 0x458(0x04)
	float MaxJumpTime; // 0x45c(0x04)
	float MaxHomingTime; // 0x460(0x04)

	void CalcLaunchVelocity(struct FVector& Velocity); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.CalcLaunchVelocity // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void OnMeleeVolumeTriggered(struct AActor* SourceActor, int32_t VolumeIndex); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.OnMeleeVolumeTriggered // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnReachedLatchTarget(struct AORCharacter* TargetORCharacter); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.OnReachedLatchTarget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayAbilitySpecHandle Handle, struct FGameplayTagContainer& RelevantTags); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.K2_CanActivateAbility // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1953910
	void SetOwner(bool& Success); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.SetOwner // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetTargetFromOwningActor(struct AActor* OwningActor, bool& Success); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.SetTargetFromOwningActor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_508AD9F84EB117D966033C98091613A5(); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.OnCompleted_508AD9F84EB117D966033C98091613A5 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnTick_508AD9F84EB117D966033C98091613A5(float DeltaTime, float TotalElapsed); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.OnTick_508AD9F84EB117D966033C98091613A5 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCancelled_E97B30794444FCE650522CBA804FABD8(); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.OnCancelled_E97B30794444FCE650522CBA804FABD8 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnInterrupted_E97B30794444FCE650522CBA804FABD8(); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.OnInterrupted_E97B30794444FCE650522CBA804FABD8 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnBlendOut_E97B30794444FCE650522CBA804FABD8(); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.OnBlendOut_E97B30794444FCE650522CBA804FABD8 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_E97B30794444FCE650522CBA804FABD8(); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.OnCompleted_E97B30794444FCE650522CBA804FABD8 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_C26B6A9B4DB98E5A67258284E1D04E67(); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.OnCompleted_C26B6A9B4DB98E5A67258284E1D04E67 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnTick_C26B6A9B4DB98E5A67258284E1D04E67(float DeltaTime, float TotalElapsed); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.OnTick_C26B6A9B4DB98E5A67258284E1D04E67 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void TickingLaunch(); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.TickingLaunch // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_CommitExecute(); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_CreatureMinion_LatchingLeap_GA(int32_t EntryPoint); // Function CreatureMinion_LatchingLeap_GA.CreatureMinion_LatchingLeap_GA_C.ExecuteUbergraph_CreatureMinion_LatchingLeap_GA // (Final|UbergraphFunction) // @ game+0x1953910
};

