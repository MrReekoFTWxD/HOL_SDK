// BlueprintGeneratedClass Creature_ArchersFocusMod_GE.Creature_ArchersFocusMod_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreature_ArchersFocusMod_GE_C : UORGameplayEffect {
};

