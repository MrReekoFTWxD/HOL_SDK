// BlueprintGeneratedClass Damage_Immunity_GE.Damage_Immunity_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UDamage_Immunity_GE_C : UORGameplayEffect {
};

