// BlueprintGeneratedClass ArmorPlatedMyte_HeavyArmor_GA.ArmorPlatedMyte_HeavyArmor_GA_C
// Size: 0x470 (Inherited: 0x464)
struct UArmorPlatedMyte_HeavyArmor_GA_C : UHeavyArmor_Removable_GA_C {
	char pad_464[0x4]; // 0x464(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x468(0x08)

	void OnHeavyArmorDestroyed(); // Function ArmorPlatedMyte_HeavyArmor_GA.ArmorPlatedMyte_HeavyArmor_GA_C.OnHeavyArmorDestroyed // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_ArmorPlatedMyte_HeavyArmor_GA(int32_t EntryPoint); // Function ArmorPlatedMyte_HeavyArmor_GA.ArmorPlatedMyte_HeavyArmor_GA_C.ExecuteUbergraph_ArmorPlatedMyte_HeavyArmor_GA // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

