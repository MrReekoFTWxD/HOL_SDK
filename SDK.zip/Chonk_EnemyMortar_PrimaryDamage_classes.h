// BlueprintGeneratedClass Chonk_EnemyMortar_PrimaryDamage.Chonk_EnemyMortar_PrimaryDamage_C
// Size: 0x818 (Inherited: 0x818)
struct UChonk_EnemyMortar_PrimaryDamage_C : UORGameplayEffect {
};

