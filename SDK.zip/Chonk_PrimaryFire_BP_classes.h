// BlueprintGeneratedClass Chonk_PrimaryFire_BP.Chonk_PrimaryFire_BP_C
// Size: 0x448 (Inherited: 0x448)
struct UChonk_PrimaryFire_BP_C : UORGameplayAbility_Montage {
};

