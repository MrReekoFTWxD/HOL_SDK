// WidgetBlueprintGeneratedClass Cursor_BP.Cursor_BP_C
// Size: 0x298 (Inherited: 0x290)
struct UCursor_BP_C : UUserWidget {
	struct UImage* Image_70; // 0x290(0x08)
};

