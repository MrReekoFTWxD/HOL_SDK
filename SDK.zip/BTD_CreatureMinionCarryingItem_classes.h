// BlueprintGeneratedClass BTD_CreatureMinionCarryingItem.BTD_CreatureMinionCarryingItem_C
// Size: 0xa0 (Inherited: 0xa0)
struct UBTD_CreatureMinionCarryingItem_C : UBTDecorator_BlueprintBase {

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_CreatureMinionCarryingItem.BTD_CreatureMinionCarryingItem_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

