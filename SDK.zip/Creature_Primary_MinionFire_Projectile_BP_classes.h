// BlueprintGeneratedClass Creature_Primary_MinionFire_Projectile_BP.Creature_Primary_MinionFire_Projectile_BP_C
// Size: 0x4cc (Inherited: 0x4a0)
struct ACreature_Primary_MinionFire_Projectile_BP_C : ACreature_MinionFire_Projectile_Base_BP_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4a0(0x08)
	struct UParticleSystemComponent* Trail; // 0x4a8(0x08)
	float Lifetime; // 0x4b0(0x04)
	float WarningLifetime; // 0x4b4(0x04)
	struct AActor* ExplosionClass; // 0x4b8(0x08)
	struct FName IsAggessiveBBKey; // 0x4c0(0x08)
	float MaxHomingTime; // 0x4c8(0x04)

	void GetNearestFloor(struct FVector Location, float Distance, struct FVector& FloorLocation); // Function Creature_Primary_MinionFire_Projectile_BP.Creature_Primary_MinionFire_Projectile_BP_C.GetNearestFloor // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void OnWarningStart(); // Function Creature_Primary_MinionFire_Projectile_BP.Creature_Primary_MinionFire_Projectile_BP_C.OnWarningStart // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Explode(); // Function Creature_Primary_MinionFire_Projectile_BP.Creature_Primary_MinionFire_Projectile_BP_C.Explode // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnTimerComplete(); // Function Creature_Primary_MinionFire_Projectile_BP.Creature_Primary_MinionFire_Projectile_BP_C.OnTimerComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnSpawnedFromPool(); // Function Creature_Primary_MinionFire_Projectile_BP.Creature_Primary_MinionFire_Projectile_BP_C.OnSpawnedFromPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnReturnedToPool(); // Function Creature_Primary_MinionFire_Projectile_BP.Creature_Primary_MinionFire_Projectile_BP_C.OnReturnedToPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnImpact(struct FHitResult& ImpactResult); // Function Creature_Primary_MinionFire_Projectile_BP.Creature_Primary_MinionFire_Projectile_BP_C.OnImpact // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_Primary_MinionFire_Projectile_BP(int32_t EntryPoint); // Function Creature_Primary_MinionFire_Projectile_BP.Creature_Primary_MinionFire_Projectile_BP_C.ExecuteUbergraph_Creature_Primary_MinionFire_Projectile_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

