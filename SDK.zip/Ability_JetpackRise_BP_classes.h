// BlueprintGeneratedClass Ability_JetpackRise_BP.Ability_JetpackRise_BP_C
// Size: 0x408 (Inherited: 0x408)
struct UAbility_JetpackRise_BP_C : UORGameplayAbility_JetpackRise {
};

