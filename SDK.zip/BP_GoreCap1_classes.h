// BlueprintGeneratedClass BP_GoreCap1.BP_GoreCap1_C
// Size: 0x230 (Inherited: 0x220)
struct ABP_GoreCap1_C : AActor {
	struct UStaticMeshComponent* StaticMesh; // 0x220(0x08)
	struct USceneComponent* Scene; // 0x228(0x08)
};

