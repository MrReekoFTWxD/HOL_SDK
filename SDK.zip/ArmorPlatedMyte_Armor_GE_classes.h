// BlueprintGeneratedClass ArmorPlatedMyte_Armor_GE.ArmorPlatedMyte_Armor_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UArmorPlatedMyte_Armor_GE_C : UORGameplayEffect {
};

