// BlueprintGeneratedClass CreatureMinion_MeleeAttack_GA.CreatureMinion_MeleeAttack_GA_C
// Size: 0x4a8 (Inherited: 0x4a8)
struct UCreatureMinion_MeleeAttack_GA_C : UOREnemy_Melee_GA_C {

	void K2_ProcessMeleeAttackHit(struct AActor* Instigator, struct FHitResult& HitResult); // Function CreatureMinion_MeleeAttack_GA.CreatureMinion_MeleeAttack_GA_C.K2_ProcessMeleeAttackHit // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

