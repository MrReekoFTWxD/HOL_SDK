// BlueprintGeneratedClass BTT_FindAverageSquadLocation.BTT_FindAverageSquadLocation_C
// Size: 0xdc (Inherited: 0xa8)
struct UBTT_FindAverageSquadLocation_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct FBlackboardKeySelector AverageSquadLocationBBKey; // 0xb0(0x28)
	float HeightOffset; // 0xd8(0x04)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_FindAverageSquadLocation.BTT_FindAverageSquadLocation_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTT_FindAverageSquadLocation(int32_t EntryPoint); // Function BTT_FindAverageSquadLocation.BTT_FindAverageSquadLocation_C.ExecuteUbergraph_BTT_FindAverageSquadLocation // (Final|UbergraphFunction) // @ game+0x1953910
};

