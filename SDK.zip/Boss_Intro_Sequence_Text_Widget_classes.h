// WidgetBlueprintGeneratedClass Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C
// Size: 0x3b0 (Inherited: 0x290)
struct UBoss_Intro_Sequence_Text_Widget_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UWidgetAnimation* ToIdle; // 0x298(0x08)
	struct UWidgetAnimation* ToOff; // 0x2a0(0x08)
	struct UWidgetAnimation* ToOn; // 0x2a8(0x08)
	struct UImage* Image_287; // 0x2b0(0x08)
	struct URetainerBox* RetainerBox_1; // 0x2b8(0x08)
	struct UTextBlock* TextBlock; // 0x2c0(0x08)
	struct UTextBlock* TextBlock_2; // 0x2c8(0x08)
	struct UTextBlock* TextBlock_3; // 0x2d0(0x08)
	struct UTextBlock* TextBlock_28; // 0x2d8(0x08)
	struct UOverlay* TextJustify_2; // 0x2e0(0x08)
	struct UScaleBox* TextJustify_3; // 0x2e8(0x08)
	struct UScaleBox* TextJustify_4; // 0x2f0(0x08)
	struct UScaleBox* TextJustify_5; // 0x2f8(0x08)
	struct UImage* Underline; // 0x300(0x08)
	struct TMap<struct FName, float> NormalShaderParams; // 0x308(0x50)
	struct TMap<struct FName, float> DistortionShaderParams; // 0x358(0x50)
	struct UDataTable* CharacterInfoDataTable; // 0x3a8(0x08)

	void SequenceEvent__ENTRYPOINTBoss_Intro_Sequence_Text_Widget_1(); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.SequenceEvent__ENTRYPOINTBoss_Intro_Sequence_Text_Widget_1 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Finished_436BDBBA44E3C3A1A2E02E9BA2ED7C3B(); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.Finished_436BDBBA44E3C3A1A2E02E9BA2ED7C3B // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Finished_AAD7CFF646779387A2FB9B80A5417972(); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.Finished_AAD7CFF646779387A2FB9B80A5417972 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StartDistortion(); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.StartDistortion // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetBossInfo(struct FText BossName); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.SetBossInfo // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StopDistortion(); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.StopDistortion // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void HideCharacterIntroText(); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.HideCharacterIntroText // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ShowCharacterIntroText(struct FName CharacterRowName); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.ShowCharacterIntroText // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Boss_Intro_Sequence_Text_Widget(int32_t EntryPoint); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.ExecuteUbergraph_Boss_Intro_Sequence_Text_Widget // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

