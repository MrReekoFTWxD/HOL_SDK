// BlueprintGeneratedClass Creature_MindControl_GE.Creature_MindControl_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreature_MindControl_GE_C : UPersistent_MindControl_GE_C {
};

