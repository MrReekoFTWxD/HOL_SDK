// UserDefinedStruct DataTableRowHandleArray.DataTableRowHandleArray
// Size: 0x10 (Inherited: 0x00)
struct FDataTableRowHandleArray {
	struct TArray<struct FDataTableRowHandle> DataTableRowHandles_3_9B191DD64B7BF37AEB6905869548D73B; // 0x00(0x10)
};

