// BlueprintGeneratedClass Charge_SC.Charge_SC_C
// Size: 0x50 (Inherited: 0x48)
struct UCharge_SC_C : UORScriptComponent_Charge {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x48(0x08)

	bool GetIsActive(); // Function Charge_SC.Charge_SC_C.GetIsActive // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetIsActive(bool IsActive); // Function Charge_SC.Charge_SC_C.SetIsActive // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Charge_SC(int32_t EntryPoint); // Function Charge_SC.Charge_SC_C.ExecuteUbergraph_Charge_SC // (Final|UbergraphFunction) // @ game+0x1953910
};

