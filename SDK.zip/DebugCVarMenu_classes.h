// WidgetBlueprintGeneratedClass DebugCVarMenu.DebugCVarMenu_C
// Size: 0x438 (Inherited: 0x3b1)
struct UDebugCVarMenu_C : UDebugMenu_C {
	char pad_3B1[0x7]; // 0x3b1(0x07)
	struct UGridPanel* Grid; // 0x3b8(0x08)
	struct UDebugMenuMissionLabel_C* RenderingLabel; // 0x3c0(0x08)
	struct UDebugMenuMissionLabel_C* SyncIntervalLabel; // 0x3c8(0x08)
	struct UDebugMenu_IntCVarToggle_C* SyncIntervalToggle; // 0x3d0(0x08)
	struct UDebugMenuMissionLabel_C* VSyncLabel; // 0x3d8(0x08)
	struct UDebugMenu_IntCVarToggle_C* VSyncToggle; // 0x3e0(0x08)
	struct TMap<struct FString, struct FDebugCVarInfo> CVars; // 0x3e8(0x50)

	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugCVarMenu.DebugCVarMenu_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetVSync(); // Function DebugCVarMenu.DebugCVarMenu_C.SetVSync // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetSyncInterval(); // Function DebugCVarMenu.DebugCVarMenu_C.SetSyncInterval // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UpdateSyncInterval(); // Function DebugCVarMenu.DebugCVarMenu_C.UpdateSyncInterval // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InitCVars(); // Function DebugCVarMenu.DebugCVarMenu_C.InitCVars // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Initialize(); // Function DebugCVarMenu.DebugCVarMenu_C.Initialize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

