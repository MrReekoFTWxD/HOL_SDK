// BlueprintGeneratedClass Ability_ConversationChoice_Cancel.Ability_ConversationChoice_Cancel_C
// Size: 0x400 (Inherited: 0x400)
struct UAbility_ConversationChoice_Cancel_C : UORGameplayAbility_ConversationChoice {
};

