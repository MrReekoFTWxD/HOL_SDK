// BlueprintGeneratedClass CanUseAbility_PrimaryFire.CanUseAbility_PrimaryFire_C
// Size: 0xc8 (Inherited: 0xc8)
struct UCanUseAbility_PrimaryFire_C : UUtilityConsideration {
};

