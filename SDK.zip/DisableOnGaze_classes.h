// BlueprintGeneratedClass DisableOnGaze.DisableOnGaze_C
// Size: 0x418 (Inherited: 0x418)
struct UDisableOnGaze_C : UDisablePlayerFireableItemOnGazeReceived_GA_C {
};

