// BlueprintGeneratedClass BTS_SetAllowStationaryRotation.BTS_SetAllowStationaryRotation_C
// Size: 0xa2 (Inherited: 0x98)
struct UBTS_SetAllowStationaryRotation_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	bool AllowStationaryRotation; // 0xa0(0x01)
	bool InitialAllowStationaryRotation; // 0xa1(0x01)

	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_SetAllowStationaryRotation.BTS_SetAllowStationaryRotation_C.ReceiveDeactivationAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_SetAllowStationaryRotation.BTS_SetAllowStationaryRotation_C.ReceiveActivationAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTS_SetAllowStationaryRotation(int32_t EntryPoint); // Function BTS_SetAllowStationaryRotation.BTS_SetAllowStationaryRotation_C.ExecuteUbergraph_BTS_SetAllowStationaryRotation // (Final|UbergraphFunction) // @ game+0x1953910
};

