// BlueprintGeneratedClass Creature_MindControl_ResourceComponent_BP.Creature_MindControl_ResourceComponent_BP_C
// Size: 0x178 (Inherited: 0x178)
struct UCreature_MindControl_ResourceComponent_BP_C : USupport_ResourceComponent_BP_C {
};

