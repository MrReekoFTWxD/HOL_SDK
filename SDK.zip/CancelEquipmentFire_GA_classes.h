// BlueprintGeneratedClass CancelEquipmentFire_GA.CancelEquipmentFire_GA_C
// Size: 0x448 (Inherited: 0x3f8)
struct UCancelEquipmentFire_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct FGameplayAbilityActorInfo Actor Info; // 0x400(0x48)

	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayAbilitySpecHandle Handle, struct FGameplayTagContainer& RelevantTags); // Function CancelEquipmentFire_GA.CancelEquipmentFire_GA_C.K2_CanActivateAbility // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1953910
	void K2_ActivateAbility(); // Function CancelEquipmentFire_GA.CancelEquipmentFire_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_CancelEquipmentFire_GA(int32_t EntryPoint); // Function CancelEquipmentFire_GA.CancelEquipmentFire_GA_C.ExecuteUbergraph_CancelEquipmentFire_GA // (Final|UbergraphFunction) // @ game+0x1953910
};

