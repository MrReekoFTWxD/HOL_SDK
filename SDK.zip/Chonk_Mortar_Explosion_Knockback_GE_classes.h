// BlueprintGeneratedClass Chonk_Mortar_Explosion_Knockback_GE.Chonk_Mortar_Explosion_Knockback_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UChonk_Mortar_Explosion_Knockback_GE_C : UORGameplayEffect {
};

