// BlueprintGeneratedClass Ability_ConversationChoice_3.Ability_ConversationChoice_2_C
// Size: 0x400 (Inherited: 0x400)
struct UAbility_ConversationChoice_2_C : UORGameplayAbility_ConversationChoice {
};

