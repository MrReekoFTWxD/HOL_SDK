// BlueprintGeneratedClass Creature_MinionFire_Projectile_Base_BP.Creature_MinionFire_Projectile_Base_BP_C
// Size: 0x4a0 (Inherited: 0x400)
struct ACreature_MinionFire_Projectile_Base_BP_C : AORProjectile_PlayerProjectile_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x400(0x08)
	struct UORTriggerSourceComponent* ORTriggerSource; // 0x408(0x08)
	struct USkeletalMeshComponent* SkeletalMesh; // 0x410(0x08)
	struct TMap<struct FGameplayTag, struct ACreatureMinion_Base_BP_C*> CreatureMinionClassToSpawn; // 0x418(0x50)
	struct ACreatureMinion_Base_BP_C* DefaultCreatureMinionClassToSpawn; // 0x468(0x08)
	struct AActor* TaskTarget; // 0x470(0x08)
	struct AORCreatureWeaponItem* CreatureWeaponItem; // 0x478(0x08)
	bool CanSpawnCreatureMinion; // 0x480(0x01)
	bool CreatureMinionSpawned; // 0x481(0x01)
	char pad_482[0x2]; // 0x482(0x02)
	struct FGameplayTag LatchImmunityTag; // 0x484(0x08)
	struct FGameplayTag CreatureModTag; // 0x48c(0x08)
	char pad_494[0x4]; // 0x494(0x04)
	struct UMaterialInstance* CreatureModMaterial; // 0x498(0x08)

	void GetCreatureMinionClassToSpawn(struct ACreatureMinion_Base_BP_C*& CreatureMinionClass); // Function Creature_MinionFire_Projectile_Base_BP.Creature_MinionFire_Projectile_Base_BP_C.GetCreatureMinionClassToSpawn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void SetCreatureWeaponItem(struct AORCreatureWeaponItem* CreatureWeaponItem); // Function Creature_MinionFire_Projectile_Base_BP.Creature_MinionFire_Projectile_Base_BP_C.SetCreatureWeaponItem // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InitCreatureMinion(struct ACreatureMinion_Base_BP_C* CreatureMinion); // Function Creature_MinionFire_Projectile_Base_BP.Creature_MinionFire_Projectile_Base_BP_C.InitCreatureMinion // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void TrySpawnCreatureMinion(struct ACreatureMinion_Base_BP_C*& CreatureMinion); // Function Creature_MinionFire_Projectile_Base_BP.Creature_MinionFire_Projectile_Base_BP_C.TrySpawnCreatureMinion // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	bool AllowBounce(struct AActor* OtherActor); // Function Creature_MinionFire_Projectile_Base_BP.Creature_MinionFire_Projectile_Base_BP_C.AllowBounce // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	bool AllowImpactWithActor(struct AActor* OtherActor); // Function Creature_MinionFire_Projectile_Base_BP.Creature_MinionFire_Projectile_Base_BP_C.AllowImpactWithActor // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnImpact(struct FHitResult& ImpactResult); // Function Creature_MinionFire_Projectile_Base_BP.Creature_MinionFire_Projectile_Base_BP_C.OnImpact // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveTick(float DeltaSeconds); // Function Creature_MinionFire_Projectile_Base_BP.Creature_MinionFire_Projectile_Base_BP_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnReturnedToPool(); // Function Creature_MinionFire_Projectile_Base_BP.Creature_MinionFire_Projectile_Base_BP_C.OnReturnedToPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnSpawnedFromPool(); // Function Creature_MinionFire_Projectile_Base_BP.Creature_MinionFire_Projectile_Base_BP_C.OnSpawnedFromPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_MinionFire_Projectile_Base_BP(int32_t EntryPoint); // Function Creature_MinionFire_Projectile_Base_BP.Creature_MinionFire_Projectile_Base_BP_C.ExecuteUbergraph_Creature_MinionFire_Projectile_Base_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

