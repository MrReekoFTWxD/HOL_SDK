// BlueprintGeneratedClass Damage_Blocking_GE.Damage_Blocking_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UDamage_Blocking_GE_C : UORGameplayEffect {
};

