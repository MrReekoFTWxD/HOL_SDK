// BlueprintGeneratedClass Ability_ChangeEquippedWeapon.Ability_ChangeEquippedWeapon_C
// Size: 0x3f5 (Inherited: 0x3e0)
struct UAbility_ChangeEquippedWeapon_C : UAbility_ChangeEquippedItemBase_BP_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3e0(0x08)
	struct FGameplayTag ItemTag; // 0x3e8(0x08)
	float EquipmentSwapDelay; // 0x3f0(0x04)
	bool bHasSwappedEquipment; // 0x3f4(0x01)

	void GetOwningCharacter(struct AORCharacter*& Character); // Function Ability_ChangeEquippedWeapon.Ability_ChangeEquippedWeapon_C.GetOwningCharacter // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function Ability_ChangeEquippedWeapon.Ability_ChangeEquippedWeapon_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function Ability_ChangeEquippedWeapon.Ability_ChangeEquippedWeapon_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void SwapEquipment(); // Function Ability_ChangeEquippedWeapon.Ability_ChangeEquippedWeapon_C.SwapEquipment // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Ability_ChangeEquippedWeapon(int32_t EntryPoint); // Function Ability_ChangeEquippedWeapon.Ability_ChangeEquippedWeapon_C.ExecuteUbergraph_Ability_ChangeEquippedWeapon // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

