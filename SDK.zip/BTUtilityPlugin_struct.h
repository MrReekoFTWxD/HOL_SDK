// Enum BTUtilityPlugin.EUtilitySelectionMethod
enum class EUtilitySelectionMethod : uint8 {
	Priority = 0,
	Proportional = 1,
	EUtilitySelectionMethod_MAX = 2
};

