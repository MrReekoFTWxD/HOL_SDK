// BlueprintGeneratedClass BTS_FindCreatureMinionAttackTarget.BTS_FindCreatureMinionAttackTarget_C
// Size: 0x100 (Inherited: 0x98)
struct UBTS_FindCreatureMinionAttackTarget_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	struct FBlackboardKeySelector ActorTarget_Key; // 0xa0(0x28)
	struct FBlackboardKeySelector CombatBehaviorSubState_Key; // 0xc8(0x28)
	float SearchRadius; // 0xf0(0x04)
	bool IsQueryRunning; // 0xf4(0x01)
	char pad_F5[0x3]; // 0xf5(0x03)
	struct AORAICreatureMinionController* CreatureMinionController_Chached; // 0xf8(0x08)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_FindCreatureMinionAttackTarget.BTS_FindCreatureMinionAttackTarget_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void QueryFinished(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus); // Function BTS_FindCreatureMinionAttackTarget.BTS_FindCreatureMinionAttackTarget_C.QueryFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTS_FindCreatureMinionAttackTarget(int32_t EntryPoint); // Function BTS_FindCreatureMinionAttackTarget.BTS_FindCreatureMinionAttackTarget_C.ExecuteUbergraph_BTS_FindCreatureMinionAttackTarget // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

