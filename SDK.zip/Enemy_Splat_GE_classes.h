// BlueprintGeneratedClass Enemy_Splat_GE.Enemy_Splat_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UEnemy_Splat_GE_C : UORGameplayEffect {
};

