// UserDefinedStruct AbilityHUDData.AbilityHUDData
// Size: 0x20 (Inherited: 0x00)
struct FAbilityHUDData {
	struct FGameplayTag Tag_2_FEBF3CF14D94F035E52D1FB2E1473086; // 0x00(0x08)
	struct UTexture2D* Icon_5_9F751FFC41E61FE1B0BB67A34D105612; // 0x08(0x08)
	struct FName Name_8_981EEF2143A9DBC2F5579F9F67135A9D; // 0x10(0x08)
	struct FName Description_11_D95AC7E54DB68E896B77D5A2992D8FA7; // 0x18(0x08)
};

