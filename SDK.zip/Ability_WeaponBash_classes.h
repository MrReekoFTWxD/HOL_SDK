// BlueprintGeneratedClass Ability_WeaponBash.Ability_WeaponBash_C
// Size: 0x470 (Inherited: 0x468)
struct UAbility_WeaponBash_C : UORGameplayAbility_PlayerMelee {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x468(0x08)

	void BP_OnPlayerMeleeEvent(struct FGameplayTag CurrentMeleeType); // Function Ability_WeaponBash.Ability_WeaponBash_C.BP_OnPlayerMeleeEvent // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Ability_WeaponBash(int32_t EntryPoint); // Function Ability_WeaponBash.Ability_WeaponBash_C.ExecuteUbergraph_Ability_WeaponBash // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

