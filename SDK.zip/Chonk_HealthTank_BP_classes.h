// BlueprintGeneratedClass Chonk_HealthTank_BP.Chonk_HealthTank_BP_C
// Size: 0x338 (Inherited: 0x330)
struct AChonk_HealthTank_BP_C : AORHealthTankItem {
	struct USceneComponent* DefaultSceneRoot; // 0x330(0x08)
};

