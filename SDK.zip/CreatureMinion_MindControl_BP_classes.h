// BlueprintGeneratedClass CreatureMinion_MindControl_BP.CreatureMinion_MindControl_BP_C
// Size: 0x2288 (Inherited: 0x227c)
struct ACreatureMinion_MindControl_BP_C : ACreatureMinion_Base_BP_C {
	char pad_227C[0x4]; // 0x227c(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2280(0x08)

	void CanTriggerPoppinMinionsMod(bool& Equipped); // Function CreatureMinion_MindControl_BP.CreatureMinion_MindControl_BP_C.CanTriggerPoppinMinionsMod // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void LatchToCharacter(struct AORCharacter* Character); // Function CreatureMinion_MindControl_BP.CreatureMinion_MindControl_BP_C.LatchToCharacter // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function CreatureMinion_MindControl_BP.CreatureMinion_MindControl_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void EndMindControl(struct UORGlobalEventPayload* EventData); // Function CreatureMinion_MindControl_BP.CreatureMinion_MindControl_BP_C.EndMindControl // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCreatureWeaponItemChanged(struct AORCreatureWeaponItem* NewCreatureWeaponItem); // Function CreatureMinion_MindControl_BP.CreatureMinion_MindControl_BP_C.OnCreatureWeaponItemChanged // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_CreatureMinion_MindControl_BP(int32_t EntryPoint); // Function CreatureMinion_MindControl_BP.CreatureMinion_MindControl_BP_C.ExecuteUbergraph_CreatureMinion_MindControl_BP // (Final|UbergraphFunction) // @ game+0x1953910
};

