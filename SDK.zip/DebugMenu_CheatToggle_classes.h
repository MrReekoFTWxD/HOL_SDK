// WidgetBlueprintGeneratedClass DebugMenu_CheatToggle.DebugMenu_CheatToggle_C
// Size: 0x2c8 (Inherited: 0x290)
struct UDebugMenu_CheatToggle_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UORWidget_Button_BP_C* ORWidget_Button_BP; // 0x298(0x08)
	struct FText InvItemValue; // 0x2a0(0x18)
	struct FString CheatCommand; // 0x2b8(0x10)

	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugMenu_CheatToggle.DebugMenu_CheatToggle_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetValueLabel(bool CheatActive); // Function DebugMenu_CheatToggle.DebugMenu_CheatToggle_C.SetValueLabel // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void FlipState(); // Function DebugMenu_CheatToggle.DebugMenu_CheatToggle_C.FlipState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetInitialCheat(struct FString InCheatCommand); // Function DebugMenu_CheatToggle.DebugMenu_CheatToggle_C.SetInitialCheat // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function DebugMenu_CheatToggle.DebugMenu_CheatToggle_C.BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugMenu_CheatToggle(int32_t EntryPoint); // Function DebugMenu_CheatToggle.DebugMenu_CheatToggle_C.ExecuteUbergraph_DebugMenu_CheatToggle // (Final|UbergraphFunction) // @ game+0x1953910
};

