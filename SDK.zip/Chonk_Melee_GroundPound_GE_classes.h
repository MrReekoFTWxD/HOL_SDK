// BlueprintGeneratedClass Chonk_Melee_GroundPound_GE.Chonk_Melee_GroundPound_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UChonk_Melee_GroundPound_GE_C : UORGameplayEffect {
};

