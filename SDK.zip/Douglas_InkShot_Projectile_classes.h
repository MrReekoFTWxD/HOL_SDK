// BlueprintGeneratedClass Douglas_InkShot_Projectile.Douglas_InkShot_Projectile_C
// Size: 0x3f8 (Inherited: 0x3d0)
struct ADouglas_InkShot_Projectile_C : AORProjectile {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d0(0x08)
	struct UNiagaraComponent* Niagara; // 0x3d8(0x08)
	struct UORAkComponent* ORAk; // 0x3e0(0x08)
	struct USceneComponent* Scene; // 0x3e8(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x3f0(0x08)

	void OnImpact(struct FHitResult& ImpactResult); // Function Douglas_InkShot_Projectile.Douglas_InkShot_Projectile_C.OnImpact // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnSpawnedFromPool(); // Function Douglas_InkShot_Projectile.Douglas_InkShot_Projectile_C.OnSpawnedFromPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnReturnedToPool(); // Function Douglas_InkShot_Projectile.Douglas_InkShot_Projectile_C.OnReturnedToPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Douglas_InkShot_Projectile(int32_t EntryPoint); // Function Douglas_InkShot_Projectile.Douglas_InkShot_Projectile_C.ExecuteUbergraph_Douglas_InkShot_Projectile // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

