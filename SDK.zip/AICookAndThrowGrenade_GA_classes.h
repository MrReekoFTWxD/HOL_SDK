// BlueprintGeneratedClass AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C
// Size: 0x4d1 (Inherited: 0x428)
struct UAICookAndThrowGrenade_GA_C : UORGameplayAbility_FireItem {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x428(0x08)
	struct UAnimMontage* GrenadeThrowMontage; // 0x430(0x08)
	bool UsesChargeLoop; // 0x438(0x01)
	char pad_439[0x7]; // 0x439(0x07)
	struct UAnimMontage* GrenadeDropMontage; // 0x440(0x08)
	struct UORWidget_HUDPrompt* WarningWidget; // 0x448(0x08)
	struct UAkAudioEvent* GrenadeChargeAkEvent; // 0x450(0x08)
	bool HandleGrenadeUsedGE; // 0x458(0x01)
	bool EndAbilityOnMontageCompletion; // 0x459(0x01)
	char pad_45A[0x2]; // 0x45a(0x02)
	float ChargeTime; // 0x45c(0x04)
	bool CanBeInterrupted; // 0x460(0x01)
	char pad_461[0x3]; // 0x461(0x03)
	float ThrowTime; // 0x464(0x04)
	struct AActor* TargetActor; // 0x468(0x08)
	struct FVector LaunchLocation; // 0x470(0x0c)
	struct FVector AimLocation; // 0x47c(0x0c)
	struct FVector EstimatedLaunchVelocity; // 0x488(0x0c)
	char pad_494[0x4]; // 0x494(0x04)
	struct TArray<float> ArcSpeedModifiers; // 0x498(0x10)
	float DefaultLaunchSpeed; // 0x4a8(0x04)
	float TargetDistanceMultiplier; // 0x4ac(0x04)
	float OffsetMultiplier; // 0x4b0(0x04)
	bool FavorHighArc; // 0x4b4(0x01)
	char pad_4B5[0x3]; // 0x4b5(0x03)
	int32_t ChargeAkID; // 0x4b8(0x04)
	bool BeginFireTriggered; // 0x4bc(0x01)
	char pad_4BD[0x3]; // 0x4bd(0x03)
	struct UAnimMontage* GrenadeChargeMontage; // 0x4c0(0x08)
	struct USkeletalMeshComponent* OwnerMesh; // 0x4c8(0x08)
	bool ShowWarningWidgetWhileCharging; // 0x4d0(0x01)

	void SetWarningWidget(bool Enabled); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.SetWarningWidget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetChargeAudioEnabled(bool Enabled); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.SetChargeAudioEnabled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnDamageTaken(struct UObject* Damager, struct AORCharacter* Damaged, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnDamageTaken // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetDamageEventBindEnabled(bool Enabled); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.SetDamageEventBindEnabled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetRandomOffset(int32_t Min, int32_t Max, float& RandomValue); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.GetRandomOffset // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1953910
	void FindLaunchVelocity(struct FVector& LaunchVelocity); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.FindLaunchVelocity // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InitializeLaunchVariables(struct AORCharacter* OwningORCharacter); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.InitializeLaunchVariables // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayAbilitySpecHandle Handle, struct FGameplayTagContainer& RelevantTags); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.K2_CanActivateAbility // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1953910
	void OnCancelled_BFF2371B49794F08C6D08BABD06E91C9(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnCancelled_BFF2371B49794F08C6D08BABD06E91C9 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnInterrupted_BFF2371B49794F08C6D08BABD06E91C9(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnInterrupted_BFF2371B49794F08C6D08BABD06E91C9 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnBlendOut_BFF2371B49794F08C6D08BABD06E91C9(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnBlendOut_BFF2371B49794F08C6D08BABD06E91C9 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_BFF2371B49794F08C6D08BABD06E91C9(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnCompleted_BFF2371B49794F08C6D08BABD06E91C9 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnNotifyEnd_CB052D0449732D9E04B5E68488268F05(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnNotifyEnd_CB052D0449732D9E04B5E68488268F05 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnNotifyBegin_CB052D0449732D9E04B5E68488268F05(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnNotifyBegin_CB052D0449732D9E04B5E68488268F05 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnInterrupted_CB052D0449732D9E04B5E68488268F05(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnInterrupted_CB052D0449732D9E04B5E68488268F05 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnBlendOut_CB052D0449732D9E04B5E68488268F05(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnBlendOut_CB052D0449732D9E04B5E68488268F05 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_CB052D0449732D9E04B5E68488268F05(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnCompleted_CB052D0449732D9E04B5E68488268F05 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnNotifyEnd_6B8CF146489C2A5CF4B68380953B270E(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnNotifyEnd_6B8CF146489C2A5CF4B68380953B270E // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnNotifyBegin_6B8CF146489C2A5CF4B68380953B270E(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnNotifyBegin_6B8CF146489C2A5CF4B68380953B270E // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnInterrupted_6B8CF146489C2A5CF4B68380953B270E(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnInterrupted_6B8CF146489C2A5CF4B68380953B270E // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnBlendOut_6B8CF146489C2A5CF4B68380953B270E(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnBlendOut_6B8CF146489C2A5CF4B68380953B270E // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_6B8CF146489C2A5CF4B68380953B270E(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnCompleted_6B8CF146489C2A5CF4B68380953B270E // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void HandleProjectileVelocityOverride(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.HandleProjectileVelocityOverride // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ThrowGrenade(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.ThrowGrenade // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void DropGrenade(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.DropGrenade // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void K2_CommitExecute(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ThrowMontageNotifyBegin(struct FName Notify Begin); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.ThrowMontageNotifyBegin // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ChargeMontageNotifyBegin(struct FName Notify Begin); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.ChargeMontageNotifyBegin // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_AICookAndThrowGrenade_GA(int32_t EntryPoint); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.ExecuteUbergraph_AICookAndThrowGrenade_GA // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

