// BlueprintGeneratedClass CanAimFromCover.CanAimFromCover_C
// Size: 0xc8 (Inherited: 0xc8)
struct UCanAimFromCover_C : UUtilityConsideration {
};

