// WidgetBlueprintGeneratedClass DebugMenu_SaveProfileButton.DebugMenu_SaveProfileButton_C
// Size: 0x2b0 (Inherited: 0x290)
struct UDebugMenu_SaveProfileButton_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UORWidget_Button_BP_C* ORWidget_Button_BP; // 0x298(0x08)
	struct FString ProfileName; // 0x2a0(0x10)

	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugMenu_SaveProfileButton.DebugMenu_SaveProfileButton_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetupProfileButton(struct FString InProfileName); // Function DebugMenu_SaveProfileButton.DebugMenu_SaveProfileButton_C.SetupProfileButton // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function DebugMenu_SaveProfileButton.DebugMenu_SaveProfileButton_C.BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugMenu_SaveProfileButton(int32_t EntryPoint); // Function DebugMenu_SaveProfileButton.DebugMenu_SaveProfileButton_C.ExecuteUbergraph_DebugMenu_SaveProfileButton // (Final|UbergraphFunction) // @ game+0x1953910
};

