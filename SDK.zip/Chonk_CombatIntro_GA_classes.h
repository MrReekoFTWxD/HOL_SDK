// BlueprintGeneratedClass Chonk_CombatIntro_GA.Chonk_CombatIntro_GA_C
// Size: 0x418 (Inherited: 0x410)
struct UChonk_CombatIntro_GA_C : UCombatIntro_GA_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x410(0x08)

	void K2_ActivateAbility(); // Function Chonk_CombatIntro_GA.Chonk_CombatIntro_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Chonk_CombatIntro_GA(int32_t EntryPoint); // Function Chonk_CombatIntro_GA.Chonk_CombatIntro_GA_C.ExecuteUbergraph_Chonk_CombatIntro_GA // (Final|UbergraphFunction) // @ game+0x1953910
};

