// BlueprintGeneratedClass BlockSupportFire_GE.BlockSupportFire_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UBlockSupportFire_GE_C : UORGameplayEffect {
};

