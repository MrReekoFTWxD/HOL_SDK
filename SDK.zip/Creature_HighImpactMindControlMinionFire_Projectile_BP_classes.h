// BlueprintGeneratedClass Creature_HighImpactMindControlMinionFire_Projectile_BP.Creature_HighImpactMindControlMinionFire_Projectile_BP_C
// Size: 0x4b8 (Inherited: 0x4b8)
struct ACreature_HighImpactMindControlMinionFire_Projectile_BP_C : ACreature_HighImpactMinionFire_Projectile_BP_C {

	void InitCreatureMinion(struct ACreatureMinion_Base_BP_C* CreatureMinion); // Function Creature_HighImpactMindControlMinionFire_Projectile_BP.Creature_HighImpactMindControlMinionFire_Projectile_BP_C.InitCreatureMinion // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

