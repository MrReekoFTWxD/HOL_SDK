// BlueprintGeneratedClass Bounce_GC.Bounce_GC_C
// Size: 0x41 (Inherited: 0x40)
struct UBounce_GC_C : UGameplayCueNotify_Static {
	bool DoesPlayVO; // 0x40(0x01)

	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function Bounce_GC.Bounce_GC_C.OnActive // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1953910
};

