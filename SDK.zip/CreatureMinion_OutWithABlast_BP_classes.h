// BlueprintGeneratedClass CreatureMinion_OutWithABlast_BP.CreatureMinion_OutWithABlast_BP_C
// Size: 0x227c (Inherited: 0x227c)
struct ACreatureMinion_OutWithABlast_BP_C : ACreatureMinionLv1_BP_C {
};

