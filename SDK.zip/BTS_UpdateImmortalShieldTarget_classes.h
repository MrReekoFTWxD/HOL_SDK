// BlueprintGeneratedClass BTS_UpdateImmortalShieldTarget.BTS_UpdateImmortalShieldTarget_C
// Size: 0xa8 (Inherited: 0x98)
struct UBTS_UpdateImmortalShieldTarget_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	struct ABP_Immortal_C* Immortal_Cached; // 0xa0(0x08)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_UpdateImmortalShieldTarget.BTS_UpdateImmortalShieldTarget_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ReceiveSearchStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_UpdateImmortalShieldTarget.BTS_UpdateImmortalShieldTarget_C.ReceiveSearchStartAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTS_UpdateImmortalShieldTarget(int32_t EntryPoint); // Function BTS_UpdateImmortalShieldTarget.BTS_UpdateImmortalShieldTarget_C.ExecuteUbergraph_BTS_UpdateImmortalShieldTarget // (Final|UbergraphFunction) // @ game+0x1953910
};

