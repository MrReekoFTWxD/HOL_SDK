// BlueprintGeneratedClass Ability_Jump.Ability_Jump_C
// Size: 0x3f8 (Inherited: 0x3f8)
struct UAbility_Jump_C : UORGameplayAbility_Jump {
};

