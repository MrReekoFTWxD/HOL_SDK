// BlueprintGeneratedClass Chonk_EnemyMortar_PrimaryExplosion.Chonk_EnemyMortar_PrimaryExplosion_C
// Size: 0x458 (Inherited: 0x438)
struct AChonk_EnemyMortar_PrimaryExplosion_C : AORExplosionActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x438(0x08)
	struct UCameraShakeSourceComponent* CameraShakeSource; // 0x440(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x448(0x08)
	struct AActor* LingeringExplosion; // 0x450(0x08)

	void ReceiveBeginPlay(); // Function Chonk_EnemyMortar_PrimaryExplosion.Chonk_EnemyMortar_PrimaryExplosion_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Chonk_EnemyMortar_PrimaryExplosion(int32_t EntryPoint); // Function Chonk_EnemyMortar_PrimaryExplosion.Chonk_EnemyMortar_PrimaryExplosion_C.ExecuteUbergraph_Chonk_EnemyMortar_PrimaryExplosion // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

