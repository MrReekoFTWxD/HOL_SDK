// BlueprintGeneratedClass Electricity_GC.Electricity_GC_C
// Size: 0x290 (Inherited: 0x280)
struct AElectricity_GC_C : AGameplayCueNotify_Actor {
	struct UParticleSystemComponent* ParticleSystem; // 0x280(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x288(0x08)
};

