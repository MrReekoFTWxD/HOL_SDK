// BlueprintGeneratedClass 004_Jorb_GroupIdleThree_v1.SequenceDirector_C
// Size: 0x40 (Inherited: 0x38)
struct USequenceDirector_C : ULevelSequenceDirector {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x38(0x08)

	void Jorb_BP_Event_1(struct AJorb_BP_C* Jorb_BP, struct UAnimSequence* Anim); // Function 004_Jorb_GroupIdleThree_v1.SequenceDirector_C.Jorb_BP_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_SequenceDirector(int32_t EntryPoint); // Function 004_Jorb_GroupIdleThree_v1.SequenceDirector_C.ExecuteUbergraph_SequenceDirector // (Final|UbergraphFunction) // @ game+0x1953910
};

