// BlueprintGeneratedClass BlockSprint_GE.BlockSprint_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UBlockSprint_GE_C : UORGameplayEffect {
};

