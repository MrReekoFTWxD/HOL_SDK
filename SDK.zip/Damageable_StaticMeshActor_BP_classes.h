// BlueprintGeneratedClass Damageable_StaticMeshActor_BP.Damageable_StaticMeshActor_BP_C
// Size: 0x2e2 (Inherited: 0x288)
struct ADamageable_StaticMeshActor_BP_C : AORBaseDamageable {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x288(0x08)
	struct UORNavModifierComponent* ORNavModifier; // 0x290(0x08)
	struct UORTriggerSourceComponent* ORTriggerSource; // 0x298(0x08)
	struct USimple_DamageHandler_BP_C* DamageHandler; // 0x2a0(0x08)
	float DefaultHealth; // 0x2a8(0x04)
	char pad_2AC[0x4]; // 0x2ac(0x04)
	struct FMulticastInlineDelegate ObjectBroken; // 0x2b0(0x30)
	bool BroadcastBrokenEvent; // 0x2e0(0x01)
	bool IsBroken; // 0x2e1(0x01)

	float ModifyDamage(struct UObject* Damager, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function Damageable_StaticMeshActor_BP.Damageable_StaticMeshActor_BP_C.ModifyDamage // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct UORDamageHandlerComponent* GetDamageHandler(); // Function Damageable_StaticMeshActor_BP.Damageable_StaticMeshActor_BP_C.GetDamageHandler // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UserConstructionScript(); // Function Damageable_StaticMeshActor_BP.Damageable_StaticMeshActor_BP_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function Damageable_StaticMeshActor_BP.Damageable_StaticMeshActor_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void OnDied(struct UObject* Killer, struct FHitResult& HitResult, struct FGameplayTagContainer& DamageTags); // Function Damageable_StaticMeshActor_BP.Damageable_StaticMeshActor_BP_C.OnDied // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Damageable_StaticMeshActor_BP(int32_t EntryPoint); // Function Damageable_StaticMeshActor_BP.Damageable_StaticMeshActor_BP_C.ExecuteUbergraph_Damageable_StaticMeshActor_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
	void ObjectBroken__DelegateSignature(); // Function Damageable_StaticMeshActor_BP.Damageable_StaticMeshActor_BP_C.ObjectBroken__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

