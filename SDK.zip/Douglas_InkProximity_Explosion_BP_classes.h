// BlueprintGeneratedClass Douglas_InkProximity_Explosion_BP.Douglas_InkProximity_Explosion_BP_C
// Size: 0x450 (Inherited: 0x438)
struct ADouglas_InkProximity_Explosion_BP_C : AORExplosionActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x438(0x08)
	struct UORAkComponent* ORAk; // 0x440(0x08)
	struct UNiagaraComponent* Niagara; // 0x448(0x08)

	void ReceiveBeginPlay(); // Function Douglas_InkProximity_Explosion_BP.Douglas_InkProximity_Explosion_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Douglas_InkProximity_Explosion_BP(int32_t EntryPoint); // Function Douglas_InkProximity_Explosion_BP.Douglas_InkProximity_Explosion_BP_C.ExecuteUbergraph_Douglas_InkProximity_Explosion_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

