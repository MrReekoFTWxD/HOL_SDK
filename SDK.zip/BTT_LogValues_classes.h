// BlueprintGeneratedClass BTT_LogValues.BTT_LogValues_C
// Size: 0xe9 (Inherited: 0xa8)
struct UBTT_LogValues_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct FBlackboardKeySelector ValueToPrint; // 0xb0(0x28)
	struct FString Label; // 0xd8(0x10)
	bool PrintToScreen; // 0xe8(0x01)

	void ReceiveExecute(struct AActor* OwnerActor); // Function BTT_LogValues.BTT_LogValues_C.ReceiveExecute // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTT_LogValues(int32_t EntryPoint); // Function BTT_LogValues.BTT_LogValues_C.ExecuteUbergraph_BTT_LogValues // (Final|UbergraphFunction) // @ game+0x1953910
};

