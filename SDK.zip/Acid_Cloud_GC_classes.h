// BlueprintGeneratedClass Acid_Cloud_GC.Acid_Cloud_GC_C
// Size: 0x298 (Inherited: 0x280)
struct AAcid_Cloud_GC_C : AGameplayCueNotify_Actor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x280(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x288(0x08)
	struct UMaterialInstance* CameraMaterial; // 0x290(0x08)

	void K2_HandleGameplayCue(struct AActor* MyTarget, enum class EGameplayCueEvent EventType, struct FGameplayCueParameters& Parameters); // Function Acid_Cloud_GC.Acid_Cloud_GC_C.K2_HandleGameplayCue // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Acid_Cloud_GC(int32_t EntryPoint); // Function Acid_Cloud_GC.Acid_Cloud_GC_C.ExecuteUbergraph_Acid_Cloud_GC // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

