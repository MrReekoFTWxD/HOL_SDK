// WidgetBlueprintGeneratedClass CharacterCreatorFullscreenContainer_BP.CharacterCreatorFullscreenContainer_BP_C
// Size: 0x2d0 (Inherited: 0x290)
struct UCharacterCreatorFullscreenContainer_BP_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UImage* Image_47; // 0x298(0x08)
	struct FMulticastInlineDelegate OnContainerFocused; // 0x2a0(0x30)

	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function CharacterCreatorFullscreenContainer_BP.CharacterCreatorFullscreenContainer_BP_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Construct(); // Function CharacterCreatorFullscreenContainer_BP.CharacterCreatorFullscreenContainer_BP_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_CharacterCreatorFullscreenContainer_BP(int32_t EntryPoint); // Function CharacterCreatorFullscreenContainer_BP.CharacterCreatorFullscreenContainer_BP_C.ExecuteUbergraph_CharacterCreatorFullscreenContainer_BP // (Final|UbergraphFunction) // @ game+0x1953910
	void OnContainerFocused__DelegateSignature(); // Function CharacterCreatorFullscreenContainer_BP.CharacterCreatorFullscreenContainer_BP_C.OnContainerFocused__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

