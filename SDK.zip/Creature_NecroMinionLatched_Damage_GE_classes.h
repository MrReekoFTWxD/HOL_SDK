// BlueprintGeneratedClass Creature_NecroMinionLatched_Damage_GE.Creature_NecroMinionLatched_Damage_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreature_NecroMinionLatched_Damage_GE_C : UCreature_MinionLatched_Damage_GE_C {
};

