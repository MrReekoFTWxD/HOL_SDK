// BlueprintGeneratedClass CreatureMinion_PickupActor_GA.CreatureMinion_PickupActor_GA_C
// Size: 0x410 (Inherited: 0x3f8)
struct UCreatureMinion_PickupActor_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct ACreatureMinion_Base_BP_C* CreatureMinion_Cached; // 0x400(0x08)
	struct AActor* TargetActor_Cached; // 0x408(0x08)

	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayAbilitySpecHandle Handle, struct FGameplayTagContainer& RelevantTags); // Function CreatureMinion_PickupActor_GA.CreatureMinion_PickupActor_GA_C.K2_CanActivateAbility // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1953910
	void K2_ActivateAbility(); // Function CreatureMinion_PickupActor_GA.CreatureMinion_PickupActor_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_CreatureMinion_PickupActor_GA(int32_t EntryPoint); // Function CreatureMinion_PickupActor_GA.CreatureMinion_PickupActor_GA_C.ExecuteUbergraph_CreatureMinion_PickupActor_GA // (Final|UbergraphFunction) // @ game+0x1953910
};

