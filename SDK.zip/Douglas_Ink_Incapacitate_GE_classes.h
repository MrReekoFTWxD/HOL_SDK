// BlueprintGeneratedClass Douglas_Ink_Incapacitate_GE.Douglas_Ink_Incapacitate_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UDouglas_Ink_Incapacitate_GE_C : UORGameplayEffect {
};

