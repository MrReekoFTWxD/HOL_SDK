// BlueprintGeneratedClass Bouncy_GE.Bouncy_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UBouncy_GE_C : UORGameplayEffect {
};

