// BlueprintGeneratedClass Creature_MaxActiveMinionUpgrade3_Payload.Creature_MaxActiveMinionUpgrade3_Payload_C
// Size: 0x50 (Inherited: 0x50)
struct UCreature_MaxActiveMinionUpgrade3_Payload_C : UORItemEquipPayload_ItemEffects {
};

