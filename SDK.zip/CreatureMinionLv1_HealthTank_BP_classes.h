// BlueprintGeneratedClass CreatureMinionLv1_HealthTank_BP.CreatureMinionLv1_HealthTank_BP_C
// Size: 0x338 (Inherited: 0x330)
struct ACreatureMinionLv1_HealthTank_BP_C : AORHealthTankItem {
	struct USceneComponent* DefaultSceneRoot; // 0x330(0x08)
};

