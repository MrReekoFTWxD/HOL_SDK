// BlueprintGeneratedClass BP_Deepcut_Chonk.BP_Deepcut_Chonk_C
// Size: 0x250 (Inherited: 0x220)
struct ABP_Deepcut_Chonk_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct USceneComponent* DecalPosition; // 0x228(0x08)
	struct UNiagaraComponent* Niagara; // 0x230(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x238(0x08)
	float Min; // 0x240(0x04)
	float Max; // 0x244(0x04)
	float DecalLifetime; // 0x248(0x04)
	float Timestamp; // 0x24c(0x04)

	void SpawnBloodDecal(); // Function BP_Deepcut_Chonk.BP_Deepcut_Chonk_C.SpawnBloodDecal // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function BP_Deepcut_Chonk.BP_Deepcut_Chonk_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ReceiveTick(float DeltaSeconds); // Function BP_Deepcut_Chonk.BP_Deepcut_Chonk_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void Execute(); // Function BP_Deepcut_Chonk.BP_Deepcut_Chonk_C.Execute // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BP_Deepcut_Chonk(int32_t EntryPoint); // Function BP_Deepcut_Chonk.BP_Deepcut_Chonk_C.ExecuteUbergraph_BP_Deepcut_Chonk // (Final|UbergraphFunction) // @ game+0x1953910
};

