// BlueprintGeneratedClass Chonk_FriendlyProximityMine_Projectile_BP.Chonk_FriendlyProximityMine_Projectile_BP_C
// Size: 0x458 (Inherited: 0x439)
struct AChonk_FriendlyProximityMine_Projectile_BP_C : AChonk_ProximityMine_Projectile_BP_C {
	char pad_439[0x7]; // 0x439(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x440(0x08)
	struct FName TargetActor_Ability; // 0x448(0x08)
	struct AActor* TargetActor; // 0x450(0x08)

	bool AllowImpactWithActor(struct AActor* OtherActor); // Function Chonk_FriendlyProximityMine_Projectile_BP.Chonk_FriendlyProximityMine_Projectile_BP_C.AllowImpactWithActor // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function Chonk_FriendlyProximityMine_Projectile_BP.Chonk_FriendlyProximityMine_Projectile_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void SetTarget(struct AActor* Actor); // Function Chonk_FriendlyProximityMine_Projectile_BP.Chonk_FriendlyProximityMine_Projectile_BP_C.SetTarget // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Chonk_FriendlyProximityMine_Projectile_BP(int32_t EntryPoint); // Function Chonk_FriendlyProximityMine_Projectile_BP.Chonk_FriendlyProximityMine_Projectile_BP_C.ExecuteUbergraph_Chonk_FriendlyProximityMine_Projectile_BP // (Final|UbergraphFunction) // @ game+0x1953910
};

