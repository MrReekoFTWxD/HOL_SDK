// UserDefinedStruct ChefStandTransactionData.ChefStandTransactionData
// Size: 0x29 (Inherited: 0x00)
struct FChefStandTransactionData {
	struct FText FakeItemName_24_966531094CD2896127E14EA4B8E56744; // 0x00(0x18)
	struct FDataTableRowHandle VendorItem_29_E9A715DA45A5B2D8B4FDD6AC8C5DBBCC; // 0x18(0x10)
	bool IsSpecialItem_21_A463AF3545E3DCC6F35A918C1CA46CD6; // 0x28(0x01)
};

