// BlueprintGeneratedClass BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C
// Size: 0x500 (Inherited: 0x480)
struct ABaseSkelMeshCustomizableNPC_BP_C : AORBaseSkelMeshCustomizableNPC {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x480(0x08)
	struct USkeletalMeshComponent* ShoesMesh; // 0x488(0x08)
	struct USkeletalMeshComponent* LegsMesh; // 0x490(0x08)
	struct USkeletalMeshComponent* TorsoMesh; // 0x498(0x08)
	struct UORDetachedTriggerComponent* InterruptVolume; // 0x4a0(0x08)
	struct UNarrativeInfluenceVolumeComponent_BP_C* NIV; // 0x4a8(0x08)
	struct UTrigger_OptIntoComponent_C* OptIntoTrigger; // 0x4b0(0x08)
	struct UORTriggerVolumeComponent* ORTriggerVolume; // 0x4b8(0x08)
	struct UAnimSequence* IdleOverride; // 0x4c0(0x08)
	struct ATrigger_OptInto_C* OptInto; // 0x4c8(0x08)
	struct FMulticastInlineDelegate OnOptIn; // 0x4d0(0x30)

	void UpdateAnimationInEditor(); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.UpdateAnimationInEditor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetupAutomaticMaterialParams(); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.SetupAutomaticMaterialParams // (Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetOptIntoActive(bool InEnabled); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.SetOptIntoActive // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UserConstructionScript(); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void OnOptedInto(); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.OnOptedInto // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BaseSkelMeshCustomizableNPC_BP(int32_t EntryPoint); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.ExecuteUbergraph_BaseSkelMeshCustomizableNPC_BP // (Final|UbergraphFunction) // @ game+0x1953910
	void OnOptIn__DelegateSignature(struct UTrigger_OptIntoComponent_C* OptInto); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.OnOptIn__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

