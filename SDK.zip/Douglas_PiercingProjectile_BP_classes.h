// BlueprintGeneratedClass Douglas_PiercingProjectile_BP.Douglas_PiercingProjectile_BP_C
// Size: 0x3f0 (Inherited: 0x3d0)
struct ADouglas_PiercingProjectile_BP_C : AORProjectile {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d0(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x3d8(0x08)
	struct UStaticMeshComponent* Mesh; // 0x3e0(0x08)
	struct USceneComponent* ScaleParent; // 0x3e8(0x08)

	bool AllowBounce(struct AActor* OtherActor); // Function Douglas_PiercingProjectile_BP.Douglas_PiercingProjectile_BP_C.AllowBounce // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	bool AllowImpactWithActor(struct AActor* OtherActor); // Function Douglas_PiercingProjectile_BP.Douglas_PiercingProjectile_BP_C.AllowImpactWithActor // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AvoidedImpactResults(struct FHitResult& HitResult); // Function Douglas_PiercingProjectile_BP.Douglas_PiercingProjectile_BP_C.AvoidedImpactResults // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1953910
	void OnSpawnedFromPool(); // Function Douglas_PiercingProjectile_BP.Douglas_PiercingProjectile_BP_C.OnSpawnedFromPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnReturnedToPool(); // Function Douglas_PiercingProjectile_BP.Douglas_PiercingProjectile_BP_C.OnReturnedToPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnImpact(struct FHitResult& ImpactResult); // Function Douglas_PiercingProjectile_BP.Douglas_PiercingProjectile_BP_C.OnImpact // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Douglas_PiercingProjectile_BP(int32_t EntryPoint); // Function Douglas_PiercingProjectile_BP.Douglas_PiercingProjectile_BP_C.ExecuteUbergraph_Douglas_PiercingProjectile_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

