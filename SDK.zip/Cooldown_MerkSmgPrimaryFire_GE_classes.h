// BlueprintGeneratedClass Cooldown_MerkSmgPrimaryFire_GE.Cooldown_MerkSmgPrimaryFire_GE_C
// Size: 0x810 (Inherited: 0x810)
struct UCooldown_MerkSmgPrimaryFire_GE_C : UGameplayEffect {
};

