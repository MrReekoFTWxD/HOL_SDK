// UserDefinedEnum E_ImmortalMovementMode.E_ImmortalMovementMode
enum class E_ImmortalMovementMode : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	E_MAX = 3
};

