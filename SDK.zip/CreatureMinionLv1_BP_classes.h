// BlueprintGeneratedClass CreatureMinionLv1_BP.CreatureMinionLv1_BP_C
// Size: 0x227c (Inherited: 0x227c)
struct ACreatureMinionLv1_BP_C : ACreatureMinion_Base_BP_C {
};

