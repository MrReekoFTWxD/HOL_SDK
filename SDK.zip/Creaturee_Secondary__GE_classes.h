// BlueprintGeneratedClass Creaturee_Secondary__GE.Creaturee_Secondary__GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreaturee_Secondary__GE_C : UFireLoop_ADSMovementModifier_GE_C {
};

