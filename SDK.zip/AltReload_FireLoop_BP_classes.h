// BlueprintGeneratedClass AltReload_FireLoop_BP.AltReload_FireLoop_BP_C
// Size: 0x88 (Inherited: 0x88)
struct UAltReload_FireLoop_BP_C : UORFireLoop_Reload {

	bool CanFire(); // Function AltReload_FireLoop_BP.AltReload_FireLoop_BP_C.CanFire // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

