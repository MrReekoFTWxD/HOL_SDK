// BlueprintGeneratedClass Combo_SlimeField_FireActivator_GE.Combo_SlimeField_FireActivator_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCombo_SlimeField_FireActivator_GE_C : UCombo_GE_C {
};

