// BlueprintGeneratedClass Creature_PoppinMinions_Primary_FiringResult_BP.Creature_PoppinMinions_Primary_FiringResult_BP_C
// Size: 0x398 (Inherited: 0x398)
struct UCreature_PoppinMinions_Primary_FiringResult_BP_C : UCreature_MinionFire_FiringResult_BP_C {
};

