// BlueprintGeneratedClass Chonk_ArcSingleShot_Aggressive_FiringResult_BP.Chonk_ArcSingleShot_Aggressive_FiringResult_BP_C
// Size: 0x358 (Inherited: 0x358)
struct UChonk_ArcSingleShot_Aggressive_FiringResult_BP_C : UChonk_ArcSingleShot_FiringResult_BP_C {
};

