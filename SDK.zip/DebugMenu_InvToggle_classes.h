// WidgetBlueprintGeneratedClass DebugMenu_InvToggle.DebugMenu_InvToggle_C
// Size: 0x2d8 (Inherited: 0x290)
struct UDebugMenu_InvToggle_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UORWidget_Button_BP_C* ORWidget_Button_BP; // 0x298(0x08)
	struct FGameplayTag ItemTag; // 0x2a0(0x08)
	struct FMulticastInlineDelegate ItemButtonClicked; // 0x2a8(0x30)

	void SetItemData(struct FGameplayTag ItemTag, struct FText Label); // Function DebugMenu_InvToggle.DebugMenu_InvToggle_C.SetItemData // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugMenu_InvToggle.DebugMenu_InvToggle_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function DebugMenu_InvToggle.DebugMenu_InvToggle_C.BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugMenu_InvToggle(int32_t EntryPoint); // Function DebugMenu_InvToggle.DebugMenu_InvToggle_C.ExecuteUbergraph_DebugMenu_InvToggle // (Final|UbergraphFunction) // @ game+0x1953910
	void ItemButtonClicked__DelegateSignature(struct FGameplayTag Item Tag); // Function DebugMenu_InvToggle.DebugMenu_InvToggle_C.ItemButtonClicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

