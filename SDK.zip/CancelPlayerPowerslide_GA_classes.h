// BlueprintGeneratedClass CancelPlayerPowerslide_GA.CancelPlayerPowerslide_GA_C
// Size: 0x400 (Inherited: 0x3f8)
struct UCancelPlayerPowerslide_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)

	void K2_ActivateAbility(); // Function CancelPlayerPowerslide_GA.CancelPlayerPowerslide_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_CancelPlayerPowerslide_GA(int32_t EntryPoint); // Function CancelPlayerPowerslide_GA.CancelPlayerPowerslide_GA_C.ExecuteUbergraph_CancelPlayerPowerslide_GA // (Final|UbergraphFunction) // @ game+0x1953910
};

