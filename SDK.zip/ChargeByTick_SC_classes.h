// BlueprintGeneratedClass ChargeByTick_SC.ChargeByTick_SC_C
// Size: 0x58 (Inherited: 0x50)
struct UChargeByTick_SC_C : UORScriptComponent_ChargeByTick {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x50(0x08)

	bool GetIsActive(); // Function ChargeByTick_SC.ChargeByTick_SC_C.GetIsActive // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetIsActive(bool IsActive); // Function ChargeByTick_SC.ChargeByTick_SC_C.SetIsActive // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_ChargeByTick_SC(int32_t EntryPoint); // Function ChargeByTick_SC.ChargeByTick_SC_C.ExecuteUbergraph_ChargeByTick_SC // (Final|UbergraphFunction) // @ game+0x1953910
};

