// BlueprintGeneratedClass Creature_FireMod_ArchersFocus_BP.Creature_FireMod_ArchersFocus_BP_C
// Size: 0x1b8 (Inherited: 0x1b8)
struct UCreature_FireMod_ArchersFocus_BP_C : UORItemEquipPayload_WeaponMod {
};

