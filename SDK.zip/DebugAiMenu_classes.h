// WidgetBlueprintGeneratedClass DebugAiMenu.DebugAIMenu_C
// Size: 0x410 (Inherited: 0x3b1)
struct UDebugAIMenu_C : UDebugMenu_C {
	char pad_3B1[0x7]; // 0x3b1(0x07)
	struct UGridPanel* Grid; // 0x3b8(0x08)
	struct TMap<struct FString, struct FDebugCVarInfo> CVars; // 0x3c0(0x50)

	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugAiMenu.DebugAIMenu_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InitCVars(); // Function DebugAiMenu.DebugAIMenu_C.InitCVars // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AddAiElements(); // Function DebugAiMenu.DebugAIMenu_C.AddAiElements // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Initialize(); // Function DebugAiMenu.DebugAIMenu_C.Initialize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

