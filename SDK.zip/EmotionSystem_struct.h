// Enum EmotionSystem.EEmotionState
enum class EEmotionState : uint8 {
	Happy = 0,
	Sarcastic = 1,
	Excited = 2,
	Wicked = 3,
	Neutral = 4,
	Confused = 5,
	Determined = 6,
	Surprised = 7,
	Sad = 8,
	Angry = 9,
	Afraid = 10,
	Disgusted = 11,
	Exhausted = 12,
	EEmotionState_MAX = 13
};

// ScriptStruct EmotionSystem.EmotionStruct
// Size: 0x14 (Inherited: 0x00)
struct FEmotionStruct {
	char pad_0[0x14]; // 0x00(0x14)
};

// ScriptStruct EmotionSystem.EmotionTrackSectionParams
// Size: 0x08 (Inherited: 0x00)
struct FEmotionTrackSectionParams {
	enum class EEmotionState Emotion; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float ExtraDuration; // 0x04(0x04)
};

// ScriptStruct EmotionSystem.EmotionSectionTemplate
// Size: 0x40 (Inherited: 0x38)
struct FEmotionSectionTemplate : FMovieScenePropertySectionTemplate {
	struct FEmotionTrackSectionParams Data; // 0x38(0x08)
};

