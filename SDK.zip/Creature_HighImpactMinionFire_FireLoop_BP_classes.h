// BlueprintGeneratedClass Creature_HighImpactMinionFire_FireLoop_BP.Creature_HighImpactMinionFire_FireLoop_BP_C
// Size: 0x100 (Inherited: 0xc8)
struct UCreature_HighImpactMinionFire_FireLoop_BP_C : USQFireLoop_SemiAuto {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc8(0x08)
	struct ACreature_WeaponItem_BP_C* ParentCreatureWeaponItem; // 0xd0(0x08)
	struct UCreature_HighImpactMinionFire_FiringResult_BP_C* MyFiringResult; // 0xd8(0x08)
	struct TArray<struct UORScriptComponent*> ScriptComponents; // 0xe0(0x10)
	struct UCreature_HighImpactMinionFire_PreviewSC_C* FirePreviewSC; // 0xf0(0x08)
	struct FGameplayTag MyFireMode; // 0xf8(0x08)

	struct TArray<struct UORScriptComponent*> GetScriptComponents(); // Function Creature_HighImpactMinionFire_FireLoop_BP.Creature_HighImpactMinionFire_FireLoop_BP_C.GetScriptComponents // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void DisablePreview(); // Function Creature_HighImpactMinionFire_FireLoop_BP.Creature_HighImpactMinionFire_FireLoop_BP_C.DisablePreview // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void EnablePreview(); // Function Creature_HighImpactMinionFire_FireLoop_BP.Creature_HighImpactMinionFire_FireLoop_BP_C.EnablePreview // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetupPreviewSC(); // Function Creature_HighImpactMinionFire_FireLoop_BP.Creature_HighImpactMinionFire_FireLoop_BP_C.SetupPreviewSC // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetScriptComponents(struct TArray<struct UORScriptComponent*>& ScriptComponents); // Function Creature_HighImpactMinionFire_FireLoop_BP.Creature_HighImpactMinionFire_FireLoop_BP_C.SetScriptComponents // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BeginFireLoop(); // Function Creature_HighImpactMinionFire_FireLoop_BP.Creature_HighImpactMinionFire_FireLoop_BP_C.BeginFireLoop // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void BP_Init(struct FGameplayTag ModeKey); // Function Creature_HighImpactMinionFire_FireLoop_BP.Creature_HighImpactMinionFire_FireLoop_BP_C.BP_Init // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void EndFireLoop(); // Function Creature_HighImpactMinionFire_FireLoop_BP.Creature_HighImpactMinionFire_FireLoop_BP_C.EndFireLoop // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BP_PostInit(); // Function Creature_HighImpactMinionFire_FireLoop_BP.Creature_HighImpactMinionFire_FireLoop_BP_C.BP_PostInit // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_HighImpactMinionFire_FireLoop_BP(int32_t EntryPoint); // Function Creature_HighImpactMinionFire_FireLoop_BP.Creature_HighImpactMinionFire_FireLoop_BP_C.ExecuteUbergraph_Creature_HighImpactMinionFire_FireLoop_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

