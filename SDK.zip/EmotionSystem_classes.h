// Class EmotionSystem.AnimNotifyState_IgnoreEmotion
// Size: 0x30 (Inherited: 0x30)
struct UAnimNotifyState_IgnoreEmotion : UAnimNotifyState {
};

// Class EmotionSystem.EmotionComponent
// Size: 0x120 (Inherited: 0xb0)
struct UEmotionComponent : UActorComponent {
	struct UAnimSequence* HappyEmotionAnim; // 0xb0(0x08)
	struct UAnimSequence* SarcasticEmotionAnim; // 0xb8(0x08)
	struct UAnimSequence* ExcitedEmotionAnim; // 0xc0(0x08)
	struct UAnimSequence* WickedEmotionAnim; // 0xc8(0x08)
	struct UAnimSequence* NeutralEmotionAnim; // 0xd0(0x08)
	struct UAnimSequence* ConfusedEmotionAnim; // 0xd8(0x08)
	struct UAnimSequence* DeterminedEmotionAnim; // 0xe0(0x08)
	struct UAnimSequence* SurprisedEmotionAnim; // 0xe8(0x08)
	struct UAnimSequence* SadEmotionAnim; // 0xf0(0x08)
	struct UAnimSequence* AngryEmotionAnim; // 0xf8(0x08)
	struct UAnimSequence* AfraidEmotionAnim; // 0x100(0x08)
	struct UAnimSequence* DisgustedEmotionAnim; // 0x108(0x08)
	struct UAnimSequence* ExhaustedEmotionAnim; // 0x110(0x08)
	enum class EEmotionState CurrentEmotion; // 0x118(0x01)
	enum class EEmotionState DefaultEmotion; // 0x119(0x01)
	char pad_11A[0x6]; // 0x11a(0x06)

	void SetDefaultEmotion(enum class EEmotionState NewEmotion); // Function EmotionSystem.EmotionComponent.SetDefaultEmotion // (Final|Native|Public|BlueprintCallable) // @ game+0xc43070
	void SetCurrentEmotion(enum class EEmotionState NewEmotion); // Function EmotionSystem.EmotionComponent.SetCurrentEmotion // (Final|Native|Public|BlueprintCallable) // @ game+0xc42ff0
	bool IsDefaultEmotionOverridden(); // Function EmotionSystem.EmotionComponent.IsDefaultEmotionOverridden // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xc42fd0
	enum class EEmotionState GetEmotionEnumByEmoji(struct FString EmoticonString); // Function EmotionSystem.EmotionComponent.GetEmotionEnumByEmoji // (Final|Native|Static|Public) // @ game+0xc42ee0
	struct UAnimSequence* GetEmotionAnim(enum class EEmotionState Emotion); // Function EmotionSystem.EmotionComponent.GetEmotionAnim // (Final|Native|Public|BlueprintCallable) // @ game+0xc42e50
	enum class EEmotionState GetDefaultEmotion(); // Function EmotionSystem.EmotionComponent.GetDefaultEmotion // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xc42e30
	enum class EEmotionState GetCurrentEmotion(); // Function EmotionSystem.EmotionComponent.GetCurrentEmotion // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xc42e10
	void ClearCurrentEmotion(); // Function EmotionSystem.EmotionComponent.ClearCurrentEmotion // (Final|Native|Public|BlueprintCallable) // @ game+0xc42df0
};

// Class EmotionSystem.EmotionInterface
// Size: 0x28 (Inherited: 0x28)
struct UEmotionInterface : UInterface {

	void Stop(); // Function EmotionSystem.EmotionInterface.Stop // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xc43250
	void SetEmotionAllowed(bool bIsAllowed); // Function EmotionSystem.EmotionInterface.SetEmotionAllowed // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xc431c0
	void SetEmotion(enum class EEmotionState Emotion, float Duration); // Function EmotionSystem.EmotionInterface.SetEmotion // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xc430f0
};

// Class EmotionSystem.Settings_EmotionTrack
// Size: 0x40 (Inherited: 0x38)
struct USettings_EmotionTrack : UDeveloperSettings {
	float DefaultEmotionExtraDuration; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class EmotionSystem.EmotionTrack
// Size: 0xb8 (Inherited: 0x98)
struct UEmotionTrack : UMovieSceneNameableTrack {
	char pad_98[0x8]; // 0x98(0x08)
	int32_t InitialSectionCount; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct TArray<struct UMovieSceneSection*> Sections; // 0xa8(0x10)
};

// Class EmotionSystem.EmotionTrackSection
// Size: 0x100 (Inherited: 0xf0)
struct UEmotionTrackSection : UMovieSceneSection {
	struct FEmotionTrackSectionParams Params; // 0xf0(0x08)
	int32_t InitialFrameStart; // 0xf8(0x04)
	int32_t InitialFrameEnd; // 0xfc(0x04)
};

