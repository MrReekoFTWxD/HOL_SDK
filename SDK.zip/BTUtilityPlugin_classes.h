// Class BTUtilityPlugin.BTDecorator_UtilityFunction
// Size: 0x68 (Inherited: 0x68)
struct UBTDecorator_UtilityFunction : UBTDecorator {
};

// Class BTUtilityPlugin.BTComposite_Utility
// Size: 0x98 (Inherited: 0x90)
struct UBTComposite_Utility : UBTCompositeNode {
	enum class EUtilitySelectionMethod SelectionMethod; // 0x90(0x01)
	bool bShouldTryNextChildOnFailure; // 0x91(0x01)
	char pad_92[0x6]; // 0x92(0x06)
};

// Class BTUtilityPlugin.BTDecorator_UtilityBlackboard
// Size: 0x90 (Inherited: 0x68)
struct UBTDecorator_UtilityBlackboard : UBTDecorator_UtilityFunction {
	struct FBlackboardKeySelector UtilityValueKey; // 0x68(0x28)
};

// Class BTUtilityPlugin.BTDecorator_UtilityBlueprintBase
// Size: 0x78 (Inherited: 0x68)
struct UBTDecorator_UtilityBlueprintBase : UBTDecorator_UtilityFunction {
	struct AAIController* AIOwner; // 0x68(0x08)
	struct AActor* ActorOwner; // 0x70(0x08)

	float CalculateUtility(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTUtilityPlugin.BTDecorator_UtilityBlueprintBase.CalculateUtility // (Event|Protected|BlueprintEvent|Const) // @ game+0x1953910
};

// Class BTUtilityPlugin.BTDecorator_UtilityConstant
// Size: 0x70 (Inherited: 0x68)
struct UBTDecorator_UtilityConstant : UBTDecorator_UtilityFunction {
	float UtilityValue; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class BTUtilityPlugin.BTUtilitySelectionMethod
// Size: 0x28 (Inherited: 0x28)
struct UBTUtilitySelectionMethod : UObject {
};

