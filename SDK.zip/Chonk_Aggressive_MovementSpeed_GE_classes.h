// BlueprintGeneratedClass Chonk_Aggressive_MovementSpeed_GE.Chonk_Aggressive_MovementSpeed_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UChonk_Aggressive_MovementSpeed_GE_C : UORGameplayEffect {
};

