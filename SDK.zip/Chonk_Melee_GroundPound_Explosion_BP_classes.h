// BlueprintGeneratedClass Chonk_Melee_GroundPound_Explosion_BP.Chonk_Melee_GroundPound_Explosion_BP_C
// Size: 0x464 (Inherited: 0x438)
struct AChonk_Melee_GroundPound_Explosion_BP_C : AORExplosionActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x438(0x08)
	struct UNiagaraComponent* FXS_GroundPoundMelee_ChonkHunk; // 0x440(0x08)
	struct UNiagaraComponent* Niagara; // 0x448(0x08)
	struct UParticleSystemComponent* Explosion; // 0x450(0x08)
	struct UMatineeCameraShake* CameraShake2; // 0x458(0x08)
	float Radius; // 0x460(0x04)

	void ReceiveBeginPlay(); // Function Chonk_Melee_GroundPound_Explosion_BP.Chonk_Melee_GroundPound_Explosion_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ReceiveDestroyed(); // Function Chonk_Melee_GroundPound_Explosion_BP.Chonk_Melee_GroundPound_Explosion_BP_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Chonk_Melee_GroundPound_Explosion_BP(int32_t EntryPoint); // Function Chonk_Melee_GroundPound_Explosion_BP.Chonk_Melee_GroundPound_Explosion_BP_C.ExecuteUbergraph_Chonk_Melee_GroundPound_Explosion_BP // (Final|UbergraphFunction) // @ game+0x1953910
};

