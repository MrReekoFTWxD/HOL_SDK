// WidgetBlueprintGeneratedClass CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C
// Size: 0x44c (Inherited: 0x3a0)
struct UCharacterCreatorWidgetV2_BP_C : UORWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a0(0x08)
	struct UHorizontalBox* HorizontalBox_ButtonContainer; // 0x3a8(0x08)
	struct UImage* Image_BackgroundClickIntercept; // 0x3b0(0x08)
	struct UORButton* ORButton_CycleLeft; // 0x3b8(0x08)
	struct UORButton* ORButton_CycleRight; // 0x3c0(0x08)
	struct UORButton* ORButton_Select; // 0x3c8(0x08)
	struct FMulticastInlineDelegate OnSelectionChanged; // 0x3d0(0x30)
	struct FMulticastInlineDelegate OnCharacterSelected; // 0x400(0x30)
	bool NewVar_1; // 0x430(0x01)
	char pad_431[0x7]; // 0x431(0x07)
	struct UCharacterCreatorFullscreenContainer_BP_C* FullscreenContainer; // 0x438(0x08)
	int32_t Face Changes; // 0x440(0x04)
	struct FFocusEvent In Focus Event; // 0x444(0x08)

	struct FEventReply OnMouseButtonDown_1(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.OnMouseButtonDown_1 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void MatchWidgetToMirror(struct FVector2D ScreenPosition, float WidgetRadius); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.MatchWidgetToMirror // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct FEventReply OnPreviewKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.OnPreviewKeyDown // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SelectFace(int32_t FaceIndex); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.SelectFace // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void NavigateRight(); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.NavigateRight // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void NavigateLeft(); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.NavigateLeft // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__CharacterCreatorWidget_BP_ORButton_Select_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.BndEvt__CharacterCreatorWidget_BP_ORButton_Select_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void BndEvt__CharacterCreatorWidgetV2_BP_ORButton_CycleLeft_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.BndEvt__CharacterCreatorWidgetV2_BP_ORButton_CycleLeft_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void BndEvt__CharacterCreatorWidgetV2_BP_ORButton_CycleRight_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.BndEvt__CharacterCreatorWidgetV2_BP_ORButton_CycleRight_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_CharacterCreatorWidgetV2_BP(int32_t EntryPoint); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.ExecuteUbergraph_CharacterCreatorWidgetV2_BP // (Final|UbergraphFunction) // @ game+0x1953910
	void OnCharacterSelected__DelegateSignature(); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.OnCharacterSelected__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnSelectionChanged__DelegateSignature(bool bNavigateRight); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.OnSelectionChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

