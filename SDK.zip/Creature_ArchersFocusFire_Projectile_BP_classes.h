// BlueprintGeneratedClass Creature_ArchersFocusFire_Projectile_BP.Creature_ArchersFocusFire_Projectile_BP_C
// Size: 0x4b8 (Inherited: 0x4b8)
struct ACreature_ArchersFocusFire_Projectile_BP_C : ACreature_HighImpactMinionFire_Projectile_BP_C {
};

