// ScriptStruct DisableEyeAutomationTrack.DisableEyeAutomationTrackSectionParams
// Size: 0x01 (Inherited: 0x00)
struct FDisableEyeAutomationTrackSectionParams {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct DisableEyeAutomationTrack.DisableEyeAutomationSectionTemplate
// Size: 0x40 (Inherited: 0x38)
struct FDisableEyeAutomationSectionTemplate : FMovieScenePropertySectionTemplate {
	struct FDisableEyeAutomationTrackSectionParams Data; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

