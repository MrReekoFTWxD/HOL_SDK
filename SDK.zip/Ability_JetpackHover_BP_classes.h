// BlueprintGeneratedClass Ability_JetpackHover_BP.Ability_JetpackHover_BP_C
// Size: 0x3f8 (Inherited: 0x3f8)
struct UAbility_JetpackHover_BP_C : UORGameplayAbility_JetpackHover {
};

