// BlueprintGeneratedClass Creature_OutWithABlast_Damage_GE.Creature_OutWithABlast_Damage_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreature_OutWithABlast_Damage_GE_C : UORGameplayEffect {
};

