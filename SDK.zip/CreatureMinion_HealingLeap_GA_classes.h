// BlueprintGeneratedClass CreatureMinion_HealingLeap_GA.CreatureMinion_HealingLeap_GA_C
// Size: 0x488 (Inherited: 0x464)
struct UCreatureMinion_HealingLeap_GA_C : UCreatureMinion_LatchingLeap_GA_C {
	struct FName ControllingActorBBKeyName; // 0x464(0x08)
	char pad_46C[0x4]; // 0x46c(0x04)
	struct UGameplayEffect* HealingGE; // 0x470(0x08)
	struct FGameplayTag HealMagnitudeTag; // 0x478(0x08)
	struct UAkAudioEvent* HealAkEvent; // 0x480(0x08)

	void GetHealthToAdd(float& HealthToAdd); // Function CreatureMinion_HealingLeap_GA.CreatureMinion_HealingLeap_GA_C.GetHealthToAdd // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayAbilitySpecHandle Handle, struct FGameplayTagContainer& RelevantTags); // Function CreatureMinion_HealingLeap_GA.CreatureMinion_HealingLeap_GA_C.K2_CanActivateAbility // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1953910
	void OnReachedLatchTarget(struct AORCharacter* TargetORCharacter); // Function CreatureMinion_HealingLeap_GA.CreatureMinion_HealingLeap_GA_C.OnReachedLatchTarget // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetTargetFromOwningActor(struct AActor* OwningActor, bool& Success); // Function CreatureMinion_HealingLeap_GA.CreatureMinion_HealingLeap_GA_C.SetTargetFromOwningActor // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

