// BlueprintGeneratedClass Bouncy_Immunity_GE.Bouncy_Immunity_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UBouncy_Immunity_GE_C : UORGameplayEffect {
};

