// BlueprintGeneratedClass BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C
// Size: 0x198 (Inherited: 0x98)
struct UBTS_UpdateAttackLocation_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	struct FBlackboardKeySelector MoveToLocation; // 0xa0(0x28)
	struct FBlackboardKeySelector TargetActor; // 0xc8(0x28)
	struct FBlackboardKeySelector CombatMoveInProgress; // 0xf0(0x28)
	struct FBlackboardKeySelector AnchorRadius; // 0x118(0x28)
	struct FBlackboardKeySelector AttractionPointCoverType_Key; // 0x140(0x28)
	bool IsQueryRunning; // 0x168(0x01)
	char pad_169[0x7]; // 0x169(0x07)
	struct UEnvQueryInstanceBlueprintWrapper* RunningEQSQuery; // 0x170(0x08)
	struct UEnvQuery* MoveToBestAttackPositionQuery; // 0x178(0x08)
	struct UEnvQuery* InRangeAttackRepositionQuery; // 0x180(0x08)
	struct AORAICharacter* CachedControlledORAICharacter; // 0x188(0x08)
	struct AAIController* CachedAIController; // 0x190(0x08)

	void FindGoodAttractLocationForMove(struct AAIController* OwnerController, struct AORAICharacter* ControlledPawn, bool& FoundLocation, struct FVector& NewLocation); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.FindGoodAttractLocationForMove // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetBestEQSQueryForMove(struct AAIController* OwnerController, struct APawn* ControlledPawn, bool& NeedsToRunQuery, struct UEnvQuery*& QueryToRun, struct AORAIHenchmanController_BP_C*& ORProtoController); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.GetBestEQSQueryForMove // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void NeedsNewMoveToLocation(struct AAIController* OwnerController, struct APawn* ControlledPawn, bool& NeedsMove); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.NeedsNewMoveToLocation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void NeedsPositionForPeriodicMove(struct AActor* TargetActor, struct AORAIHenchmanController_BP_C* OwningController, struct APawn* ControlledPawn, bool& NeedsPosition); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.NeedsPositionForPeriodicMove // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void NeedsPositionForAttackRanging(struct AActor* TargetActor, struct AORAICharacter* ControlledPawn, bool& NeedsPosition); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.NeedsPositionForAttackRanging // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void EQS_QueryComplete(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.EQS_QueryComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.ReceiveDeactivationAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTS_UpdateAttackLocation(int32_t EntryPoint); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.ExecuteUbergraph_BTS_UpdateAttackLocation // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

