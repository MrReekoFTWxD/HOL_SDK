// WidgetBlueprintGeneratedClass DebugTabHeader.DebugTabHeader_C
// Size: 0x2f5 (Inherited: 0x290)
struct UDebugTabHeader_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UButton* Button_1; // 0x298(0x08)
	struct UTextBlock* TextBlock_1; // 0x2a0(0x08)
	struct FText Text; // 0x2a8(0x18)
	struct FMulticastInlineDelegate Clicked; // 0x2c0(0x30)
	int32_t Index; // 0x2f0(0x04)
	bool Active; // 0x2f4(0x01)

	struct FSlateColor Get_TextBlock_0_ColorAndOpacity_1(); // Function DebugTabHeader.DebugTabHeader_C.Get_TextBlock_0_ColorAndOpacity_1 // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	struct FText Get_TextBlock_0_Text_1(); // Function DebugTabHeader.DebugTabHeader_C.Get_TextBlock_0_Text_1 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function DebugTabHeader.DebugTabHeader_C.BndEvt__Button_0_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugTabHeader(int32_t EntryPoint); // Function DebugTabHeader.DebugTabHeader_C.ExecuteUbergraph_DebugTabHeader // (Final|UbergraphFunction) // @ game+0x1953910
	void Clicked__DelegateSignature(int32_t Index); // Function DebugTabHeader.DebugTabHeader_C.Clicked__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

