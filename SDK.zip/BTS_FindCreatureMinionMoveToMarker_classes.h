// BlueprintGeneratedClass BTS_FindCreatureMinionMoveToMarker.BTS_FindCreatureMinionMoveToMarker_C
// Size: 0xb0 (Inherited: 0x98)
struct UBTS_FindCreatureMinionMoveToMarker_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	bool IsQueryRunning; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
	struct AORAICreatureMinionController* CreatureMinionController_Chached; // 0xa8(0x08)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_FindCreatureMinionMoveToMarker.BTS_FindCreatureMinionMoveToMarker_C.ReceiveTickAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void QueryFinished(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus); // Function BTS_FindCreatureMinionMoveToMarker.BTS_FindCreatureMinionMoveToMarker_C.QueryFinished // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTS_FindCreatureMinionMoveToMarker(int32_t EntryPoint); // Function BTS_FindCreatureMinionMoveToMarker.BTS_FindCreatureMinionMoveToMarker_C.ExecuteUbergraph_BTS_FindCreatureMinionMoveToMarker // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

