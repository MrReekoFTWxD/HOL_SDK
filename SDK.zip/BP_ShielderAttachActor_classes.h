// BlueprintGeneratedClass BP_ShielderAttachActor.BP_ShielderAttachActor_C
// Size: 0x230 (Inherited: 0x220)
struct ABP_ShielderAttachActor_C : AActor {
	struct UStaticMeshComponent* AttachVisualizerCube; // 0x220(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x228(0x08)
};

