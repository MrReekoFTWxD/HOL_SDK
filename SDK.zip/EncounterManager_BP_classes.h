// BlueprintGeneratedClass EncounterManager_BP.EncounterManager_BP_C
// Size: 0x6ec (Inherited: 0x6e0)
struct AEncounterManager_BP_C : AOREncounterManager {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x6e0(0x08)
	float EncounterOverlapRadius; // 0x6e8(0x04)

	void SetWarpBase(int32_t Wave); // Function EncounterManager_BP.EncounterManager_BP_C.SetWarpBase // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Get Active Enemies in Encounter(struct TArray<struct AORAICharacter*>& ActiveEnemies); // Function EncounterManager_BP.EncounterManager_BP_C.Get Active Enemies in Encounter // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function EncounterManager_BP.EncounterManager_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void OnWaveAdvance_Event(int32_t Wave); // Function EncounterManager_BP.EncounterManager_BP_C.OnWaveAdvance_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_EncounterManager_BP(int32_t EntryPoint); // Function EncounterManager_BP.EncounterManager_BP_C.ExecuteUbergraph_EncounterManager_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

