// BlueprintGeneratedClass Ability_OpenPauseMenu.Ability_OpenPauseMenu_C
// Size: 0x408 (Inherited: 0x3f8)
struct UAbility_OpenPauseMenu_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct UPauseMenuPayload_C* Payload; // 0x400(0x08)

	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayAbilitySpecHandle Handle, struct FGameplayTagContainer& RelevantTags); // Function Ability_OpenPauseMenu.Ability_OpenPauseMenu_C.K2_CanActivateAbility // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1953910
	void K2_ActivateAbility(); // Function Ability_OpenPauseMenu.Ability_OpenPauseMenu_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Ability_OpenPauseMenu(int32_t EntryPoint); // Function Ability_OpenPauseMenu.Ability_OpenPauseMenu_C.ExecuteUbergraph_Ability_OpenPauseMenu // (Final|UbergraphFunction) // @ game+0x1953910
};

