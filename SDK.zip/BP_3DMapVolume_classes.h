// BlueprintGeneratedClass BP_3DMapVolume.BP_3DMapVolume_C
// Size: 0x290 (Inherited: 0x278)
struct ABP_3DMapVolume_C : AOR3DMapVolume {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x278(0x08)
	struct UStaticMeshComponent* EditorPreview; // 0x280(0x08)
	struct UBillboardComponent* EditorBillboard; // 0x288(0x08)

	void UserConstructionScript(); // Function BP_3DMapVolume.BP_3DMapVolume_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnActorEnterMapVolume(struct AActor* Actor, struct AORTriggerVolume* Volume); // Function BP_3DMapVolume.BP_3DMapVolume_C.OnActorEnterMapVolume // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BP_3DMapVolume(int32_t EntryPoint); // Function BP_3DMapVolume.BP_3DMapVolume_C.ExecuteUbergraph_BP_3DMapVolume // (Final|UbergraphFunction) // @ game+0x1953910
};

