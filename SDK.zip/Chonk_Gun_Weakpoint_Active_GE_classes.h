// BlueprintGeneratedClass Chonk_Gun_Weakpoint_Active_GE.Chonk_Gun_Weakpoint_Active_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UChonk_Gun_Weakpoint_Active_GE_C : UORGameplayEffect {
};

