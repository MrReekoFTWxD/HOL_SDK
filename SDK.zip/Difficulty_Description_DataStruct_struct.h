// UserDefinedStruct Difficulty_Description_DataStruct.Difficulty_Description_DataStruct
// Size: 0x31 (Inherited: 0x00)
struct FDifficulty_Description_DataStruct {
	struct FText Name_5_44C1CDCA4AE602E4D65909BCFD6A7C18; // 0x00(0x18)
	struct FText Description_8_60AF3EEC4AEFFE977771F88BAE5D474C; // 0x18(0x18)
	char DifficultyAmount_12_724AE0784A9FFE03673ADF98B376108A; // 0x30(0x01)
};

