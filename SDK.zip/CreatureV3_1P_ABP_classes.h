// AnimBlueprintGeneratedClass CreatureV3_1P_ABP.CreatureV3_1P_ABP_C
// Size: 0x8840 (Inherited: 0x8840)
struct UCreatureV3_1P_ABP_C : USharedPlayer1P_ABP_C {

	bool K2_OwnerItemEventFired(struct ASQInventoryItem* Item, struct FGameplayTag EventTag, struct FGameplayTag FireModeTag, enum class EInventoryTransactionType TransactionType); // Function CreatureV3_1P_ABP.CreatureV3_1P_ABP_C.K2_OwnerItemEventFired // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

