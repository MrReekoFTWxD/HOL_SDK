// BlueprintGeneratedClass Chonk_IntroJump_GA.Chonk_IntroJump_GA_C
// Size: 0x43c (Inherited: 0x3f8)
struct UChonk_IntroJump_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct AORCharacter* OwningCharacter; // 0x400(0x08)
	struct UAnimMontage* MontageToPlay; // 0x408(0x08)
	struct UORCharacterMovementComponent* Character Movement; // 0x410(0x08)
	struct AActor* ExplosionClass; // 0x418(0x08)
	enum class ECollisionResponse DefaultCollisionResponseToPawns; // 0x420(0x01)
	char pad_421[0x3]; // 0x421(0x03)
	struct FVector Facing Direction; // 0x424(0x0c)
	bool InFallingState; // 0x430(0x01)
	char pad_431[0x3]; // 0x431(0x03)
	struct FName DefaultCollisionProfile; // 0x434(0x08)

	void BindToOnLanded(bool BindToOnLanded); // Function Chonk_IntroJump_GA.Chonk_IntroJump_GA_C.BindToOnLanded // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetLaunchVelocity(struct FVector& LaunchVelocity); // Function Chonk_IntroJump_GA.Chonk_IntroJump_GA_C.GetLaunchVelocity // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnNotifyEnd_4414FCDE402F719B49727E86EB008E8F(struct FName NotifyName); // Function Chonk_IntroJump_GA.Chonk_IntroJump_GA_C.OnNotifyEnd_4414FCDE402F719B49727E86EB008E8F // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnNotifyBegin_4414FCDE402F719B49727E86EB008E8F(struct FName NotifyName); // Function Chonk_IntroJump_GA.Chonk_IntroJump_GA_C.OnNotifyBegin_4414FCDE402F719B49727E86EB008E8F // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnInterrupted_4414FCDE402F719B49727E86EB008E8F(struct FName NotifyName); // Function Chonk_IntroJump_GA.Chonk_IntroJump_GA_C.OnInterrupted_4414FCDE402F719B49727E86EB008E8F // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnBlendOut_4414FCDE402F719B49727E86EB008E8F(struct FName NotifyName); // Function Chonk_IntroJump_GA.Chonk_IntroJump_GA_C.OnBlendOut_4414FCDE402F719B49727E86EB008E8F // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_4414FCDE402F719B49727E86EB008E8F(struct FName NotifyName); // Function Chonk_IntroJump_GA.Chonk_IntroJump_GA_C.OnCompleted_4414FCDE402F719B49727E86EB008E8F // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_4F99826448D80252712FD19116ED769E(); // Function Chonk_IntroJump_GA.Chonk_IntroJump_GA_C.OnCompleted_4F99826448D80252712FD19116ED769E // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnTick_4F99826448D80252712FD19116ED769E(float DeltaTime, float TotalElapsed); // Function Chonk_IntroJump_GA.Chonk_IntroJump_GA_C.OnTick_4F99826448D80252712FD19116ED769E // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_CommitExecute(); // Function Chonk_IntroJump_GA.Chonk_IntroJump_GA_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function Chonk_IntroJump_GA.Chonk_IntroJump_GA_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void OnCharacterLanded(struct FHitResult& Hit); // Function Chonk_IntroJump_GA.Chonk_IntroJump_GA_C.OnCharacterLanded // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void MovementModeChanged(struct ACharacter* Character, enum class EMovementMode PrevMovementMode, char PreviousCustomMode); // Function Chonk_IntroJump_GA.Chonk_IntroJump_GA_C.MovementModeChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function Chonk_IntroJump_GA.Chonk_IntroJump_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Chonk_IntroJump_GA(int32_t EntryPoint); // Function Chonk_IntroJump_GA.Chonk_IntroJump_GA_C.ExecuteUbergraph_Chonk_IntroJump_GA // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

