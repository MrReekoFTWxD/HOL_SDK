// BlueprintGeneratedClass Chonk_Melee_ProtoSlam_Explosion_BP.Chonk_Melee_ProtoSlam_Explosion_BP_C
// Size: 0x438 (Inherited: 0x438)
struct AChonk_Melee_ProtoSlam_Explosion_BP_C : AORExplosionActor {
};

