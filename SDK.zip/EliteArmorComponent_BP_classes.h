// BlueprintGeneratedClass EliteArmorComponent_BP.EliteArmorComponent_BP_C
// Size: 0xe0 (Inherited: 0xd8)
struct UEliteArmorComponent_BP_C : UOREliteArmorComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xd8(0x08)

	void OnArmorHealthChanged(float HealthPCT); // Function EliteArmorComponent_BP.EliteArmorComponent_BP_C.OnArmorHealthChanged // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_EliteArmorComponent_BP(int32_t EntryPoint); // Function EliteArmorComponent_BP.EliteArmorComponent_BP_C.ExecuteUbergraph_EliteArmorComponent_BP // (Final|UbergraphFunction) // @ game+0x1953910
};

