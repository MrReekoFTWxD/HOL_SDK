// BlueprintGeneratedClass Creature_AbilityUpgrade1_Payload_BP.Creature_AbilityUpgrade1_Payload_BP_C
// Size: 0x50 (Inherited: 0x50)
struct UCreature_AbilityUpgrade1_Payload_BP_C : UORItemEquipPayload_ItemEffects {
};

