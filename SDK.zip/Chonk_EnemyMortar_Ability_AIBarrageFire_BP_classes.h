// BlueprintGeneratedClass Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C
// Size: 0x47c (Inherited: 0x468)
struct UChonk_EnemyMortar_Ability_AIBarrageFire_BP_C : UAbility_AIChargeAndFireMultipleTimesItemMontage_BP_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x468(0x08)
	struct AChonk_BP_C* ChonkBP; // 0x470(0x08)
	float CurrentGunDamage; // 0x478(0x04)

	void SetNDBarrageInterruptData(); // Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.SetNDBarrageInterruptData // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayAbilitySpecHandle Handle, struct FGameplayTagContainer& RelevantTags); // Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.K2_CanActivateAbility // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1953910
	void OwnerDamageTaken(struct UObject* Damager, struct AORCharacter* Damaged, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.OwnerDamageTaken // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Chonk_EnemyMortar_Ability_AIBarrageFire_BP(int32_t EntryPoint); // Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.ExecuteUbergraph_Chonk_EnemyMortar_Ability_AIBarrageFire_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

