// BlueprintGeneratedClass Creature_MaxActiveMinionUpgrade2_Payload.Creature_MaxActiveMinionUpgrade2_Payload_C
// Size: 0x50 (Inherited: 0x50)
struct UCreature_MaxActiveMinionUpgrade2_Payload_C : UORItemEquipPayload_ItemEffects {
};

