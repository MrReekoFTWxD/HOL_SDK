// BlueprintGeneratedClass Creature_CartridgeMinionAttachment_BP.Creature_CartridgeMinionAttachment_BP_C
// Size: 0x264 (Inherited: 0x220)
struct ACreature_CartridgeMinionAttachment_BP_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct UORAkComponent* ORAk; // 0x228(0x08)
	struct USkeletalMeshComponent* SkeletalMesh; // 0x230(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x238(0x08)
	enum class Creature_CreatureMinionStatus CreatureMinionStatus; // 0x240(0x01)
	char pad_241[0x7]; // 0x241(0x07)
	struct TArray<struct UAnimMontage*> ReloadAnimations; // 0x248(0x10)
	struct ACreature_CartridgeAttachment_BP_C* CreatureCartridgeAttachmentBP; // 0x258(0x08)
	int32_t SocketIndex; // 0x260(0x04)

	void PlayReloadMontage(float Delay, float PlayRate); // Function Creature_CartridgeMinionAttachment_BP.Creature_CartridgeMinionAttachment_BP_C.PlayReloadMontage // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void PlayFireMontage(); // Function Creature_CartridgeMinionAttachment_BP.Creature_CartridgeMinionAttachment_BP_C.PlayFireMontage // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InitSocketMinionAttachment(struct ACreature_WeaponItem_BP_C* CreatureWeaponItem, struct ACreature_CartridgeAttachment_BP_C* CreatureCartridgeAttachment, int32_t SocketIndex); // Function Creature_CartridgeMinionAttachment_BP.Creature_CartridgeMinionAttachment_BP_C.InitSocketMinionAttachment // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetChargingState(bool Charging); // Function Creature_CartridgeMinionAttachment_BP.Creature_CartridgeMinionAttachment_BP_C.SetChargingState // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StopAllMontages(); // Function Creature_CartridgeMinionAttachment_BP.Creature_CartridgeMinionAttachment_BP_C.StopAllMontages // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_CartridgeMinionAttachment_BP(int32_t EntryPoint); // Function Creature_CartridgeMinionAttachment_BP.Creature_CartridgeMinionAttachment_BP_C.ExecuteUbergraph_Creature_CartridgeMinionAttachment_BP // (Final|UbergraphFunction) // @ game+0x1953910
};

