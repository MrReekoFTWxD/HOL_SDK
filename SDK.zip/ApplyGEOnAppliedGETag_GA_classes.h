// BlueprintGeneratedClass ApplyGEOnAppliedGETag_GA.ApplyGEOnAppliedGETag_GA_C
// Size: 0x498 (Inherited: 0x480)
struct UApplyGEOnAppliedGETag_GA_C : UActivateOnAppliedGETag_GA_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x480(0x08)
	struct TArray<struct UGameplayEffect*> GEToApply; // 0x488(0x10)

	void K2_CommitExecute(); // Function ApplyGEOnAppliedGETag_GA.ApplyGEOnAppliedGETag_GA_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_ApplyGEOnAppliedGETag_GA(int32_t EntryPoint); // Function ApplyGEOnAppliedGETag_GA.ApplyGEOnAppliedGETag_GA_C.ExecuteUbergraph_ApplyGEOnAppliedGETag_GA // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

