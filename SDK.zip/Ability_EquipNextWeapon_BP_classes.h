// BlueprintGeneratedClass Ability_EquipNextWeapon_BP.Ability_EquipNextWeapon_BP_C
// Size: 0x401 (Inherited: 0x3e0)
struct UAbility_EquipNextWeapon_BP_C : UAbility_ChangeEquippedItemBase_BP_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3e0(0x08)
	struct TArray<struct FGameplayTag> PlayerWeaponEquipOrder; // 0x3e8(0x10)
	int32_t StartingWeaponIndex; // 0x3f8(0x04)
	int32_t CurrentWeaponIndex; // 0x3fc(0x04)
	bool ShouldKeepCycling; // 0x400(0x01)

	void SafelyIncrementWeaponIndex(); // Function Ability_EquipNextWeapon_BP.Ability_EquipNextWeapon_BP_C.SafelyIncrementWeaponIndex // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void EvaluateCycleCondition(struct UORCharacterInventory* Inventory); // Function Ability_EquipNextWeapon_BP.Ability_EquipNextWeapon_BP_C.EvaluateCycleCondition // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void IsCurrentIndexValidEquippable(struct UORCharacterInventory* Inventory, bool& Valid); // Function Ability_EquipNextWeapon_BP.Ability_EquipNextWeapon_BP_C.IsCurrentIndexValidEquippable // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function Ability_EquipNextWeapon_BP.Ability_EquipNextWeapon_BP_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Ability_EquipNextWeapon_BP(int32_t EntryPoint); // Function Ability_EquipNextWeapon_BP.Ability_EquipNextWeapon_BP_C.ExecuteUbergraph_Ability_EquipNextWeapon_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

