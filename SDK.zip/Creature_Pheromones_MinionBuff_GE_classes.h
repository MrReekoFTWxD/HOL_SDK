// BlueprintGeneratedClass Creature_Pheromones_MinionBuff_GE.Creature_Pheromones_MinionBuff_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreature_Pheromones_MinionBuff_GE_C : UORGameplayEffect {
};

