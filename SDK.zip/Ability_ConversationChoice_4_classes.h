// BlueprintGeneratedClass Ability_ConversationChoice_4.Ability_ConversationChoice_3_C
// Size: 0x400 (Inherited: 0x400)
struct UAbility_ConversationChoice_3_C : UORGameplayAbility_ConversationChoice {
};

