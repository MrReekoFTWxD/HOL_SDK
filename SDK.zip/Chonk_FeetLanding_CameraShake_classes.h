// BlueprintGeneratedClass Chonk_FeetLanding_CameraShake.Chonk_FeetLanding_CameraShake_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UChonk_FeetLanding_CameraShake_C : UMatineeCameraShake {
};

