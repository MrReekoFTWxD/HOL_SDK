// BlueprintGeneratedClass CreatureMinionLv1_MeleeAttack_Damage_GE.CreatureMinionLv1_MeleeAttack_Damage_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreatureMinionLv1_MeleeAttack_Damage_GE_C : UORGameplayEffect {
};

