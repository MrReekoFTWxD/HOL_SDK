// BlueprintGeneratedClass BTS_RequestReturnAttackToken.BTS_RequestReturnAttackToken_C
// Size: 0xc8 (Inherited: 0x98)
struct UBTS_RequestReturnAttackToken_C : UBTService_BlueprintBase {
	struct FGameplayTag CharacterAbilityTag; // 0x98(0x08)
	struct FBlackboardKeySelector TargetActorKey; // 0xa0(0x28)

	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_RequestReturnAttackToken.BTS_RequestReturnAttackToken_C.ReceiveDeactivationAI // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_RequestReturnAttackToken.BTS_RequestReturnAttackToken_C.ReceiveActivationAI // (Event|Protected|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

