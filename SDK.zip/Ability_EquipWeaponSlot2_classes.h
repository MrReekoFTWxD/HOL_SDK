// BlueprintGeneratedClass Ability_EquipWeaponSlot2.Ability_EquipWeaponSlot2_C
// Size: 0x400 (Inherited: 0x3f5)
struct UAbility_EquipWeaponSlot2_C : UAbility_ChangeEquippedWeapon_C {
	char pad_3F5[0x3]; // 0x3f5(0x03)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)

	void K2_OnEndAbility(bool bWasCancelled); // Function Ability_EquipWeaponSlot2.Ability_EquipWeaponSlot2_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Ability_EquipWeaponSlot2(int32_t EntryPoint); // Function Ability_EquipWeaponSlot2.Ability_EquipWeaponSlot2_C.ExecuteUbergraph_Ability_EquipWeaponSlot2 // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

