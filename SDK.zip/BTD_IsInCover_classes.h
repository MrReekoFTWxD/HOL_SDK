// BlueprintGeneratedClass BTD_IsInCover.BTD_IsInCover_C
// Size: 0xa8 (Inherited: 0xa0)
struct UBTD_IsInCover_C : UBTDecorator_BlueprintBase {
	struct FGameplayTag TakingCoverGamplayTag; // 0xa0(0x08)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_IsInCover.BTD_IsInCover_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

