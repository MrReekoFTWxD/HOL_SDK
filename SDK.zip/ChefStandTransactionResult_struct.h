// UserDefinedEnum ChefStandTransactionResult.ChefStandTransactionResult
enum class ChefStandTransactionResult : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator4 = 2,
	ChefStandTransactionResult_MAX = 3
};

