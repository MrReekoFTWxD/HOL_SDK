// BlueprintGeneratedClass ArmorPlatedMyte_BP.ArmorPlatedMyte_BP_C
// Size: 0x21a8 (Inherited: 0x2172)
struct AArmorPlatedMyte_BP_C : AMyte_BP_C {
	char pad_2172[0x6]; // 0x2172(0x06)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2178(0x08)
	struct UStaticMeshComponent* ArmorMesh; // 0x2180(0x08)
	struct FGameplayTagContainer WeakpointTags; // 0x2188(0x20)

	void IsArmored(bool& Armored); // Function ArmorPlatedMyte_BP.ArmorPlatedMyte_BP_C.IsArmored // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetupDynamicMaterialInstances(); // Function ArmorPlatedMyte_BP.ArmorPlatedMyte_BP_C.SetupDynamicMaterialInstances // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UpdateHeadHitzone(bool Enabled); // Function ArmorPlatedMyte_BP.ArmorPlatedMyte_BP_C.UpdateHeadHitzone // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void RemoveArmor(); // Function ArmorPlatedMyte_BP.ArmorPlatedMyte_BP_C.RemoveArmor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function ArmorPlatedMyte_BP.ArmorPlatedMyte_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void OnDied(struct UObject* Killer, struct FHitResult& HitResult, struct FGameplayTagContainer& DamageTags); // Function ArmorPlatedMyte_BP.ArmorPlatedMyte_BP_C.OnDied // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1953910
	void BP_SpawnedFromPool(); // Function ArmorPlatedMyte_BP.ArmorPlatedMyte_BP_C.BP_SpawnedFromPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_ArmorPlatedMyte_BP(int32_t EntryPoint); // Function ArmorPlatedMyte_BP.ArmorPlatedMyte_BP_C.ExecuteUbergraph_ArmorPlatedMyte_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

