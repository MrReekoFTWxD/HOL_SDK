// WidgetBlueprintGeneratedClass DetectiveMode_CompletedAnalysis_Widget.DetectiveMode_CompletedAnalysis_Widget_C
// Size: 0x44c (Inherited: 0x410)
struct UDetectiveMode_CompletedAnalysis_Widget_C : UORWidget_HUDPrompt {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x410(0x08)
	struct UWidgetAnimation* ShowAnimation; // 0x418(0x08)
	struct UWidgetAnimation* DisplayLoopAnimation; // 0x420(0x08)
	struct UImage* Image_86; // 0x428(0x08)
	struct UImage* Image_87; // 0x430(0x08)
	struct UOverlay* Overlay_26; // 0x438(0x08)
	struct UScaleBox* ScaleBox_1; // 0x440(0x08)
	float lastShowTime; // 0x448(0x04)

	void Construct(); // Function DetectiveMode_CompletedAnalysis_Widget.DetectiveMode_CompletedAnalysis_Widget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1953910
	void ShowIndicator(); // Function DetectiveMode_CompletedAnalysis_Widget.DetectiveMode_CompletedAnalysis_Widget_C.ShowIndicator // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnShowedIndicator(); // Function DetectiveMode_CompletedAnalysis_Widget.DetectiveMode_CompletedAnalysis_Widget_C.OnShowedIndicator // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void HideIndicator(); // Function DetectiveMode_CompletedAnalysis_Widget.DetectiveMode_CompletedAnalysis_Widget_C.HideIndicator // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnHidIndicator(); // Function DetectiveMode_CompletedAnalysis_Widget.DetectiveMode_CompletedAnalysis_Widget_C.OnHidIndicator // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetOffset(struct FVector2D Offset); // Function DetectiveMode_CompletedAnalysis_Widget.DetectiveMode_CompletedAnalysis_Widget_C.SetOffset // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DetectiveMode_CompletedAnalysis_Widget(int32_t EntryPoint); // Function DetectiveMode_CompletedAnalysis_Widget.DetectiveMode_CompletedAnalysis_Widget_C.ExecuteUbergraph_DetectiveMode_CompletedAnalysis_Widget // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

