// BlueprintGeneratedClass Creature_ChargingADS_FireLoop_BP.Creature_ChargingADS_FireLoop_BP_C
// Size: 0x100 (Inherited: 0xb1)
struct UCreature_ChargingADS_FireLoop_BP_C : UFireLoop_ADSMovementModifier_BP_C {
	char pad_B1[0x7]; // 0xb1(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb8(0x08)
	struct ACreature_WeaponItem_BP_C* ParentCreatureWeaponItem; // 0xc0(0x08)
	struct ACreature_WeaponAttachment_BP_C* CreatureWeaponAttachment; // 0xc8(0x08)
	struct UCreature_MinionFire_FireLoop_BP_C* MinionFireFireLoop; // 0xd0(0x08)
	struct FGameplayTag MinionFireMode; // 0xd8(0x08)
	struct UCreature_HighImpactMinionFire_FireLoop_BP_C* HighImpactMinionFireFireLoop; // 0xe0(0x08)
	struct FGameplayTag HighImpactMinionFireMode; // 0xe8(0x08)
	struct FGameplayTag MindControlFireMode; // 0xf0(0x08)
	struct UCreature_MindControl_FireLoop_BP_C* MindControlFireLoop; // 0xf8(0x08)

	void ADSOn(bool& ADSOn); // Function Creature_ChargingADS_FireLoop_BP.Creature_ChargingADS_FireLoop_BP_C.ADSOn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void BP_Init(struct FGameplayTag ModeKey); // Function Creature_ChargingADS_FireLoop_BP.Creature_ChargingADS_FireLoop_BP_C.BP_Init // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void BeginFireLoop(); // Function Creature_ChargingADS_FireLoop_BP.Creature_ChargingADS_FireLoop_BP_C.BeginFireLoop // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void BP_PostInit(); // Function Creature_ChargingADS_FireLoop_BP.Creature_ChargingADS_FireLoop_BP_C.BP_PostInit // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void EndFireLoop(); // Function Creature_ChargingADS_FireLoop_BP.Creature_ChargingADS_FireLoop_BP_C.EndFireLoop // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CancelFireLoop(); // Function Creature_ChargingADS_FireLoop_BP.Creature_ChargingADS_FireLoop_BP_C.CancelFireLoop // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_ChargingADS_FireLoop_BP(int32_t EntryPoint); // Function Creature_ChargingADS_FireLoop_BP.Creature_ChargingADS_FireLoop_BP_C.ExecuteUbergraph_Creature_ChargingADS_FireLoop_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

