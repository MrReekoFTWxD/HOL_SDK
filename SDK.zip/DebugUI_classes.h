// WidgetBlueprintGeneratedClass DebugUI.DebugUI_C
// Size: 0x328 (Inherited: 0x290)
struct UDebugUI_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UHorizontalBox* Content; // 0x298(0x08)
	struct UTextBlock* EngineVersion; // 0x2a0(0x08)
	struct TArray<struct UDebugMenu_C*> MenuStack; // 0x2a8(0x10)
	struct FMulticastInlineDelegate OnRemoveSelf; // 0x2b8(0x30)
	struct FMulticastInlineDelegate OnClose; // 0x2e8(0x30)
	bool AllowClose; // 0x318(0x01)
	char pad_319[0x7]; // 0x319(0x07)
	struct UDebugMenu_C* DebugMainMenu_BP; // 0x320(0x08)

	void Close(); // Function DebugUI.DebugUI_C.Close // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct FEventReply OnKeyUp(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function DebugUI.DebugUI_C.OnKeyUp // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function DebugUI.DebugUI_C.OnKeyDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugUI.DebugUI_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AddContent(struct UWidget* InContent); // Function DebugUI.DebugUI_C.AddContent // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void DebugMenuEnd(); // Function DebugUI.DebugUI_C.DebugMenuEnd // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void DebugMenuBegin(); // Function DebugUI.DebugUI_C.DebugMenuBegin // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Remove All Menus(); // Function DebugUI.DebugUI_C.Remove All Menus // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void RemoveMenu(); // Function DebugUI.DebugUI_C.RemoveMenu // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void AddMenu(struct UDebugMenu_C* InWidget, struct UDebugMenu_C*& OutWidget); // Function DebugUI.DebugUI_C.AddMenu // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Construct(); // Function DebugUI.DebugUI_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnInitialized(); // Function DebugUI.DebugUI_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1953910
	void Destruct(); // Function DebugUI.DebugUI_C.Destruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1953910
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function DebugUI.DebugUI_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugUI(int32_t EntryPoint); // Function DebugUI.DebugUI_C.ExecuteUbergraph_DebugUI // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
	void OnClose__DelegateSignature(); // Function DebugUI.DebugUI_C.OnClose__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnRemoveSelf__DelegateSignature(); // Function DebugUI.DebugUI_C.OnRemoveSelf__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

