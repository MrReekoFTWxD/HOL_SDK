// BlueprintGeneratedClass EnemyComboKnockup_GE.EnemyComboKnockup_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UEnemyComboKnockup_GE_C : UORGameplayEffect {
};

