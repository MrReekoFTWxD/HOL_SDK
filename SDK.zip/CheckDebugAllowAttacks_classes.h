// BlueprintGeneratedClass CheckDebugAllowAttacks.CheckDebugAllowAttacks_C
// Size: 0xc8 (Inherited: 0xc8)
struct UCheckDebugAllowAttacks_C : UUtilityConsideration {
};

