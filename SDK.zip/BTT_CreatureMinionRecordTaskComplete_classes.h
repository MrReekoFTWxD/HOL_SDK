// BlueprintGeneratedClass BTT_CreatureMinionRecordTaskComplete.BTT_CreatureMinionRecordTaskComplete_C
// Size: 0xb0 (Inherited: 0xa8)
struct UBTT_CreatureMinionRecordTaskComplete_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_CreatureMinionRecordTaskComplete.BTT_CreatureMinionRecordTaskComplete_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTT_CreatureMinionRecordTaskComplete(int32_t EntryPoint); // Function BTT_CreatureMinionRecordTaskComplete.BTT_CreatureMinionRecordTaskComplete_C.ExecuteUbergraph_BTT_CreatureMinionRecordTaskComplete // (Final|UbergraphFunction) // @ game+0x1953910
};

