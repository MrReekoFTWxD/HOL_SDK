// BlueprintGeneratedClass ArmorPlatedMyte_RemovePlate_GE.ArmorPlatedMyte_RemovePlate_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UArmorPlatedMyte_RemovePlate_GE_C : UORGameplayEffect {
};

