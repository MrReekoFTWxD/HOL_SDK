// BlueprintGeneratedClass Creature_CartridgeAttachment_BP.Creature_CartridgeAttachment_BP_C
// Size: 0x258 (Inherited: 0x220)
struct ACreature_CartridgeAttachment_BP_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct USkeletalMeshComponent* SkeletalMesh; // 0x228(0x08)
	enum class Creature_CreatureMinionStatus CreatureMinionStatus; // 0x230(0x01)
	char pad_231[0x7]; // 0x231(0x07)
	struct TArray<struct UAnimMontage*> FireSocketMontages; // 0x238(0x10)
	struct TArray<struct UAnimMontage*> ReloadSocketMontages; // 0x248(0x10)

	void FireSocket(int32_t SocketIndex); // Function Creature_CartridgeAttachment_BP.Creature_CartridgeAttachment_BP_C.FireSocket // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReloadSocket(int32_t SocketIndex); // Function Creature_CartridgeAttachment_BP.Creature_CartridgeAttachment_BP_C.ReloadSocket // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InitCreatureCartridgeAttachment(struct ACreature_WeaponItem_BP_C* CreatureWeaponItem); // Function Creature_CartridgeAttachment_BP.Creature_CartridgeAttachment_BP_C.InitCreatureCartridgeAttachment // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StopAllMontages(); // Function Creature_CartridgeAttachment_BP.Creature_CartridgeAttachment_BP_C.StopAllMontages // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_CartridgeAttachment_BP(int32_t EntryPoint); // Function Creature_CartridgeAttachment_BP.Creature_CartridgeAttachment_BP_C.ExecuteUbergraph_Creature_CartridgeAttachment_BP // (Final|UbergraphFunction) // @ game+0x1953910
};

