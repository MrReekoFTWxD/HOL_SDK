// WidgetBlueprintGeneratedClass DebugCheatMenu.DebugCheatMenu_C
// Size: 0x448 (Inherited: 0x3b1)
struct UDebugCheatMenu_C : UDebugMenu_C {
	char pad_3B1[0x7]; // 0x3b1(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3b8(0x08)
	struct UORWidget_Button_BP_C* EquipRandomWeaponMods; // 0x3c0(0x08)
	struct UORWidget_Button_BP_C* GrantAllItemsButton; // 0x3c8(0x08)
	struct UGridPanel* Grid; // 0x3d0(0x08)
	struct UORWidget_Button_BP_C* ReloadButton_BP; // 0x3d8(0x08)
	struct TMap<struct FString, struct FString> CheatNameToCommand; // 0x3e0(0x50)
	struct UDataTable* InventoryItemDataTable; // 0x430(0x08)
	struct TArray<struct UInventorySet*> DebugInventories; // 0x438(0x10)

	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugCheatMenu.DebugCheatMenu_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InitItems(); // Function DebugCheatMenu.DebugCheatMenu_C.InitItems // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Initialize(); // Function DebugCheatMenu.DebugCheatMenu_C.Initialize // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__DebugCheatMenu_ReloadButton_BP_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function DebugCheatMenu.DebugCheatMenu_C.BndEvt__DebugCheatMenu_ReloadButton_BP_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void BndEvt__DebugCheatMenu_GrantAllItemsButton_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function DebugCheatMenu.DebugCheatMenu_C.BndEvt__DebugCheatMenu_GrantAllItemsButton_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void BndEvt__DebugCheatMenu_EquipRandomWeaponMods_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function DebugCheatMenu.DebugCheatMenu_C.BndEvt__DebugCheatMenu_EquipRandomWeaponMods_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugCheatMenu(int32_t EntryPoint); // Function DebugCheatMenu.DebugCheatMenu_C.ExecuteUbergraph_DebugCheatMenu // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

