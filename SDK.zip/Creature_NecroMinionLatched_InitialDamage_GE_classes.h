// BlueprintGeneratedClass Creature_NecroMinionLatched_InitialDamage_GE.Creature_NecroMinionLatched_InitialDamage_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreature_NecroMinionLatched_InitialDamage_GE_C : UORGameplayEffect {
};

