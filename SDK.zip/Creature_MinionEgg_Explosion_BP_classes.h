// BlueprintGeneratedClass Creature_MinionEgg_Explosion_BP.Creature_MinionEgg_Explosion_BP_C
// Size: 0x490 (Inherited: 0x438)
struct ACreature_MinionEgg_Explosion_BP_C : AORExplosionActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x438(0x08)
	struct UORAkComponent* ORAk; // 0x440(0x08)
	struct UStaticMeshComponent* RadiusHelper; // 0x448(0x08)
	struct UParticleSystemComponent* B5000_Portal_Ambient_FX; // 0x450(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x458(0x08)
	struct UAbilitySystemComponent* AbilitySystem; // 0x460(0x08)
	struct FGameplayTagContainer TagContainer; // 0x468(0x20)
	struct ACreature_WeaponItem_BP_C* CreatureWeaponItem; // 0x488(0x08)

	void ReceiveBeginPlay(); // Function Creature_MinionEgg_Explosion_BP.Creature_MinionEgg_Explosion_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ReceiveActorBeginOverlap(struct AActor* OtherActor); // Function Creature_MinionEgg_Explosion_BP.Creature_MinionEgg_Explosion_BP_C.ReceiveActorBeginOverlap // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_MinionEgg_Explosion_BP(int32_t EntryPoint); // Function Creature_MinionEgg_Explosion_BP.Creature_MinionEgg_Explosion_BP_C.ExecuteUbergraph_Creature_MinionEgg_Explosion_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

