// BlueprintGeneratedClass BTT_FindRandomMoveToLocation.BTT_FindRandomMoveToLocation_C
// Size: 0xdc (Inherited: 0xa8)
struct UBTT_FindRandomMoveToLocation_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct FBlackboardKeySelector MoveToLocation; // 0xb0(0x28)
	float Radius; // 0xd8(0x04)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_FindRandomMoveToLocation.BTT_FindRandomMoveToLocation_C.ReceiveExecuteAI // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BTT_FindRandomMoveToLocation(int32_t EntryPoint); // Function BTT_FindRandomMoveToLocation.BTT_FindRandomMoveToLocation_C.ExecuteUbergraph_BTT_FindRandomMoveToLocation // (Final|UbergraphFunction) // @ game+0x1953910
};

