// UserDefinedEnum EMissionAct.EMissionAct
enum class EMissionAct : uint8 {
	NewEnumerator3 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	EMissionAct_MAX = 4
};

