// BlueprintGeneratedClass AnchorPoint_BP.AnchorPoint_BP_C
// Size: 0x3a5 (Inherited: 0x2c8)
struct AAnchorPoint_BP_C : AORAnchorPoint {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c8(0x08)
	struct USphereComponent* ProjectileCollision; // 0x2d0(0x08)
	struct USkeletalMeshComponentBudgeted* BugMesh; // 0x2d8(0x08)
	struct UORDamageHandlerComponent_NoHealth* ORDamageHandlerComponent_NoHealth; // 0x2e0(0x08)
	struct UORInteractableComponent_AnchorPoint* ORInteractableComponent_AnchorPoint; // 0x2e8(0x08)
	struct UORTriggerSourceComponent* ORTriggerSource; // 0x2f0(0x08)
	struct UORTriggerVolumeComponent* ORTriggerVolume; // 0x2f8(0x08)
	struct UORSplineFollowerComponent* ORSplineFollower; // 0x300(0x08)
	struct USceneComponent* Helpers; // 0x308(0x08)
	struct UORAkComponent* ORAk; // 0x310(0x08)
	struct UORScannableComponent* ORScannable; // 0x318(0x08)
	struct USceneComponent* Root; // 0x320(0x08)
	struct UStaticMeshComponent* vis_8m_vertical; // 0x328(0x08)
	struct UStaticMeshComponent* vis_8m_horizontal; // 0x330(0x08)
	struct UStaticMeshComponent* vis_exittrajectory; // 0x338(0x08)
	struct UStaticMeshComponent* vis_tetherrange; // 0x340(0x08)
	struct UStaticMeshComponent* vis_exittrajectory2; // 0x348(0x08)
	struct UStaticMeshComponent* vis_exittrajectory1; // 0x350(0x08)
	struct UORGazeTargetComponent* ORGazeTarget; // 0x358(0x08)
	struct FVector OriginalLocation; // 0x360(0x0c)
	bool AmbientMovement?; // 0x36c(0x01)
	char pad_36D[0x3]; // 0x36d(0x03)
	float MovementRange; // 0x370(0x04)
	int32_t AudioPlayingID; // 0x374(0x04)
	bool ShowHelpers; // 0x378(0x01)
	char pad_379[0x3]; // 0x379(0x03)
	float CooldownDuration; // 0x37c(0x04)
	struct FVector PrevLocation; // 0x380(0x0c)
	float TetheredMovementSpeed; // 0x38c(0x04)
	struct FTimerHandle AngryTimer; // 0x390(0x08)
	bool NDTakenFirstShot; // 0x398(0x01)
	char pad_399[0x3]; // 0x399(0x03)
	int32_t NDShotCount; // 0x39c(0x04)
	int32_t NDRandomShotsTrigger; // 0x3a0(0x04)
	bool Automatically Move on Spline on Release; // 0x3a4(0x01)

	bool ShouldBlockInteractionWithActor(struct AActor* Interactor); // Function AnchorPoint_BP.AnchorPoint_BP_C.ShouldBlockInteractionWithActor // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct TArray<struct AActor*> GetSecondaryEffectsTargets(); // Function AnchorPoint_BP.AnchorPoint_BP_C.GetSecondaryEffectsTargets // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct UORDamageHandlerComponent* GetDamageHandler(); // Function AnchorPoint_BP.AnchorPoint_BP_C.GetDamageHandler // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct TArray<struct UGameplayEffect*> GetKillerGameplayEffects(); // Function AnchorPoint_BP.AnchorPoint_BP_C.GetKillerGameplayEffects // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	bool HasDied(); // Function AnchorPoint_BP.AnchorPoint_BP_C.HasDied // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	float ModifyDamage(struct UObject* Damager, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function AnchorPoint_BP.AnchorPoint_BP_C.ModifyDamage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	float ModifyFinalDamage(struct UObject* Damager, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function AnchorPoint_BP.AnchorPoint_BP_C.ModifyFinalDamage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	bool ShouldBlockDamage(struct UObject* Damager, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function AnchorPoint_BP.AnchorPoint_BP_C.ShouldBlockDamage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Set ABPSpeeds(struct FVector Location); // Function AnchorPoint_BP.AnchorPoint_BP_C.Set ABPSpeeds // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StopSound(bool& Success); // Function AnchorPoint_BP.AnchorPoint_BP_C.StopSound // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void PlaySound(int32_t& PlayingID); // Function AnchorPoint_BP.AnchorPoint_BP_C.PlaySound // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UserConstructionScript(); // Function AnchorPoint_BP.AnchorPoint_BP_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StartCooldown(); // Function AnchorPoint_BP.AnchorPoint_BP_C.StartCooldown // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCooldownComplete(); // Function AnchorPoint_BP.AnchorPoint_BP_C.OnCooldownComplete // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__AnchorPoint_BP_ORTriggerVolume_K2Node_ComponentBoundEvent_4_ORTriggerVolumeComponentCallback__DelegateSignature(struct AActor* SourceActor, int32_t VolumeIndex); // Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__AnchorPoint_BP_ORTriggerVolume_K2Node_ComponentBoundEvent_4_ORTriggerVolumeComponentCallback__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void BndEvt__AnchorPoint_BP_ORTriggerVolume_K2Node_ComponentBoundEvent_5_ORTriggerVolumeComponentCallback__DelegateSignature(struct AActor* SourceActor, int32_t VolumeIndex); // Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__AnchorPoint_BP_ORTriggerVolume_K2Node_ComponentBoundEvent_5_ORTriggerVolumeComponentCallback__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void DoneBeingAngry(); // Function AnchorPoint_BP.AnchorPoint_BP_C.DoneBeingAngry // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__AnchorPoint_BP_ProjectileCollision_K2Node_ComponentBoundEvent_6_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__AnchorPoint_BP_ProjectileCollision_K2Node_ComponentBoundEvent_6_ComponentHitSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x1953910
	void TetherPullEnded(struct AORCharacter* TetherSource); // Function AnchorPoint_BP.AnchorPoint_BP_C.TetherPullEnded // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void TetherPullStarted(struct AORCharacter* TetherSource); // Function AnchorPoint_BP.AnchorPoint_BP_C.TetherPullStarted // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void SetNextMovementParams(); // Function AnchorPoint_BP.AnchorPoint_BP_C.SetNextMovementParams // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StartNextMovement(); // Function AnchorPoint_BP.AnchorPoint_BP_C.StartNextMovement // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORScannable_K2Node_ComponentBoundEvent_3_DisableHighlightSignature__DelegateSignature(); // Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__ORScannable_K2Node_ComponentBoundEvent_3_DisableHighlightSignature__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORGazeTarget_K2Node_ComponentBoundEvent_2_GazeResponseDelegate__DelegateSignature(); // Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__ORGazeTarget_K2Node_ComponentBoundEvent_2_GazeResponseDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORScannable_K2Node_ComponentBoundEvent_1_EnableHighlightSignature__DelegateSignature(); // Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__ORScannable_K2Node_ComponentBoundEvent_1_EnableHighlightSignature__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORGazeTarget_K2Node_ComponentBoundEvent_0_GazeResponseDelegate__DelegateSignature(); // Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__ORGazeTarget_K2Node_ComponentBoundEvent_0_GazeResponseDelegate__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void SetMoveTarget(struct FVector MoveTarget); // Function AnchorPoint_BP.AnchorPoint_BP_C.SetMoveTarget // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function AnchorPoint_BP.AnchorPoint_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void SetInteractableState(bool bEnabled); // Function AnchorPoint_BP.AnchorPoint_BP_C.SetInteractableState // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InteractionTriggeredWithComponent(struct AActor* Interactor, struct UORInteractableComponent* Component); // Function AnchorPoint_BP.AnchorPoint_BP_C.InteractionTriggeredWithComponent // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void InteractionTriggered(struct AActor* Interactable); // Function AnchorPoint_BP.AnchorPoint_BP_C.InteractionTriggered // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_AnchorPoint_BP(int32_t EntryPoint); // Function AnchorPoint_BP.AnchorPoint_BP_C.ExecuteUbergraph_AnchorPoint_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

