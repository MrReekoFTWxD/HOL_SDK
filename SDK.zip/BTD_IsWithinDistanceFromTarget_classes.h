// BlueprintGeneratedClass BTD_IsWithinDistanceFromTarget.BTD_IsWithinDistanceFromTarget_C
// Size: 0xcc (Inherited: 0xa0)
struct UBTD_IsWithinDistanceFromTarget_C : UBTDecorator_BlueprintBase {
	struct FBlackboardKeySelector TargetKey; // 0xa0(0x28)
	float MaxDistance; // 0xc8(0x04)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_IsWithinDistanceFromTarget.BTD_IsWithinDistanceFromTarget_C.PerformConditionCheckAI // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

