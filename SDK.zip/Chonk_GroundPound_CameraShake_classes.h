// BlueprintGeneratedClass Chonk_GroundPound_CameraShake.Chonk_GroundPound_CameraShake_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UChonk_GroundPound_CameraShake_C : UMatineeCameraShake {
};

