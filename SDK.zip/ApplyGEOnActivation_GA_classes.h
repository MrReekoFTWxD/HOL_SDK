// BlueprintGeneratedClass ApplyGEOnActivation_GA.ApplyGEOnActivation_GA_C
// Size: 0x421 (Inherited: 0x3f8)
struct UApplyGEOnActivation_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct TArray<struct UGameplayEffect*> GEToApply; // 0x400(0x10)
	struct TArray<struct FActiveGameplayEffectHandle> AppliedGE; // 0x410(0x10)
	bool DoesEndOnActivation; // 0x420(0x01)

	void K2_ActivateAbility(); // Function ApplyGEOnActivation_GA.ApplyGEOnActivation_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_ApplyGEOnActivation_GA(int32_t EntryPoint); // Function ApplyGEOnActivation_GA.ApplyGEOnActivation_GA_C.ExecuteUbergraph_ApplyGEOnActivation_GA // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

