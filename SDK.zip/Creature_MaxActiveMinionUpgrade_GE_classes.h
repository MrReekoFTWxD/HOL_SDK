// BlueprintGeneratedClass Creature_MaxActiveMinionUpgrade_GE.Creature_MaxActiveMinionUpgrade_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UCreature_MaxActiveMinionUpgrade_GE_C : UORGameplayEffect {
};

