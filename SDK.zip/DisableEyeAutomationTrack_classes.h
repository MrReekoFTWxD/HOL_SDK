// Class DisableEyeAutomationTrack.DisableEyeAutomationInterface
// Size: 0x28 (Inherited: 0x28)
struct UDisableEyeAutomationInterface : UInterface {

	void EndDisableEyeAutomation(); // Function DisableEyeAutomationTrack.DisableEyeAutomationInterface.EndDisableEyeAutomation // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xc43250
	void BeginDisableEyeAutomation(); // Function DisableEyeAutomationTrack.DisableEyeAutomationInterface.BeginDisableEyeAutomation // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xe9b690
};

// Class DisableEyeAutomationTrack.DisableEyeAutomationTrack
// Size: 0xb0 (Inherited: 0x98)
struct UDisableEyeAutomationTrack : UMovieSceneNameableTrack {
	char pad_98[0x8]; // 0x98(0x08)
	struct TArray<struct UMovieSceneSection*> Sections; // 0xa0(0x10)
};

// Class DisableEyeAutomationTrack.DisableEyeAutomationTrackSection
// Size: 0xf8 (Inherited: 0xf0)
struct UDisableEyeAutomationTrackSection : UMovieSceneSection {
	struct FDisableEyeAutomationTrackSectionParams Params; // 0xf0(0x01)
	char pad_F1[0x7]; // 0xf1(0x07)
};

