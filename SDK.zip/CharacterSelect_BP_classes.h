// BlueprintGeneratedClass CharacterSelect_BP.CharacterSelect_BP_C
// Size: 0x240 (Inherited: 0x220)
struct ACharacterSelect_BP_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x220(0x08)
	struct USkeletalMeshComponent* SkeletalMesh; // 0x228(0x08)
	struct UWidgetComponent* Widget; // 0x230(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x238(0x08)

	void PopSelectionWidget(); // Function CharacterSelect_BP.CharacterSelect_BP_C.PopSelectionWidget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void PushSelectionWidget(); // Function CharacterSelect_BP.CharacterSelect_BP_C.PushSelectionWidget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveDestroyed(); // Function CharacterSelect_BP.CharacterSelect_BP_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function CharacterSelect_BP.CharacterSelect_BP_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_CharacterSelect_BP(int32_t EntryPoint); // Function CharacterSelect_BP.CharacterSelect_BP_C.ExecuteUbergraph_CharacterSelect_BP // (Final|UbergraphFunction) // @ game+0x1953910
};

