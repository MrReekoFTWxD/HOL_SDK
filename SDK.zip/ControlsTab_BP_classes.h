// WidgetBlueprintGeneratedClass ControlsTab_BP.ControlsTab_BP_C
// Size: 0x558 (Inherited: 0x3a0)
struct UControlsTab_BP_C : UORWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a0(0x08)
	struct UWidgetAnimation* DisplayMessage; // 0x3a8(0x08)
	struct UTextBlock* BlockedRebinding_TextBlock; // 0x3b0(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* Crouch_KeybindButtons; // 0x3b8(0x08)
	struct UTextBlock* FeedbackMessage_TextBlock; // 0x3c0(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* Fire_KeybindButtons; // 0x3c8(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* Hover_KeybindButtons; // 0x3d0(0x08)
	struct UImage* Image; // 0x3d8(0x08)
	struct UImage* Image_2; // 0x3e0(0x08)
	struct UImage* Image_62; // 0x3e8(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* InfoScan_KeybindButtons; // 0x3f0(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* Interact_KeybindButtons; // 0x3f8(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* Inventory_KeybindButtons; // 0x400(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* Jump_KeybindButtons; // 0x408(0x08)
	struct UScrollBox* KeyboardMouseOptions_ScrollBox; // 0x410(0x08)
	struct UOverlay* KeyboardMouseOverlay; // 0x418(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* MoveBackward_KeybindButtons; // 0x420(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* MoveForward_KeybindButtons; // 0x428(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* MoveLeft_KeybindButtons; // 0x430(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* MoveRight_KeybindButtons; // 0x438(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* NextWeapon_KeybindButtons; // 0x440(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* PauseMenu_KeybindButtons; // 0x448(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* PrevWeapon_KeybindButtons; // 0x450(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* Reload_KeybindButtons; // 0x458(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* SecondaryFire_KeybindButtons; // 0x460(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* Slide_KeybindButtons; // 0x468(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* Sprint_KeybindButtons; // 0x470(0x08)
	struct UTextBlock* SubmenuTitle_TextBlock; // 0x478(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* WeaponAbility_KeybindButtons; // 0x480(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* WeaponBash_KeybindButtons; // 0x488(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* WeaponSwap1_KeybindButtons; // 0x490(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* WeaponSwap2_KeybindButtons; // 0x498(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* WeaponSwap3_KeybindButtons; // 0x4a0(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* WeaponSwap4_KeybindButtons; // 0x4a8(0x08)
	struct UPauseMenu_KeybindButtons_BP_C* WeaponSwap5_KeybindButtons; // 0x4b0(0x08)
	bool IsInitialized; // 0x4b8(0x01)
	char pad_4B9[0x7]; // 0x4b9(0x07)
	struct FText EnterKeybindText; // 0x4c0(0x18)
	struct FText OverlappingKeybindText; // 0x4d8(0x18)
	bool IsCapturing; // 0x4f0(0x01)
	char pad_4F1[0x7]; // 0x4f1(0x07)
	struct FMulticastInlineDelegate RequestCloseMenu; // 0x4f8(0x30)
	struct FMulticastInlineDelegate RequestResetDefaults; // 0x528(0x30)

	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function ControlsTab_BP.ControlsTab_BP_C.OnMouseButtonDown // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ResetAllKeybinds(); // Function ControlsTab_BP.ControlsTab_BP_C.ResetAllKeybinds // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void HandleRebindBlocked(); // Function ControlsTab_BP.ControlsTab_BP_C.HandleRebindBlocked // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void RequestBack(); // Function ControlsTab_BP.ControlsTab_BP_C.RequestBack // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void HandleCapturingEnded(struct UPauseMenu_KeybindButtons_BP_C* KeybindWidget, bool Success, struct FName ActionName, struct FKeyCombo NewKeyCombo); // Function ControlsTab_BP.ControlsTab_BP_C.HandleCapturingEnded // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void HandleCapturingNewBind(); // Function ControlsTab_BP.ControlsTab_BP_C.HandleCapturingNewBind // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetUpKeybinds(); // Function ControlsTab_BP.ControlsTab_BP_C.SetUpKeybinds // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct FEventReply OnPreviewKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function ControlsTab_BP.ControlsTab_BP_C.OnPreviewKeyDown // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function ControlsTab_BP.ControlsTab_BP_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnPushed(); // Function ControlsTab_BP.ControlsTab_BP_C.OnPushed // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnPopped(); // Function ControlsTab_BP.ControlsTab_BP_C.OnPopped // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_ControlsTab_BP(int32_t EntryPoint); // Function ControlsTab_BP.ControlsTab_BP_C.ExecuteUbergraph_ControlsTab_BP // (Final|UbergraphFunction) // @ game+0x1953910
	void RequestResetDefaults__DelegateSignature(); // Function ControlsTab_BP.ControlsTab_BP_C.RequestResetDefaults__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void RequestCloseMenu__DelegateSignature(); // Function ControlsTab_BP.ControlsTab_BP_C.RequestCloseMenu__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

