// BlueprintGeneratedClass Ability_ConversationChoice_2.Ability_ConversationChoice_1_C
// Size: 0x400 (Inherited: 0x400)
struct UAbility_ConversationChoice_1_C : UORGameplayAbility_ConversationChoice {
};

