// BlueprintGeneratedClass Ability_ConversationChoice_5.Ability_ConversationChoice_4_C
// Size: 0x400 (Inherited: 0x400)
struct UAbility_ConversationChoice_4_C : UORGameplayAbility_ConversationChoice {
};

