// BlueprintGeneratedClass Chonk_EnemyMortar_BarrageExplosion.Chonk_EnemyMortar_BarrageExplosion_C
// Size: 0x458 (Inherited: 0x458)
struct AChonk_EnemyMortar_BarrageExplosion_C : AChonk_EnemyMortar_PrimaryExplosion_C {
};

