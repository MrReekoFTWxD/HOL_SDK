// BlueprintGeneratedClass Ability_SkipDialogue.Ability_SkipDialogue_C
// Size: 0x408 (Inherited: 0x3f8)
struct UAbility_SkipDialogue_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct FTimerHandle SkipTimer; // 0x400(0x08)

	void K2_ActivateAbility(); // Function Ability_SkipDialogue.Ability_SkipDialogue_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function Ability_SkipDialogue.Ability_SkipDialogue_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void FireSkip(); // Function Ability_SkipDialogue.Ability_SkipDialogue_C.FireSkip // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Ability_SkipDialogue(int32_t EntryPoint); // Function Ability_SkipDialogue.Ability_SkipDialogue_C.ExecuteUbergraph_Ability_SkipDialogue // (Final|UbergraphFunction) // @ game+0x1953910
};

