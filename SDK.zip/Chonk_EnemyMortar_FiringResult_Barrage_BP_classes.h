// BlueprintGeneratedClass Chonk_EnemyMortar_FiringResult_Barrage_BP.Chonk_EnemyMortar_FiringResult_Barrage_BP_C
// Size: 0x358 (Inherited: 0x358)
struct UChonk_EnemyMortar_FiringResult_Barrage_BP_C : UChonk_ArcFiringResult_Base_BP_C {
};

