// BlueprintGeneratedClass Creature_HighImpactMinionFire_FiringResult_BP.Creature_HighImpactMinionFire_FiringResult_BP_C
// Size: 0x2d0 (Inherited: 0x2c8)
struct UCreature_HighImpactMinionFire_FiringResult_BP_C : UORFiringResult_Projectile {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c8(0x08)

	void BP_InitProjectile(struct ASQProjectile* Projectile); // Function Creature_HighImpactMinionFire_FiringResult_BP.Creature_HighImpactMinionFire_FiringResult_BP_C.BP_InitProjectile // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Creature_HighImpactMinionFire_FiringResult_BP(int32_t EntryPoint); // Function Creature_HighImpactMinionFire_FiringResult_BP.Creature_HighImpactMinionFire_FiringResult_BP_C.ExecuteUbergraph_Creature_HighImpactMinionFire_FiringResult_BP // (Final|UbergraphFunction) // @ game+0x1953910
};

