// BlueprintGeneratedClass BP_Immortal.BP_Immortal_C
// Size: 0x242c (Inherited: 0x233d)
struct ABP_Immortal_C : AFlyingHenchman_BP_C {
	char pad_233D[0x3]; // 0x233d(0x03)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2340(0x08)
	struct UNiagaraComponent* NPS_Death; // 0x2348(0x08)
	struct UNiagaraComponent* NPS_FlyingPowers; // 0x2350(0x08)
	struct USQDismemberComponent* DismemberComp; // 0x2358(0x08)
	struct UORSquadUnitConsumerComponent* ORSquadUnitConsumer; // 0x2360(0x08)
	struct UMercuna3DNavigationComponent* Mercuna3DNavigation; // 0x2368(0x08)
	struct UORAkComponent* ORAk (Body); // 0x2370(0x08)
	float WarpOutTimeline_Dissolve_8C143B554711AE346A39F78EFBB00C69; // 0x2378(0x04)
	enum class ETimelineDirection WarpOutTimeline__Direction_8C143B554711AE346A39F78EFBB00C69; // 0x237c(0x01)
	char pad_237D[0x3]; // 0x237d(0x03)
	struct UTimelineComponent* WarpOutTimeline; // 0x2380(0x08)
	float WarpOutScaleTimeline_ScaleTrack_D16E5E6C485D48D058487C8106306663; // 0x2388(0x04)
	enum class ETimelineDirection WarpOutScaleTimeline__Direction_D16E5E6C485D48D058487C8106306663; // 0x238c(0x01)
	char pad_238D[0x3]; // 0x238d(0x03)
	struct UTimelineComponent* WarpOutScaleTimeline; // 0x2390(0x08)
	int32_t MaxActiveShielders; // 0x2398(0x04)
	int32_t MaxTotalSpawnedShielders; // 0x239c(0x04)
	int32_t ActiveShielderCount; // 0x23a0(0x04)
	int32_t SpawnedShielderCount; // 0x23a4(0x04)
	enum class E_ImmortalMovementMode MovementMode; // 0x23a8(0x01)
	char pad_23A9[0x3]; // 0x23a9(0x03)
	float ElapsedTime; // 0x23ac(0x04)
	struct AORAICharacter* CurrentShieldTarget; // 0x23b0(0x08)
	struct AImmortalHead_BP_C* CurrentShielderHead; // 0x23b8(0x08)
	struct TArray<struct AImmortalHead_BP_C*> SpawnedShielders; // 0x23c0(0x10)
	struct AActor* OrbitTarget; // 0x23d0(0x08)
	struct AImmortalHead_Shield_BP_C* ImmortalShield; // 0x23d8(0x08)
	bool IsRecharging; // 0x23e0(0x01)
	char pad_23E1[0x3]; // 0x23e1(0x03)
	struct FName HeadSpawnSocketName; // 0x23e4(0x08)
	struct FGameplayTag MindControlStatusTag; // 0x23ec(0x08)
	char pad_23F4[0x4]; // 0x23f4(0x04)
	struct TArray<struct UMaterialInstanceDynamic*> DynamicMaterialInstances_Cached; // 0x23f8(0x10)
	struct FTimerHandle UpdateAutoWarpOutTimerHandle; // 0x2408(0x08)
	struct FTimerHandle AutoWarpOutTimer; // 0x2410(0x08)
	float CurrentAutoWarpOutTime; // 0x2418(0x04)
	float EncounterStartAutoWarpOutTime; // 0x241c(0x04)
	float PostShieldAutoWarpOutTime; // 0x2420(0x04)
	bool AutoWarpOut; // 0x2424(0x01)
	char pad_2425[0x3]; // 0x2425(0x03)
	float InitialShieldDelay; // 0x2428(0x04)

	void CanWarpOut(bool& CanWarpOut?); // Function BP_Immortal.BP_Immortal_C.CanWarpOut // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void IsMindControlled(bool& MindControlled); // Function BP_Immortal.BP_Immortal_C.IsMindControlled // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void FinishWarpingOut(); // Function BP_Immortal.BP_Immortal_C.FinishWarpingOut // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StartWarpingOut(); // Function BP_Immortal.BP_Immortal_C.StartWarpingOut // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InitiateWarpOut(); // Function BP_Immortal.BP_Immortal_C.InitiateWarpOut // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UpdateAutoWarpOut(); // Function BP_Immortal.BP_Immortal_C.UpdateAutoWarpOut // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void CanSpawnShielder(bool& CanSpawn); // Function BP_Immortal.BP_Immortal_C.CanSpawnShielder // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void SetCurrentShieldTarget(struct AORAICharacter* NewShieldTarget); // Function BP_Immortal.BP_Immortal_C.SetCurrentShieldTarget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void GetBestShieldTarget(struct AORAICharacter*& TargetCharacter); // Function BP_Immortal.BP_Immortal_C.GetBestShieldTarget // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetImmortalShieldEnabled(bool ShieldEnabled); // Function BP_Immortal.BP_Immortal_C.SetImmortalShieldEnabled // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void EndShieldRecharge(); // Function BP_Immortal.BP_Immortal_C.EndShieldRecharge // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BeginShieldRecharge(); // Function BP_Immortal.BP_Immortal_C.BeginShieldRecharge // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void KillAllSpawnedShielders(); // Function BP_Immortal.BP_Immortal_C.KillAllSpawnedShielders // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void LoseSpawnedShielder(struct AImmortalHead_BP_C*& Shielder); // Function BP_Immortal.BP_Immortal_C.LoseSpawnedShielder // (Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void TrackSpawnedShielder(struct AImmortalHead_BP_C*& Shielder); // Function BP_Immortal.BP_Immortal_C.TrackSpawnedShielder // (Private|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetOrbitTarget(struct AORAICharacter* OrbitTarget); // Function BP_Immortal.BP_Immortal_C.SetOrbitTarget // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SpawnShielder(); // Function BP_Immortal.BP_Immortal_C.SpawnShielder // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void DispatchShielder(struct AORAICharacter* ShieldTarget, bool& Dispatched); // Function BP_Immortal.BP_Immortal_C.DispatchShielder // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetScalarParameterOnMaterialInstances(struct FName Name, float Value); // Function BP_Immortal.BP_Immortal_C.SetScalarParameterOnMaterialInstances // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetupMaterialInstances(); // Function BP_Immortal.BP_Immortal_C.SetupMaterialInstances // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void WarpOutScaleTimeline__FinishedFunc(); // Function BP_Immortal.BP_Immortal_C.WarpOutScaleTimeline__FinishedFunc // (BlueprintEvent) // @ game+0x1953910
	void WarpOutScaleTimeline__UpdateFunc(); // Function BP_Immortal.BP_Immortal_C.WarpOutScaleTimeline__UpdateFunc // (BlueprintEvent) // @ game+0x1953910
	void WarpOutTimeline__FinishedFunc(); // Function BP_Immortal.BP_Immortal_C.WarpOutTimeline__FinishedFunc // (BlueprintEvent) // @ game+0x1953910
	void WarpOutTimeline__UpdateFunc(); // Function BP_Immortal.BP_Immortal_C.WarpOutTimeline__UpdateFunc // (BlueprintEvent) // @ game+0x1953910
	void Audio_Play_Attached_Loop(); // Function BP_Immortal.BP_Immortal_C.Audio_Play_Attached_Loop // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Audio_Stop_Attached_Loop(); // Function BP_Immortal.BP_Immortal_C.Audio_Stop_Attached_Loop // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Audio_ShieldHead_Death(); // Function BP_Immortal.BP_Immortal_C.Audio_ShieldHead_Death // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Audio_ReturnedToPool(); // Function BP_Immortal.BP_Immortal_C.Audio_ReturnedToPool // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ReceiveBeginPlay(); // Function BP_Immortal.BP_Immortal_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void OnDied(struct UObject* Killer, struct FHitResult& HitResult, struct FGameplayTagContainer& DamageTags); // Function BP_Immortal.BP_Immortal_C.OnDied // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1953910
	void ReceiveDirectEvent(struct FGameplayTag Tag, struct UORGlobalEventPayload* Payload); // Function BP_Immortal.BP_Immortal_C.ReceiveDirectEvent // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnShielderDied(struct AORAICharacter* Victim, struct UObject* Killer); // Function BP_Immortal.BP_Immortal_C.OnShielderDied // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Audio_Stop_StunnedSfx(); // Function BP_Immortal.BP_Immortal_C.Audio_Stop_StunnedSfx // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Audio_Play_StunnedSfx(); // Function BP_Immortal.BP_Immortal_C.Audio_Play_StunnedSfx // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Audio_Death(); // Function BP_Immortal.BP_Immortal_C.Audio_Death // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void StartImmortalStun(); // Function BP_Immortal.BP_Immortal_C.StartImmortalStun // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BP_OnStatusEffectChanged(enum class EORAIStatusEffect NewStatusEffect); // Function BP_Immortal.BP_Immortal_C.BP_OnStatusEffectChanged // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void OnCurrentShieldTargetDied(struct UObject* Killer, struct AORCharacter* Killed, struct FHitResult& HitResult, struct FGameplayTagContainer& DamageTags); // Function BP_Immortal.BP_Immortal_C.OnCurrentShieldTargetDied // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Audio_Start_HoverLoop(); // Function BP_Immortal.BP_Immortal_C.Audio_Start_HoverLoop // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BP_SpawnedFromPool(); // Function BP_Immortal.BP_Immortal_C.BP_SpawnedFromPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void BP_ReturnedToPool(); // Function BP_Immortal.BP_Immortal_C.BP_ReturnedToPool // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void ResetMaterialParams(); // Function BP_Immortal.BP_Immortal_C.ResetMaterialParams // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BP_Immortal(int32_t EntryPoint); // Function BP_Immortal.BP_Immortal_C.ExecuteUbergraph_BP_Immortal // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

