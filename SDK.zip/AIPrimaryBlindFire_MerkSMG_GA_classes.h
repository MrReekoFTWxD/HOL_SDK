// BlueprintGeneratedClass AIPrimaryBlindFire_MerkSMG_GA.AIPrimaryBlindFire_MerkSMG_GA_C
// Size: 0x490 (Inherited: 0x490)
struct UAIPrimaryBlindFire_MerkSMG_GA_C : UAIPrimaryBlindFire_GA_C {
};

