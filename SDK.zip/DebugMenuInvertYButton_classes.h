// BlueprintGeneratedClass DebugMenuInvertYButton.DebugMenuInvertYButton_C
// Size: 0x500 (Inherited: 0x4d0)
struct UDebugMenuInvertYButton_C : UDebugMenuButton_C {
	struct FMulticastInlineDelegate SyncInvertState; // 0x4d0(0x30)

	void ToggleState(); // Function DebugMenuInvertYButton.DebugMenuInvertYButton_C.ToggleState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void InitState(); // Function DebugMenuInvertYButton.DebugMenuInvertYButton_C.InitState // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SyncInvertState__DelegateSignature(bool Enabled); // Function DebugMenuInvertYButton.DebugMenuInvertYButton_C.SyncInvertState__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
};

