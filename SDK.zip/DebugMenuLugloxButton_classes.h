// WidgetBlueprintGeneratedClass DebugMenuLugloxButton.DebugMenuLugloxButton_C
// Size: 0x2c8 (Inherited: 0x290)
struct UDebugMenuLugloxButton_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UORWidget_Button_BP_C* ORWidget_Button_BP; // 0x298(0x08)
	struct FText Label; // 0x2a0(0x18)
	struct TArray<struct FDataTableRowHandle> RewardTableRows; // 0x2b8(0x10)

	void UpdateText(); // Function DebugMenuLugloxButton.DebugMenuLugloxButton_C.UpdateText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void SetupLugloxButton(struct FText Text, struct TArray<struct FDataTableRowHandle>& RewardRows); // Function DebugMenuLugloxButton.DebugMenuLugloxButton_C.SetupLugloxButton // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugMenuLugloxButton.DebugMenuLugloxButton_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function DebugMenuLugloxButton.DebugMenuLugloxButton_C.BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugMenuLugloxButton(int32_t EntryPoint); // Function DebugMenuLugloxButton.DebugMenuLugloxButton_C.ExecuteUbergraph_DebugMenuLugloxButton // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

