// WidgetBlueprintGeneratedClass DebugLevelMenu.DebugLevelMenu_C
// Size: 0x410 (Inherited: 0x3b1)
struct UDebugLevelMenu_C : UDebugMenu_C {
	char pad_3B1[0x7]; // 0x3b1(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3b8(0x08)
	struct UComboBoxString* CheckpointComboBox; // 0x3c0(0x08)
	struct UORWidget_Button_BP_C* ClearProfileSaveButton_BP; // 0x3c8(0x08)
	struct UORWidget_Button_BP_C* ClearSaveButton_BP; // 0x3d0(0x08)
	struct UComboBoxString* DifficultyComboBox; // 0x3d8(0x08)
	struct UTextBlock* DiskSaveData; // 0x3e0(0x08)
	struct UDebugMenuInvertYButton_C* InvertYButton; // 0x3e8(0x08)
	struct UTextBlock* InvertYText; // 0x3f0(0x08)
	struct UORWidget_Button_BP_C* ReloadButton_BP; // 0x3f8(0x08)
	struct UTextBlock* RuntimeSaveData; // 0x400(0x08)
	struct UTextBlock* SoftSaveData; // 0x408(0x08)

	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function DebugLevelMenu.DebugLevelMenu_C.OnFocusReceived // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Initialize(); // Function DebugLevelMenu.DebugLevelMenu_C.Initialize // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void BndEvt__InvertYButton_K2Node_ComponentBoundEvent_2_SyncInvertState__DelegateSignature(bool Enabled); // Function DebugLevelMenu.DebugLevelMenu_C.BndEvt__InvertYButton_K2Node_ComponentBoundEvent_2_SyncInvertState__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void Construct(); // Function DebugLevelMenu.DebugLevelMenu_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORWidget_ReloadButton_BP_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature(); // Function DebugLevelMenu.DebugLevelMenu_C.BndEvt__ORWidget_ReloadButton_BP_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature(); // Function DebugLevelMenu.DebugLevelMenu_C.BndEvt__ORWidget_Button_BP_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void BndEvt__ClearProfileSaveButton_BP_K2Node_ComponentBoundEvent_7_OnButtonClickedEvent__DelegateSignature(); // Function DebugLevelMenu.DebugLevelMenu_C.BndEvt__ClearProfileSaveButton_BP_K2Node_ComponentBoundEvent_7_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void BndEvt__InvertYButton_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function DebugLevelMenu.DebugLevelMenu_C.BndEvt__InvertYButton_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void BndEvt__DebugLevelMenu_DifficultyComboBox_K2Node_ComponentBoundEvent_1_OnSelectionChangedEvent__DelegateSignature(struct FString SelectedItem, enum class ESelectInfo SelectionType); // Function DebugLevelMenu.DebugLevelMenu_C.BndEvt__DebugLevelMenu_DifficultyComboBox_K2Node_ComponentBoundEvent_1_OnSelectionChangedEvent__DelegateSignature // (BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_DebugLevelMenu(int32_t EntryPoint); // Function DebugLevelMenu.DebugLevelMenu_C.ExecuteUbergraph_DebugLevelMenu // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

