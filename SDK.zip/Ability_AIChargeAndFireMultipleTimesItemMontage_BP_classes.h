// BlueprintGeneratedClass Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C
// Size: 0x468 (Inherited: 0x428)
struct UAbility_AIChargeAndFireMultipleTimesItemMontage_BP_C : UORGameplayAbility_FireItem {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x428(0x08)
	struct UAnimMontage* FiringMontage; // 0x430(0x08)
	struct FName StartSectionName; // 0x438(0x08)
	struct FName FiringSectionName; // 0x440(0x08)
	struct FName LastShotSectionName; // 0x448(0x08)
	struct UORFireLoop_Enemy* Fireloop Component; // 0x450(0x08)
	struct FTimerHandle InitialDelayTimerHandle; // 0x458(0x08)
	struct FTimerHandle FireRateTiming; // 0x460(0x08)

	void GetFireLoopComponent(struct UORFireLoop_Enemy*& FireloopComponent); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.GetFireLoopComponent // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1953910
	void OnCancelled_48D23F304AF0142EF325D88D9B4A6042(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.OnCancelled_48D23F304AF0142EF325D88D9B4A6042 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnInterrupted_48D23F304AF0142EF325D88D9B4A6042(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.OnInterrupted_48D23F304AF0142EF325D88D9B4A6042 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnBlendOut_48D23F304AF0142EF325D88D9B4A6042(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.OnBlendOut_48D23F304AF0142EF325D88D9B4A6042 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnCompleted_48D23F304AF0142EF325D88D9B4A6042(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.OnCompleted_48D23F304AF0142EF325D88D9B4A6042 // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void K2_CommitExecute(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void InitialDelayTrigger(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.InitialDelayTrigger // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void TimerLoopTriggerShots(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.TimerLoopTriggerShots // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Ability_AIChargeAndFireMultipleTimesItemMontage_BP(int32_t EntryPoint); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.ExecuteUbergraph_Ability_AIChargeAndFireMultipleTimesItemMontage_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

