// WidgetBlueprintGeneratedClass ButtonPrompt_BP.ButtonPrompt_BP_C
// Size: 0x337 (Inherited: 0x290)
struct UButtonPrompt_BP_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UTextBlock* ButtonCombo_TextBlock; // 0x298(0x08)
	struct UImage* ButtonComboImage; // 0x2a0(0x08)
	struct UImage* ButtonImage; // 0x2a8(0x08)
	struct UHorizontalBox* ButtonImage_HorizontalBox; // 0x2b0(0x08)
	struct UImage* Image_44; // 0x2b8(0x08)
	struct UImage* PlusSignImage; // 0x2c0(0x08)
	bool bIsGamepad; // 0x2c8(0x01)
	enum class EInputDeviceType CurrentInputDevice; // 0x2c9(0x01)
	char pad_2CA[0x6]; // 0x2ca(0x06)
	struct UDataTable* ButtonIconDataTable; // 0x2d0(0x08)
	struct TMap<enum class EInputDeviceType, struct FKey> OverrideKeys; // 0x2d8(0x50)
	struct FName Action Name; // 0x328(0x08)
	bool UseText; // 0x330(0x01)
	bool ForceKBM; // 0x331(0x01)
	bool UseMinimalImage; // 0x332(0x01)
	bool UseHelpTextIcon; // 0x333(0x01)
	bool bIsAxisKey; // 0x334(0x01)
	bool bIsPositiveAxis; // 0x335(0x01)
	bool IsXenoButton; // 0x336(0x01)

	void ApplyKeyText(struct FButtonPromptIcon IconData); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.ApplyKeyText // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void FindImageForKey(struct FKey KeyToFind, struct FButtonPromptIcon& FoundIconData); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.FindImageForKey // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UpdateButtonImage(); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.UpdateButtonImage // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void UpdateInputDevice(enum class EInputDeviceType NewInputDevice); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.UpdateInputDevice // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnLoaded_640DFFB94D753175E4E3B08AB61FC9BA(struct UObject* Loaded); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.OnLoaded_640DFFB94D753175E4E3B08AB61FC9BA // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void Construct(); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x1953910
	void Apply Key Image(struct FButtonPromptIcon IconData, struct UImage* ImageToSet); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.Apply Key Image // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void OnActionBindUpdated(struct FName ActionName); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.OnActionBindUpdated // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_ButtonPrompt_BP(int32_t EntryPoint); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.ExecuteUbergraph_ButtonPrompt_BP // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

