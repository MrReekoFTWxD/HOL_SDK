// BlueprintGeneratedClass Ability_ChangeEquippedItemBase_BP.Ability_ChangeEquippedItemBase_BP_C
// Size: 0x3e0 (Inherited: 0x3d8)
struct UAbility_ChangeEquippedItemBase_BP_C : UGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d8(0x08)

	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayAbilitySpecHandle Handle, struct FGameplayTagContainer& RelevantTags); // Function Ability_ChangeEquippedItemBase_BP.Ability_ChangeEquippedItemBase_BP_C.K2_CanActivateAbility // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1953910
	void GetOwningInventory(struct UORPlayerInventory*& OutInventory); // Function Ability_ChangeEquippedItemBase_BP.Ability_ChangeEquippedItemBase_BP_C.GetOwningInventory // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function Ability_ChangeEquippedItemBase_BP.Ability_ChangeEquippedItemBase_BP_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_Ability_ChangeEquippedItemBase_BP(int32_t EntryPoint); // Function Ability_ChangeEquippedItemBase_BP.Ability_ChangeEquippedItemBase_BP_C.ExecuteUbergraph_Ability_ChangeEquippedItemBase_BP // (Final|UbergraphFunction) // @ game+0x1953910
};

