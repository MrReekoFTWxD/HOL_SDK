// BlueprintGeneratedClass AIImpactDamage_GE.AIImpactDamage_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UAIImpactDamage_GE_C : UORGameplayEffect {
};

