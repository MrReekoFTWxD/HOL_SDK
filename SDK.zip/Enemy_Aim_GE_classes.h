// BlueprintGeneratedClass Enemy_Aim_GE.Enemy_Aim_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UEnemy_Aim_GE_C : UORGameplayEffect {
};

