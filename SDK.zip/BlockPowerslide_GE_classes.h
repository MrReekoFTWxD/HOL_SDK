// BlueprintGeneratedClass BlockPowerslide_GE.BlockPowerslide_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UBlockPowerslide_GE_C : UORGameplayEffect {
};

