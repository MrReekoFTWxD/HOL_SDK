// BlueprintGeneratedClass Ability_SecondaryFire_BP.Ability_SecondaryFire_BP_C
// Size: 0x428 (Inherited: 0x428)
struct UAbility_SecondaryFire_BP_C : UORGameplayAbility_FireItem {
};

