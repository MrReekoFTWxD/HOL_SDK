// BlueprintGeneratedClass Ability_Reload_BP.Ability_Reload_BP_C
// Size: 0x428 (Inherited: 0x428)
struct UAbility_Reload_BP_C : UORGameplayAbility_FireItem {
};

