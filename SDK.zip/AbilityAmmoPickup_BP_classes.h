// BlueprintGeneratedClass AbilityAmmoPickup_BP.AbilityAmmoPickup_BP_C
// Size: 0x2d8 (Inherited: 0x2d8)
struct AAbilityAmmoPickup_BP_C : AORAmmoPickup {
};

