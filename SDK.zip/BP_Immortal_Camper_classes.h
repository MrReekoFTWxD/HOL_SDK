// BlueprintGeneratedClass BP_Immortal_Camper.BP_Immortal_Camper_C
// Size: 0x242c (Inherited: 0x242c)
struct ABP_Immortal_Camper_C : ABP_Immortal_C {
};

