// BlueprintGeneratedClass BlockCrouch_GA.BlockCrouch_GA_C
// Size: 0x400 (Inherited: 0x3f8)
struct UBlockCrouch_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)

	void K2_ActivateAbility(); // Function BlockCrouch_GA.BlockCrouch_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_BlockCrouch_GA(int32_t EntryPoint); // Function BlockCrouch_GA.BlockCrouch_GA_C.ExecuteUbergraph_BlockCrouch_GA // (Final|UbergraphFunction) // @ game+0x1953910
};

