// BlueprintGeneratedClass Ability_GunInteraction_Kenny_BP.Ability_GunInteraction_Kenny_BP_C
// Size: 0x3f9 (Inherited: 0x3f9)
struct UAbility_GunInteraction_Kenny_BP_C : UAbility_GunInteraction_BP_C {
};

