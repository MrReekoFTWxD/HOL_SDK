// BlueprintGeneratedClass AI_Flying_Type_GE.AI_Flying_Type_GE_C
// Size: 0x818 (Inherited: 0x818)
struct UAI_Flying_Type_GE_C : UORGameplayEffect {
};

