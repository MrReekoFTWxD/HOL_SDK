// BlueprintGeneratedClass ApplyGEOnOwnerItemEvent_GA.ApplyGEOnOwnerItemEvent_GA_C
// Size: 0x420 (Inherited: 0x3f8)
struct UApplyGEOnOwnerItemEvent_GA_C : UORGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct ASQInventoryItem* OwnerSQInventoryItem; // 0x400(0x08)
	struct UGameplayEffect* GEToApply; // 0x408(0x08)
	struct FGameplayTag EventTag; // 0x410(0x08)
	struct FGameplayTag FireModeTag; // 0x418(0x08)

	void OnItemEvent(struct ASQInventoryItem* Item, struct FGameplayTag EventTag, struct FGameplayTag FireMode, enum class EInventoryTransactionType TransactionType); // Function ApplyGEOnOwnerItemEvent_GA.ApplyGEOnOwnerItemEvent_GA_C.OnItemEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x1953910
	void K2_OnEndAbility(bool bWasCancelled); // Function ApplyGEOnOwnerItemEvent_GA.ApplyGEOnOwnerItemEvent_GA_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void K2_ActivateAbility(); // Function ApplyGEOnOwnerItemEvent_GA.ApplyGEOnOwnerItemEvent_GA_C.K2_ActivateAbility // (Event|Protected|BlueprintEvent) // @ game+0x1953910
	void ExecuteUbergraph_ApplyGEOnOwnerItemEvent_GA(int32_t EntryPoint); // Function ApplyGEOnOwnerItemEvent_GA.ApplyGEOnOwnerItemEvent_GA_C.ExecuteUbergraph_ApplyGEOnOwnerItemEvent_GA // (Final|UbergraphFunction|HasDefaults) // @ game+0x1953910
};

